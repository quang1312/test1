from __future__ import annotations

from collections import Counter, defaultdict

from backend.models.analytics import (
    AlarmAnalytics,
    AnalyticsFilter,
    AnalyticsKpi,
    BessAnalytics,
    EnergyBalancePoint,
    GridAnalytics,
    LoadAnalytics,
    PowerTrendPoint,
    PvAnalytics,
)


class AnalyticsCalculator:

    ALARM_KEYS = {"totalAlarms", "criticalAlarms", "faultAlarms", "warningAlarms", "avgAckMinutes",
                  "topAlarmSource", "repeatedAlarmCount", "alarmRatePerDay"}

    COLORS = {
        "pv": "#facc15",
        "bess": "#38bdf8",
        "grid": "#60a5fa",
        "load": "#a78bfa",
        "alarm": "#ef4444",
        "good": "#22c55e",
        "muted": "#94a3b8",
    }

    def __init__(self):
        self._unavailable: set[str] = set()
        self._finance: dict | None = None
        self._capacity_mwh: float | None = None
        self._live = False

    def calculate(self, dataset: dict) -> dict:
        self._unavailable = set(dataset.get("unavailable", ()))
        self._finance = dataset.get("financeTotals")
        self._capacity_mwh = dataset.get("bessCapacityMwh")
        self._live = bool(dataset.get("live"))
        samples = dataset["samples"]
        alarms = dataset["alarms"]
        step_hours = dataset["stepHours"]
        energy_bucket = dataset["energyBucket"]
        trend = self._power_trend(samples)
        balance = self._energy_balance(samples, step_hours, energy_bucket)
        if not samples:  # không có dữ liệu historian: mọi KPI dựa trên mẫu -> "--", chỉ giữ KPI alarm
            self._unavailable |= set(self._summary(samples, alarms, step_hours, balance)) - self.ALARM_KEYS
        kpis = self._kpis(samples, alarms, step_hours, balance)
        return {
            "analyticsKpi": kpis,
            "powerTrendData": trend,
            "energyBalanceData": balance,
            "bessAnalytics": self._bess(samples, alarms, step_hours),
            "pvAnalytics": self._pv(samples, step_hours),
            "gridAnalytics": self._grid(samples, step_hours),
            "loadAnalytics": self._load(samples, step_hours),
            "alarmAnalytics": self._alarm(alarms, samples),
            "summary": self._summary(samples, alarms, step_hours, balance),
        }

    def visible_kpis(self, all_kpis: dict[str, list[AnalyticsKpi]], analytics_filter: AnalyticsFilter) -> list[AnalyticsKpi]:
        key = self._asset_key(analytics_filter.assetType)
        if key == "all":
            return all_kpis["all"][:10]
        if key == "pcs":
            return all_kpis["bess"][:4] + all_kpis["grid"][:2]
        if key == "transformer":
            return [
                AnalyticsKpi("Transformer loading peak", all_kpis["load"][0].value, "MW", "#a78bfa", "Transformer", "up", "Proxy from feeder loading"),
                AnalyticsKpi("Energy balance error", all_kpis["all"][-1].value, "%", "#facc15", "Transformer", "stable", "Loss/imbalance proxy"),
                AnalyticsKpi("Alarm rate", all_kpis["all"][7].value, "alarms/day", "#ef4444", "Transformer", "stable", "Filtered source"),
            ]
        return all_kpis.get(key, all_kpis["all"])[:10]

    @staticmethod
    def _v(summary: dict, key: str):
        value = summary.get(key)
        return "--" if value is None else value

    def _power_trend(self, samples: list[dict]) -> list[PowerTrendPoint]:
        peak = max((sample.get("peakLoadMw", sample["loadMw"]) for sample in samples), default=0.0)
        return [
            PowerTrendPoint(
                timestamp=sample["timestamp"],
                timeLabel=sample["timeLabel"],
                loadMw=sample["loadMw"],
                pvMw=sample["pvMw"],
                bessMw=sample["bessMw"],
                gridMw=sample["gridMw"],
                socPct=sample["socPct"] if sample.get("socKnown", True) else None,
                peakDemandMw=round(peak, 3),
                gridImportLimitMw=sample["gridImportLimitMw"],
                gridExportLimitMw=sample["gridExportLimitMw"],
            )
            for sample in samples
        ]

    def _energy_balance(self, samples: list[dict], step_hours: float, bucket: str) -> list[EnergyBalancePoint]:
        grouped: dict[str, dict] = defaultdict(lambda: defaultdict(float))
        for sample in samples:
            label = sample["periodLabel"]
            item = grouped[label]
            item["pvGenerationMwh"] += max(0.0, sample["pvMw"]) * step_hours
            item["gridImportMwh"] += max(0.0, sample["gridMw"]) * step_hours
            item["bessDischargeMwh"] += max(0.0, sample["bessMw"]) * step_hours
            item["loadConsumptionMwh"] += max(0.0, sample["loadMw"] - sample["loadShedMw"]) * step_hours
            item["bessChargeMwh"] += max(0.0, -sample["bessMw"]) * step_hours
            item["gridExportMwh"] += max(0.0, -sample["gridMw"]) * step_hours
            if not self._live:  # live: không có số đo tổn thất -> để lệch cân bằng hiện đúng trong balanceErrorPct
                item["lossMwh"] += max(0.0, 0.015 * sample["loadMw"] + sample["pvCurtailmentMw"] * 0.08) * step_hours
        rows: list[EnergyBalancePoint] = []
        for label, values in grouped.items():
            supply = values["pvGenerationMwh"] + values["gridImportMwh"] + values["bessDischargeMwh"]
            demand = values["loadConsumptionMwh"] + values["bessChargeMwh"] + values["gridExportMwh"] + values["lossMwh"]
            error = 0.0 if supply <= 0.01 else abs(supply - demand) / supply * 100.0
            rows.append(
                EnergyBalancePoint(
                    periodLabel=label,
                    pvGenerationMwh=round(values["pvGenerationMwh"], 2),
                    gridImportMwh=round(values["gridImportMwh"], 2),
                    bessDischargeMwh=round(values["bessDischargeMwh"], 2),
                    loadConsumptionMwh=round(values["loadConsumptionMwh"], 2),
                    bessChargeMwh=round(values["bessChargeMwh"], 2),
                    gridExportMwh=round(values["gridExportMwh"], 2),
                    lossMwh=round(values["lossMwh"], 2),
                    balanceErrorPct=round(error, 2),
                )
            )
        return rows

    def _kpis(self, samples: list[dict], alarms: list[dict], step_hours: float, balance: list[EnergyBalancePoint]) -> dict[str, list[AnalyticsKpi]]:
        summary = self._summary(samples, alarms, step_hours, balance)
        c = self.COLORS
        all_kpis = [
            AnalyticsKpi("Total generation", self._v(summary, "totalGenerationMwh"), "MWh", c["good"], "All system", "up"),
            AnalyticsKpi("Total load consumption", self._v(summary, "loadMwh"), "MWh", c["load"], "Load", "stable"),
            AnalyticsKpi("Renewable fraction", self._v(summary, "renewableFractionPct"), "%", c["good"], "All system", "up"),
            AnalyticsKpi("Grid dependency", self._v(summary, "gridDependencyPct"), "%", c["grid"], "Grid", "down"),
            AnalyticsKpi("Energy self-sufficiency", self._v(summary, "selfSufficiencyPct"), "%", c["good"], "All system", "up"),
            AnalyticsKpi("Peak demand", self._v(summary, "peakDemandMw"), "MW", c["load"], "Load", "up"),
            AnalyticsKpi("Peak shaving energy", self._v(summary, "peakShavingMwh"), "MWh", c["bess"], "BESS", "up"),
            AnalyticsKpi("Alarm rate", self._v(summary, "alarmRatePerDay"), "alarms/day", c["alarm"], "Alarm", "stable"),
            AnalyticsKpi("System availability", self._v(summary, "systemAvailabilityPct"), "%", c["good"], "All system", "stable"),
            AnalyticsKpi("Energy balance error", self._v(summary, "balanceErrorPct"), "%", "#facc15", "All system", "stable"),
        ]
        bess_kpis = [
            AnalyticsKpi("Energy charged", self._v(summary, "bessChargeMwh"), "MWh", c["bess"], "BESS"),
            AnalyticsKpi("Energy discharged", self._v(summary, "bessDischargeMwh"), "MWh", c["bess"], "BESS"),
            AnalyticsKpi("Round-trip efficiency", self._v(summary, "bessEfficiencyPct"), "%", c["good"], "BESS"),
            AnalyticsKpi("Average SOC", self._v(summary, "avgSocPct"), "%", c["bess"], "BESS"),
            AnalyticsKpi("Minimum SOC", self._v(summary, "minSocPct"), "%", "#facc15", "BESS"),
            AnalyticsKpi("Maximum SOC", self._v(summary, "maxSocPct"), "%", c["good"], "BESS"),
            AnalyticsKpi("Equivalent full cycles", self._v(summary, "equivalentCycles"), "", c["bess"], "BESS"),
            AnalyticsKpi("BESS availability", self._v(summary, "bessAvailabilityPct"), "%", c["good"], "BESS"),
            AnalyticsKpi("Chg/Dis/Standby", self._v(summary, "bessModeText"), "", c["muted"], "BESS"),
            AnalyticsKpi("SOC violations", self._v(summary, "socViolationCount"), "", c["alarm"], "BESS"),
        ]
        pv_kpis = [
            AnalyticsKpi("PV generation", self._v(summary, "pvMwh"), "MWh", c["pv"], "PV"),
            AnalyticsKpi("PV peak power", self._v(summary, "pvPeakMw"), "MW", c["pv"], "PV"),
            AnalyticsKpi("PV capacity factor", self._v(summary, "pvCapacityFactorPct"), "%", c["pv"], "PV"),
            AnalyticsKpi("PV self-consumption", self._v(summary, "pvSelfConsumptionPct"), "%", c["good"], "PV"),
            AnalyticsKpi("PV curtailment", self._v(summary, "pvCurtailmentMwh"), "MWh", "#f97316", "PV"),
            AnalyticsKpi("Forecast delta", self._v(summary, "pvForecastDeltaPct"), "%", "#facc15", "PV"),
            AnalyticsKpi("Weather impact index", self._v(summary, "weatherImpactIndex"), "%", "#38bdf8", "PV"),
        ]
        grid_kpis = [
            AnalyticsKpi("Grid import", self._v(summary, "gridImportMwh"), "MWh", c["grid"], "Grid"),
            AnalyticsKpi("Grid export", self._v(summary, "gridExportMwh"), "MWh", "#38bdf8", "Grid"),
            AnalyticsKpi("Net import", self._v(summary, "netImportMwh"), "MWh", c["grid"], "Grid"),
            AnalyticsKpi("Peak import", self._v(summary, "peakImportMw"), "MW", "#facc15", "Grid"),
            AnalyticsKpi("Zero export violations", self._v(summary, "zeroExportViolationCount"), "", c["alarm"], "Grid"),
            AnalyticsKpi("Grid outage duration", self._v(summary, "gridOutageHours"), "h", c["alarm"], "Grid"),
            AnalyticsKpi("Import/export ratio", self._v(summary, "importExportRatio"), "", c["grid"], "Grid"),
        ]
        load_kpis = [
            AnalyticsKpi("Peak demand", self._v(summary, "peakDemandMw"), "MW", c["load"], "Load"),
            AnalyticsKpi("Base load", self._v(summary, "baseLoadMw"), "MW", c["load"], "Load"),
            AnalyticsKpi("Load factor", self._v(summary, "loadFactorPct"), "%", c["good"], "Load"),
            AnalyticsKpi("Critical load", self._v(summary, "criticalLoadMwh"), "MWh", c["alarm"], "Load"),
            AnalyticsKpi("Non-critical load", self._v(summary, "nonCriticalLoadMwh"), "MWh", c["load"], "Load"),
            AnalyticsKpi("Load shedding", self._v(summary, "loadShedMwh"), "MWh", c["alarm"], "Load"),
            AnalyticsKpi("Average PF", self._v(summary, "avgPowerFactor"), "", "#facc15", "Load"),
        ]
        alarm_kpis = [
            AnalyticsKpi("Total alarms", self._v(summary, "totalAlarms"), "", c["alarm"], "Alarm"),
            AnalyticsKpi("Critical alarms", self._v(summary, "criticalAlarms"), "", c["alarm"], "Alarm"),
            AnalyticsKpi("Fault alarms", self._v(summary, "faultAlarms"), "", "#f97316", "Alarm"),
            AnalyticsKpi("Warning alarms", self._v(summary, "warningAlarms"), "", "#facc15", "Alarm"),
            AnalyticsKpi("Average ACK time", self._v(summary, "avgAckMinutes"), "min", c["alarm"], "Alarm"),
            AnalyticsKpi("Top alarm source", self._v(summary, "topAlarmSource"), "", c["muted"], "Alarm"),
            AnalyticsKpi("Repeated alarms", self._v(summary, "repeatedAlarmCount"), "", c["alarm"], "Alarm"),
        ]
        return {
            "all": all_kpis,
            "bess": bess_kpis,
            "pv": pv_kpis,
            "grid": grid_kpis,
            "load": load_kpis,
            "alarm": alarm_kpis,
        }

    def _bess(self, samples: list[dict], alarms: list[dict], step_hours: float) -> BessAnalytics:
        summary = self._summary(samples, alarms, step_hours, [])
        modes = self._mode_hours(samples, step_hours)
        histogram = [
            {"label": "Charge", "value": round(modes["charge"], 2), "color": "#38bdf8"},
            {"label": "Discharge", "value": round(modes["discharge"], 2), "color": "#22c55e"},
            {"label": "Standby", "value": round(modes["standby"], 2), "color": "#64748b"},
        ]
        return BessAnalytics(
            metrics=self._kpis(samples, alarms, step_hours, [])["bess"][:8],
            socTrend=[{"label": s["timeLabel"], "value": s["socPct"]} for s in samples if s.get("socKnown", True)],
            chargeDischargeHistogram=histogram,
            socOperatingBand={
                "min": 20,
                "max": 90,
                "timeBelow20Hours": round(sum(step_hours for s in samples if s.get("socKnown", True) and s["socPct"] < 20), 2),
                "timeAbove90Hours": round(sum(step_hours for s in samples if s.get("socKnown", True) and s["socPct"] > 90), 2),
                "throughputMwh": round((summary["bessChargeMwh"] or 0.0) + (summary["bessDischargeMwh"] or 0.0), 2),
            },
            alarmCorrelation=self._alarm_correlation(alarms, "BESS"),
        )

    def _pv(self, samples: list[dict], step_hours: float) -> PvAnalytics:
        alarms: list[dict] = []
        summary = self._summary(samples, alarms, step_hours, [])
        return PvAnalytics(
            metrics=self._kpis(samples, alarms, step_hours, [])["pv"],
            generationTrend=[
                ({"label": s["timeLabel"], "actual": s["pvMw"]} if self._live
                 else {"label": s["timeLabel"], "actual": s["pvMw"], "forecast": s["pvForecastMw"]})
                for s in samples
            ],
            forecastVsActual=(
                [{"label": s["timeLabel"], "actual": s["pvMw"]} for s in samples] if self._live
                else [{"label": s["timeLabel"], "actual": s["pvMw"], "forecast": s["pvForecastMw"]} for s in samples if s["pvForecastMw"] > 0.1]
            ),
            energyRouting=[
                {"label": "PV to load", "value": round(summary["pvToLoadMwh"] or 0.0, 2), "color": "#22c55e"},
                {"label": "PV to BESS", "value": round(summary["pvToBessMwh"] or 0.0, 2), "color": "#38bdf8"},
                {"label": "PV export", "value": round(min(summary["pvMwh"] or 0.0, summary["gridExportMwh"] or 0.0), 2), "color": "#60a5fa"},
            ] + ([] if summary["pvCurtailmentMwh"] is None else [
                {"label": "Curtailment", "value": round(summary["pvCurtailmentMwh"], 2), "color": "#f97316"},
            ]),
            irradianceCorrelation=[] if self._live else [{"label": s["timeLabel"], "pvMw": s["pvMw"], "irradiance": s["irradianceWm2"]} for s in samples],
        )

    def _grid(self, samples: list[dict], step_hours: float) -> GridAnalytics:
        alarms: list[dict] = []
        summary = self._summary(samples, alarms, step_hours, [])
        peak_events = sorted(samples, key=lambda s: s["gridMw"], reverse=True)[:5]
        return GridAnalytics(
            metrics=self._kpis(samples, alarms, step_hours, [])["grid"],
            importExportTrend=[{"label": s["timeLabel"], "importMw": max(0, s["gridMw"]), "exportMw": max(0, -s["gridMw"])} for s in samples],
            peakImportEvents=[{"time": s["timeLabel"], "value": s["gridMw"], "action": "Discharge BESS for peak shaving"} for s in peak_events if s["gridMw"] > 0],
            outageTimeline=[] if self._live else [{"time": s["timeLabel"], "durationMin": 60 * step_hours, "note": "Grid outage"} for s in samples if s["gridOutage"]],
            powerQualitySummary=[] if self._live else [
                {"label": "Voltage avg", "value": round(sum(s["voltageKv"] for s in samples) / max(1, len(samples)), 2), "unit": "kV"},
                {"label": "Frequency avg", "value": round(sum(s["frequencyHz"] for s in samples) / max(1, len(samples)), 2), "unit": "Hz"},
                {"label": "Power factor avg", "value": summary["avgPowerFactor"], "unit": ""},
            ],
        )

    def _load(self, samples: list[dict], step_hours: float) -> LoadAnalytics:
        alarms: list[dict] = []
        summary = self._summary(samples, alarms, step_hours, [])
        profile = defaultdict(list)
        for s in samples:
            profile[s["timeLabel"][:2]].append(s["loadMw"])
        return LoadAnalytics(
            metrics=self._kpis(samples, alarms, step_hours, [])["load"],
            demandTrend=[{"label": s["timeLabel"], "loadMw": s["loadMw"], "pf": s["powerFactor"]} for s in samples],
            dailyProfile=[{"hour": hour, "value": round(sum(values) / len(values), 2)} for hour, values in sorted(profile.items())],
            loadSheddingEvents=[] if self._live else [{"time": s["timeLabel"], "value": s["loadShedMw"], "action": "Restore non-critical load when reserve returns"} for s in samples if s["loadShedMw"] > 0],
        )

    def _alarm(self, alarms: list[dict], samples: list[dict]) -> AlarmAnalytics:
        by_level = Counter(a["level"] for a in alarms)
        by_source = Counter(a["source"] for a in alarms)
        by_code = Counter(a["code"] for a in alarms)
        heat = Counter(a["timeLabel"][:2] for a in alarms)
        return AlarmAnalytics(
            metrics=self._kpis(samples, alarms, 1.0, [])["alarm"],
            countByLevel=[{"label": k, "value": v, "color": self._level_color(k)} for k, v in by_level.items()],
            countBySource=[{"label": k, "value": v} for k, v in by_source.most_common(8)],
            topRepeatedAlarms=[{"code": k, "count": v} for k, v in by_code.most_common(6)],
            timeline=[{"time": a["timeLabel"], "source": a["source"], "level": a["level"], "code": a["code"]} for a in alarms[:80]],
            heatmap=[{"hour": hour, "value": value} for hour, value in sorted(heat.items())],
        )

    def _summary(self, samples: list[dict], alarms: list[dict], step_hours: float, balance: list[EnergyBalancePoint]) -> dict:
        hours = max(step_hours, len(samples) * step_hours)
        n = max(1, len(samples))
        days = max(1.0 / 24.0, hours / 24.0)
        pv_mwh = sum(max(0, s["pvMw"]) * step_hours for s in samples)
        load_mwh = sum(max(0, s["loadMw"] - s["loadShedMw"]) * step_hours for s in samples)
        grid_import_mwh = sum(max(0, s["gridMw"]) * step_hours for s in samples)
        grid_export_mwh = sum(max(0, -s["gridMw"]) * step_hours for s in samples)
        bess_charge_mwh = sum(max(0, -s["bessMw"]) * step_hours for s in samples)
        bess_discharge_mwh = sum(max(0, s["bessMw"]) * step_hours for s in samples)
        pv_curtailment_mwh = sum(max(0, s["pvCurtailmentMw"]) * step_hours for s in samples)
        pv_forecast_mwh = sum(max(0, s["pvForecastMw"]) * step_hours for s in samples)
        load_shed_mwh = sum(max(0, s["loadShedMw"]) * step_hours for s in samples)
        critical_load_mwh = sum(s["criticalLoadMw"] * step_hours for s in samples)
        non_critical_load_mwh = sum(s["nonCriticalLoadMw"] * step_hours for s in samples)
        total_generation = pv_mwh + bess_discharge_mwh + grid_import_mwh
        renewable = min(100.0, (pv_mwh + bess_discharge_mwh) / max(0.01, load_mwh) * 100.0)
        grid_dep = grid_import_mwh / max(0.01, load_mwh) * 100.0
        self_sufficiency = max(0.0, 100.0 - grid_dep)
        peak = max((s.get("peakLoadMw", s["loadMw"]) for s in samples), default=0.0)
        base = min((s["loadMw"] for s in samples), default=0.0)
        avg_load = sum(s["loadMw"] for s in samples) / n
        modes = self._mode_hours(samples, step_hours)
        soc_values = [s["socPct"] for s in samples if s.get("socKnown", True)] or [0.0]
        level_counts = Counter(a["level"] for a in alarms)
        source_counts = Counter(a["source"] for a in alarms)
        code_counts = Counter(a["code"] for a in alarms)
        grid_outage_h = sum(step_hours for s in samples if s["gridOutage"])
        balance_error = sum(row.balanceErrorPct for row in balance) / len(balance) if balance else 0.0
        if self._finance:  # sổ cái MySQL finance_agg_daily: cùng nguồn với Overview/Energy Balance
            fin = self._finance
            pv_mwh, load_mwh = fin["pv"], fin["load"]
            grid_import_mwh, grid_export_mwh = fin["grid_in"], fin["grid_export"]
            bess_charge_mwh, bess_discharge_mwh = fin["bess_charge"], fin["bess_dis"]
            total_generation = pv_mwh + bess_discharge_mwh + grid_import_mwh
            renewable = min(100.0, (pv_mwh + bess_discharge_mwh) / max(0.01, load_mwh) * 100.0)
            grid_dep = grid_import_mwh / max(0.01, load_mwh) * 100.0
            self_sufficiency = max(0.0, 100.0 - grid_dep)
        # PV đi đâu: suy từ số đo thật (export lấy từ PV trước, phần còn lại nạp BESS, còn lại cấp tải)
        pv_exported = min(pv_mwh, grid_export_mwh)
        pv_to_bess = min(bess_charge_mwh, max(0.0, pv_mwh - pv_exported))
        pv_to_load = max(0.0, pv_mwh - pv_exported - pv_to_bess)
        capacity = self._capacity_mwh if self._live else 20.0
        out = {
            "totalGenerationMwh": round(total_generation, 2),
            "loadMwh": round(load_mwh, 2),
            "renewableFractionPct": round(renewable, 1),
            "gridDependencyPct": round(grid_dep, 1),
            "selfSufficiencyPct": round(self_sufficiency, 1),
            "peakDemandMw": round(peak, 2),
            "baseLoadMw": round(base, 2),
            "peakShavingMwh": round(min(bess_discharge_mwh, max(0.0, peak - avg_load) * hours * 0.22), 2),
            "alarmRatePerDay": round(len(alarms) / days, 1),
            "systemAvailabilityPct": round(max(88.0, 100.0 - grid_outage_h / max(0.01, hours) * 100.0 - len(alarms) * 0.015), 2),
            "balanceErrorPct": round(balance_error, 2),
            "bessChargeMwh": round(bess_charge_mwh, 2),
            "bessDischargeMwh": round(bess_discharge_mwh, 2),
            "bessEfficiencyPct": round(min(96.0, bess_discharge_mwh / max(0.01, bess_charge_mwh) * 100.0), 1),
            "avgSocPct": round(sum(soc_values) / len(soc_values), 1),
            "minSocPct": round(min(soc_values), 1),
            "maxSocPct": round(max(soc_values), 1),
            "equivalentCycles": round((bess_charge_mwh + bess_discharge_mwh) / (2.0 * capacity), 2) if capacity else None,
            "bessAvailabilityPct": round(max(88.0, 99.6 - level_counts.get("Critical", 0) * 0.08), 2),
            "bessModeText": f"{modes['charge']:.1f}/{modes['discharge']:.1f}/{modes['standby']:.1f} h",
            "socViolationCount": sum(1 for s in samples if s.get("socKnown", True) and (s["socPct"] < 20 or s["socPct"] > 90)),
            "pvMwh": round(pv_mwh, 2),
            "pvPeakMw": round(max((s["pvMw"] for s in samples), default=0.0), 2),
            "pvCapacityFactorPct": round(pv_mwh / max(0.01, 5.2 * hours) * 100.0, 1),
            "pvSelfConsumptionPct": round(pv_to_load / max(0.01, pv_mwh) * 100.0, 1),
            "pvCurtailmentMwh": round(pv_curtailment_mwh, 2),
            "pvForecastDeltaPct": round((pv_mwh - pv_forecast_mwh) / max(0.01, pv_forecast_mwh) * 100.0, 1),
            "weatherImpactIndex": round(max(0.0, min(100.0, 100.0 - pv_mwh / max(0.01, pv_forecast_mwh) * 100.0)), 1),
            "pvToLoadMwh": round(pv_to_load, 2),
            "pvToBessMwh": round(pv_to_bess, 2),
            "gridImportMwh": round(grid_import_mwh, 2),
            "gridExportMwh": round(grid_export_mwh, 2),
            "netImportMwh": round(grid_import_mwh - grid_export_mwh, 2),
            "peakImportMw": round(max((max(0, s["gridMw"]) for s in samples), default=0.0), 2),
            "zeroExportViolationCount": sum(1 for s in samples if s["zeroExportViolation"]),
            "gridOutageHours": round(grid_outage_h, 2),
            "importExportRatio": round(grid_import_mwh / max(0.01, grid_export_mwh), 2),
            "loadFactorPct": round(avg_load / max(0.01, peak) * 100.0, 1),
            "criticalLoadMwh": round(critical_load_mwh, 2),
            "nonCriticalLoadMwh": round(non_critical_load_mwh, 2),
            "loadShedMwh": round(load_shed_mwh, 2),
            "avgPowerFactor": round(sum(s["powerFactor"] for s in samples) / n, 3),
            "totalAlarms": len(alarms),
            "criticalAlarms": level_counts.get("Critical", 0),
            "faultAlarms": level_counts.get("Fault", 0),
            "warningAlarms": level_counts.get("Warning", 0),
            "avgAckMinutes": self._avg_ack_minutes(alarms),
            "topAlarmSource": source_counts.most_common(1)[0][0] if source_counts else "--",
            "repeatedAlarmCount": sum(count for _, count in code_counts.items() if count > 1),
        }
        for key in self._unavailable:
            if key in out:
                out[key] = None
        return out

    @staticmethod
    def _avg_ack_minutes(alarms: list[dict]):
        acked = [a["ackSeconds"] for a in alarms if a.get("ackSeconds") is not None]
        if not acked:
            return None if any(a.get("ackSeconds") is None for a in alarms) and alarms else 0.0
        return round(sum(acked) / len(acked) / 60.0, 1)

    def _mode_hours(self, samples: list[dict], step_hours: float) -> dict:
        return {
            "charge": sum(step_hours for s in samples if s["bessMw"] < -0.08),
            "discharge": sum(step_hours for s in samples if s["bessMw"] > 0.08),
            "standby": sum(step_hours for s in samples if abs(s["bessMw"]) <= 0.08),
        }

    def _alarm_correlation(self, alarms: list[dict], source: str) -> list[dict]:
        by_code = Counter(a["code"] for a in alarms if a["source"] == source)
        return [{"code": code, "count": count} for code, count in by_code.most_common(5)]

    def _level_color(self, level: str) -> str:
        return {"Critical": "#ef4444", "Fault": "#f97316", "Warning": "#facc15", "Info": "#38bdf8"}.get(level, "#94a3b8")

    def _asset_key(self, asset_type: str) -> str:
        return {
            "All system": "all",
            "BESS": "bess",
            "PV": "pv",
            "Grid": "grid",
            "Load": "load",
            "PCS": "pcs",
            "Transformer": "transformer",
        }.get(asset_type, "all")
