"""Dựng dataset cho tab Analytics từ nguồn THẬT (cùng hợp đồng với AnalyticsSimulator.generate()).

Nguồn dữ liệu:
- Công suất PV/Load/BESS/Grid, peak demand  -> HistorianService (Influx power_rollup)
- Tổng năng lượng theo ngày                   -> EventDataService.get_finance_agg_range (MySQL finance_agg_daily)
- Alarm (level/source/ack/duration)           -> EventDataService.get_alarms (MySQL alarms + alarm_history)
- SOC BESS                                    -> Influx BAT_VF_01 (L.SOC, tecu=255) của từng container

Chính sách "không giả dữ liệu": trường nào không có nguồn đo thật (forecast, curtailment, PF, load shedding,
điện áp/tần số lịch sử...) KHÔNG được bịa số; tên KPI tương ứng được đưa vào `unavailable` để calculator
hiển thị "--".
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta

from backend.models.analytics import AnalyticsFilter
from backend.services.historian.historian_service import PLANT_LOCAL_TZ, to_query_iso

logger = logging.getLogger(__name__)

_BESS_SOURCE_TYPE = "_CFG_PWRSRCTYPE_BESS"
_BESS_PACK_MEASUREMENT = "BAT_VF_01"
_BESS_PACK_TECU = "255"
_SOC_FIELD = "L.SOC"
_SOC_SCALE = 0.1
_SOC_QUERY_STEP_SECONDS = 3600

# Các KPI/summary key KHÔNG có nguồn thật ở chế độ live.
ALWAYS_UNAVAILABLE = frozenset({
    "peakShavingMwh",           # công thức ước lượng, không đo được
    "systemAvailabilityPct",    # không có nguồn availability
    "bessAvailabilityPct",
    "pvCapacityFactorPct",      # cần công suất PV lắp đặt đáng tin cậy
    "pvCurtailmentMwh",         # không có tag curtailment
    "pvForecastDeltaPct",       # forecast nằm ở tab Forecast (flex_psg), chưa nối vào đây
    "weatherImpactIndex",
    "zeroExportViolationCount",
    "gridOutageHours",
    "criticalLoadMwh",          # không tách critical/non-critical trong historian
    "nonCriticalLoadMwh",
    "loadShedMwh",
    "avgPowerFactor",           # không có PF lịch sử
})

SOC_KEYS = frozenset({
    "avgSocPct", "minSocPct", "maxSocPct", "socViolationCount",
})
CAPACITY_KEYS = frozenset({"equivalentCycles"})


def _parse_dt(text) -> datetime | None:
    if not text:
        return None
    text = str(text).strip()
    try:
        dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        dt = None
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M:%S.%f"):
            try:
                dt = datetime.strptime(text, fmt)
                break
            except ValueError:
                continue
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=PLANT_LOCAL_TZ)
    return dt.astimezone(PLANT_LOCAL_TZ)


class LiveAnalyticsDatasetBuilder:

    def __init__(self, topology_vm, historian_service, event_service, influx_client=None, settings_vm=None):
        self._topology_vm = topology_vm
        self._historian = historian_service
        self._events = event_service
        self._influx = influx_client
        self._settings_vm = settings_vm

    # ------------------------------------------------------------------ public
    def build(self, analytics_filter: AnalyticsFilter) -> dict:
        topology = self._topology_vm.topology_model if self._topology_vm is not None else None
        grid_id = self._topology_vm.selectedGridId if self._topology_vm is not None else 0
        now = datetime.now(PLANT_LOCAL_TZ)
        start, end, windows, step_hours, bucket = self._plan(analytics_filter, now)

        rows: list[dict] = []
        if topology is not None:
            rows = self._power_rows(grid_id, topology, windows, start, end, step_hours)
        alarms = self._alarms(topology, grid_id, start, end) if topology is not None else []

        unavailable = set(ALWAYS_UNAVAILABLE)
        soc_by_index = self._soc_by_sample(topology, grid_id, rows, step_hours)
        capacity_mwh = self._bess_capacity_mwh(topology, grid_id)
        if not soc_by_index:
            unavailable |= SOC_KEYS
        if capacity_mwh is None:
            unavailable |= CAPACITY_KEYS

        samples = [self._sample(i, row, soc_by_index.get(i), bucket) for i, row in enumerate(rows)]
        finance = self._finance_totals(grid_id, start, end) if step_hours >= 24.0 or analytics_filter.timeRange in ("Today", "Yesterday") else None

        # historian + alarm đều trả [] ở lần gọi đầu (refresh nền) -> báo cho VM retry
        pending = bool(topology is not None and not rows)
        return {
            "filter": analytics_filter,
            "samples": samples,
            "alarms": alarms,
            "stepHours": step_hours,
            "energyBucket": bucket,
            "unavailable": unavailable,
            "bessCapacityMwh": capacity_mwh,
            "financeTotals": finance,
            "pending": pending,
            "live": True,
        }

    # ------------------------------------------------------------------ range planning
    def _plan(self, f: AnalyticsFilter, now: datetime):
        """-> (start, end, [(historian_range, anchor, bucket_hours)], step_hours, 'hour'|'day')"""
        today0 = now.replace(hour=0, minute=0, second=0, microsecond=0)
        name = f.timeRange
        if name == "Today":
            return today0, now, [("Today", now, 1)], 1.0, "hour"
        if name == "Yesterday":
            y0 = today0 - timedelta(days=1)
            return y0, today0 - timedelta(seconds=1), [("Today", y0 + timedelta(hours=12), 1)], 1.0, "hour"
        if name == "Last 7 days":
            return today0 - timedelta(days=6), now, [("Last 7 days", now, 24)], 24.0, "day"
        if name == "This month":
            return today0.replace(day=1), now, [("This month", now, 24)], 24.0, "day"
        if name == "Last month":
            last_end = today0.replace(day=1) - timedelta(seconds=1)
            first = last_end.replace(day=1, hour=0, minute=0, second=0)
            return first, last_end, [("This month", first + timedelta(days=1), 24)], 24.0, "day"
        if name == "Custom range":
            start = _parse_dt(f.fromTime) or today0
            end = _parse_dt(f.toTime) or now
            if end - start <= timedelta(hours=48):
                windows, cursor = [], start.replace(hour=0, minute=0, second=0, microsecond=0)
                while cursor <= end:
                    windows.append(("Today", cursor + timedelta(hours=12), 1))
                    cursor += timedelta(days=1)
                return start, end, windows, 1.0, "hour"
            windows, cursor = [], start.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            while cursor <= end:
                windows.append(("This month", cursor + timedelta(days=1), 24))
                cursor = (cursor.replace(day=28) + timedelta(days=4)).replace(day=1)
            return start, end, windows, 24.0, "day"
        # Realtime: 24h gần nhất, độ phân giải 1h (độ mịn nhất mà rollup có)
        start = now - timedelta(hours=24)
        return start, now, [("Today", now - timedelta(days=1), 1), ("Today", now, 1)], 1.0, "hour"

    # ------------------------------------------------------------------ power rows
    def _power_rows(self, grid_id, topology, windows, start, end, step_hours) -> list[dict]:
        power: dict[str, object] = {}
        demand: dict[str, float] = {}
        for range_name, anchor, _ in windows:
            for p in self._historian.get_power_history(grid_id, topology, range_name, anchor):
                power[p.timestamp] = p
            for p in self._historian.get_demand_history(grid_id, topology, range_name, anchor):
                demand[p.timestamp] = p.load_mw
        rows = []
        for ts in sorted(power):
            p = power[ts]
            dt = _parse_dt(ts)
            if dt is None or not (start - timedelta(hours=step_hours) < dt <= end):
                continue
            if not p.has_data:
                continue  # bucket không có dữ liệu thật: bỏ, không vẽ số 0 giả
            rows.append({"dt": dt, "p": p, "peak": demand.get(ts, p.load_mw)})
        return rows

    def _sample(self, index: int, row: dict, soc, bucket: str) -> dict:
        dt, p = row["dt"], row["p"]
        label = dt.strftime("%H:%M") if bucket == "hour" else dt.strftime("%d/%m %Hh")
        period = dt.strftime("%H:00") if bucket == "hour" else dt.strftime("%d/%m")
        grid_mw = p.grid_mw
        return {
            "timestamp": dt.isoformat(timespec="minutes"),
            "timeLabel": label,
            "periodLabel": period,
            "loadMw": p.load_mw,
            "peakLoadMw": max(row["peak"], 0.0),
            "criticalLoadMw": 0.0,
            "nonCriticalLoadMw": 0.0,
            "pvMw": p.pv_mw,
            "pvForecastMw": 0.0,
            "pvCurtailmentMw": 0.0,
            "bessMw": p.bess_mw,
            "gridMw": grid_mw,
            "socPct": soc if soc is not None else 0.0,
            "socKnown": soc is not None,
            "irradianceWm2": 0.0,
            "moduleTempC": 0.0,
            "gridImportLimitMw": 0.0,
            "gridExportLimitMw": 0.0,
            "gridOutage": False,
            "zeroExportViolation": False,
            "loadShedMw": 0.0,
            "voltageKv": 0.0,
            "frequencyHz": 0.0,
            "powerFactor": 0.0,
            "transformerLoadingPct": 0.0,
            "temperatureC": 0.0,
        }

    # ------------------------------------------------------------------ alarms (MySQL)
    def _alarms(self, topology, grid_id, start, end) -> list[dict]:
        raw = self._events.get_alarms(
            topology, limit=2000, start_ms=int(start.timestamp() * 1000), end_ms=int(end.timestamp() * 1000)
        )
        out = []
        for a in raw:
            if a.get("gridId") not in (grid_id, None):
                continue
            t0 = _parse_dt(a.get("timestamp"))
            t_ack = _parse_dt(a.get("ackTime"))
            t_clear = _parse_dt(a.get("clearTime"))
            ack_s = (t_ack - t0).total_seconds() if t0 and t_ack and t_ack >= t0 else None
            dur_min = (t_clear - t0).total_seconds() / 60.0 if t0 and t_clear and t_clear >= t0 else None
            out.append({
                "id": a.get("id", ""),
                "timestamp": t0.isoformat(timespec="minutes") if t0 else "",
                "timeLabel": t0.strftime("%H:%M") if t0 else "--",
                "source": a.get("source") or "EMS",
                "code": a.get("code") or "",
                "level": a.get("level") or "Info",
                "description": a.get("description") or "",
                "ackSeconds": ack_s,
                "durationMinutes": dur_min,
            })
        return out

    # ------------------------------------------------------------------ finance ledger (MySQL)
    def _finance_totals(self, grid_id, start, end) -> dict | None:
        try:
            by_day = self._events.get_finance_agg_range(grid_id, start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d"))
        except Exception:
            logger.exception("get_finance_agg_range failed")
            return None
        if not by_day:
            return None
        keys = ("pv", "grid_in", "grid_export", "bess_charge", "bess_dis", "load")
        totals = {k: 0.0 for k in keys}
        for row in by_day.values():
            for k in keys:
                totals[k] += float(row.get(k) or 0.0)
        return {k: v / 1000.0 for k, v in totals.items()}  # kWh -> MWh

    # ------------------------------------------------------------------ BESS SOC / capacity
    def _bess_sources(self, topology, grid_id):
        group_ids = {g.id for g in topology.groups_by_grid(grid_id)}
        return [s for s in topology.power_sources if s.type == _BESS_SOURCE_TYPE and s.group_id in group_ids]

    def _bess_capacity_mwh(self, topology, grid_id) -> float | None:
        if topology is None or self._settings_vm is None:
            return None
        try:
            per = float(self._settings_vm.getSettings("bess").get("energyPerContainerMwh"))
        except (TypeError, ValueError, AttributeError):
            return None
        count = len(self._bess_sources(topology, grid_id))
        return per * count if count and per > 0 else None

    def _soc_by_sample(self, topology, grid_id, rows, step_hours) -> dict[int, float]:
        if not rows or self._influx is None or topology is None:
            return {}
        first = rows[0]["dt"]
        last = rows[-1]["dt"] + timedelta(hours=step_hours)
        tips = []
        for src in self._bess_sources(topology, grid_id):
            devs = topology.devices_by_source(src.id, enabled_only=False)
            dev = next((d for d in devs if d.type.startswith("_DEVCFG_DEVTYPE_BAT")), devs[0] if devs else None)
            if dev and dev.address:
                tips.append(dev.address)
        if not tips:
            return {}
        starts = [r["dt"] for r in rows]
        acc: dict[int, list[float]] = {}
        for tip in tips:
            tip_value = tip if tip.startswith('"') else f'"{tip}"'
            try:
                pts = self._influx.query_range_grouped_by_time(
                    _BESS_PACK_MEASUREMENT, to_query_iso(first), to_query_iso(last),
                    {"Tip": tip_value, "Tecu": _BESS_PACK_TECU},
                    fields=[_SOC_FIELD], interval_seconds=_SOC_QUERY_STEP_SECONDS,
                )
            except Exception:
                logger.exception("SOC query failed tip=%s", tip)
                continue
            for pt in pts:
                value, ts = pt.get(_SOC_FIELD), _parse_dt(pt.get("time"))
                if value is None or ts is None:
                    continue
                idx = self._sample_index(starts, ts, step_hours)
                if idx is not None:
                    acc.setdefault(idx, []).append(float(value) * _SOC_SCALE)
        return {i: sum(v) / len(v) for i, v in acc.items()}  # trung bình các container (SOC %, không phải tổng)

    @staticmethod
    def _sample_index(starts: list[datetime], ts: datetime, step_hours: float) -> int | None:
        width = timedelta(hours=step_hours)
        for i in range(len(starts) - 1, -1, -1):
            if starts[i] <= ts < starts[i] + width:
                return i
        return None
