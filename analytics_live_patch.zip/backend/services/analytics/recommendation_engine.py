from __future__ import annotations

from backend.models.analytics import AnalyticsFilter, RecommendationInsight


def _g(summary: dict, key: str, default):
    """KPI không có nguồn thật được calculator đặt None -> coi như không có để không kích hoạt luật sai."""
    value = summary.get(key)
    return default if value is None else value


class RecommendationEngine:

    def generate(self, summary: dict, analytics_filter: AnalyticsFilter, alarm_analytics: dict | None = None) -> list[RecommendationInsight]:
        insights: list[RecommendationInsight] = []
        if _g(summary, "peakImportMw", 0) > 3.1:
            insights.append(
                RecommendationInsight(
                    priority="High",
                    relatedAsset="Grid/BESS",
                    title="Peak import high in evening window",
                    description=f"Peak grid import reached {summary['peakImportMw']:.2f} MW while peak demand was {summary['peakDemandMw']:.2f} MW.",
                    suggestedAction="Discharge BESS 1.2-1.8 MW during 18:00-20:00 and keep SOC reserve before evening peak.",
                    expectedImpact="Reduce peak import by about 15-25%.",
                    confidencePct=88.0,
                )
            )
        if _g(summary, "minSocPct", 100) < 22:
            insights.append(
                RecommendationInsight(
                    priority="High",
                    relatedAsset="BESS",
                    title="SOC frequently low",
                    description=f"Minimum SOC dropped to {summary['minSocPct']:.1f}%, increasing backup risk.",
                    suggestedAction="Increase reserve SOC setpoint and charge earlier during PV surplus.",
                    expectedImpact="Improve backup availability and reserve margin.",
                    confidencePct=90.0,
                )
            )
        if _g(summary, "equivalentCycles", None) is not None and _g(summary, "equivalentCycles", 0) < 0.15 and _g(summary, "peakDemandMw", 0) > 3.4:
            insights.append(
                RecommendationInsight(
                    priority="Medium",
                    relatedAsset="BESS",
                    title="BESS under-utilized for peak shaving",
                    description="BESS cycle estimate is low while load peak remains high.",
                    suggestedAction="Enable peak-shaving dispatch with SOC floor protection.",
                    expectedImpact="Increase BESS value and reduce demand charge/grid dependency.",
                    confidencePct=76.0,
                )
            )
        if _g(summary, "pvCurtailmentMwh", 0) > max(0.5, _g(summary, "pvMwh", 0) * 0.04):
            insights.append(
                RecommendationInsight(
                    priority="Medium",
                    relatedAsset="PV/BESS",
                    title="PV curtailment elevated",
                    description=f"Estimated curtailment is {summary['pvCurtailmentMwh']:.2f} MWh.",
                    suggestedAction="Leave more BESS headroom before solar noon or shift flexible loads into PV hours.",
                    expectedImpact="Recover 3-8% of curtailed PV energy.",
                    confidencePct=82.0,
                )
            )
        if _g(summary, "pvSelfConsumptionPct", 100) < 68:
            insights.append(
                RecommendationInsight(
                    priority="Medium",
                    relatedAsset="PV/Load",
                    title="PV self-consumption ratio low",
                    description=f"PV self-consumption is {summary['pvSelfConsumptionPct']:.1f}%.",
                    suggestedAction="Charge BESS earlier and move non-critical load to high PV window.",
                    expectedImpact="Reduce export and grid import later in the day.",
                    confidencePct=78.0,
                )
            )
        if _g(summary, "zeroExportViolationCount", 0) > 0:
            insights.append(
                RecommendationInsight(
                    priority="High",
                    relatedAsset="Grid/PV",
                    title="Zero export violations detected",
                    description=f"{summary['zeroExportViolationCount']} export limit violations were detected.",
                    suggestedAction="Check zero-export controller, PV curtailment command and meter sign convention.",
                    expectedImpact="Avoid utility compliance violation.",
                    confidencePct=86.0,
                )
            )
        if _g(summary, "avgPowerFactor", 1.0) < 0.91:
            insights.append(
                RecommendationInsight(
                    priority="Medium",
                    relatedAsset="PCS/PV inverter/Load",
                    title="Power factor below target",
                    description=f"Average power factor is {summary['avgPowerFactor']:.3f}.",
                    suggestedAction="Use PCS/PV inverter Q control or capacitor compensation during low PF periods.",
                    expectedImpact="Improve power quality and reduce apparent power loading.",
                    confidencePct=74.0,
                )
            )
        if _g(summary, "loadShedMwh", 0) > 0:
            insights.append(
                RecommendationInsight(
                    priority="High",
                    relatedAsset="Load/Grid",
                    title="Load shedding occurred",
                    description=f"Estimated load shedding energy is {summary['loadShedMwh']:.2f} MWh.",
                    suggestedAction="Review reserve margin and non-critical load restoration policy.",
                    expectedImpact="Reduce interruption of non-critical load.",
                    confidencePct=88.0,
                )
            )
        if _g(summary, "criticalAlarms", 0) > 0 and _g(summary, "avgAckMinutes", 0) > 12:
            insights.append(
                RecommendationInsight(
                    priority="High",
                    relatedAsset="Alarm",
                    title="Critical alarm acknowledgement too slow",
                    description=f"Average ACK time is {summary['avgAckMinutes']:.1f} minutes with {summary['criticalAlarms']} critical alarm(s).",
                    suggestedAction="Review alarm routing, operator response workflow and escalation matrix.",
                    expectedImpact="Reduce operational risk during fault conditions.",
                    confidencePct=84.0,
                )
            )
        if not insights:
            insights.append(
                RecommendationInsight(
                    priority="Low",
                    relatedAsset="All system",
                    title="Operation within target envelope",
                    description="No major efficiency or reliability issue was detected for the selected range.",
                    suggestedAction="Continue normal EMS optimization and monitor PV/BESS schedule.",
                    expectedImpact="Maintain stable operation.",
                    confidencePct=72.0,
                )
            )

        filtered = self._filter_by_asset(insights, analytics_filter.assetType)
        return filtered[:8]

    def _filter_by_asset(self, insights: list[RecommendationInsight], asset_type: str) -> list[RecommendationInsight]:
        if asset_type == "All system":
            return insights
        if asset_type == "PCS":
            aliases = {"PCS", "BESS", "Grid", "PV inverter"}
        elif asset_type == "Transformer":
            aliases = {"Transformer", "Grid", "Load", "PV", "BESS"}
        else:
            aliases = {asset_type}
        filtered = [item for item in insights if any(alias in item.relatedAsset for alias in aliases)]
        return filtered or insights[:3]
