from __future__ import annotations

from dataclasses import asdict, dataclass, field


def to_map(value):
    if hasattr(value, "__dataclass_fields__"):
        return asdict(value)
    if isinstance(value, list):
        return [to_map(item) for item in value]
    if isinstance(value, dict):
        return {key: to_map(item) for key, item in value.items()}
    return value


@dataclass
class AnalyticsFilter:
    timeRange: str = "Realtime"
    assetType: str = "All system"
    timezone: str = "Asia/Ho_Chi_Minh"
    fromTime: str = ""
    toTime: str = ""
    valid: bool = True
    message: str = "Filter ready"


@dataclass
class AnalyticsKpi:
    label: str
    value: float | str
    unit: str
    accent: str
    asset: str = "All system"
    trend: str = "stable"
    note: str = ""


@dataclass
class PowerTrendPoint:
    timestamp: str
    timeLabel: str
    loadMw: float
    pvMw: float
    bessMw: float
    gridMw: float
    socPct: float | None
    peakDemandMw: float
    gridImportLimitMw: float
    gridExportLimitMw: float


@dataclass
class EnergyBalancePoint:
    periodLabel: str
    pvGenerationMwh: float
    gridImportMwh: float
    bessDischargeMwh: float
    loadConsumptionMwh: float
    bessChargeMwh: float
    gridExportMwh: float
    lossMwh: float
    balanceErrorPct: float


@dataclass
class BessAnalytics:
    metrics: list[AnalyticsKpi] = field(default_factory=list)
    socTrend: list[dict] = field(default_factory=list)
    chargeDischargeHistogram: list[dict] = field(default_factory=list)
    socOperatingBand: dict = field(default_factory=dict)
    alarmCorrelation: list[dict] = field(default_factory=list)


@dataclass
class PvAnalytics:
    metrics: list[AnalyticsKpi] = field(default_factory=list)
    generationTrend: list[dict] = field(default_factory=list)
    forecastVsActual: list[dict] = field(default_factory=list)
    energyRouting: list[dict] = field(default_factory=list)
    irradianceCorrelation: list[dict] = field(default_factory=list)


@dataclass
class GridAnalytics:
    metrics: list[AnalyticsKpi] = field(default_factory=list)
    importExportTrend: list[dict] = field(default_factory=list)
    peakImportEvents: list[dict] = field(default_factory=list)
    outageTimeline: list[dict] = field(default_factory=list)
    powerQualitySummary: list[dict] = field(default_factory=list)


@dataclass
class LoadAnalytics:
    metrics: list[AnalyticsKpi] = field(default_factory=list)
    demandTrend: list[dict] = field(default_factory=list)
    dailyProfile: list[dict] = field(default_factory=list)
    loadSheddingEvents: list[dict] = field(default_factory=list)


@dataclass
class AlarmAnalytics:
    metrics: list[AnalyticsKpi] = field(default_factory=list)
    countByLevel: list[dict] = field(default_factory=list)
    countBySource: list[dict] = field(default_factory=list)
    topRepeatedAlarms: list[dict] = field(default_factory=list)
    timeline: list[dict] = field(default_factory=list)
    heatmap: list[dict] = field(default_factory=list)


@dataclass
class RecommendationInsight:
    priority: str
    relatedAsset: str
    title: str
    description: str
    suggestedAction: str
    expectedImpact: str
    confidencePct: float


@dataclass
class AnalyticsSnapshot:
    filter: AnalyticsFilter
    analyticsKpi: dict[str, list[AnalyticsKpi]]
    powerTrendData: list[PowerTrendPoint]
    energyBalanceData: list[EnergyBalancePoint]
    bessAnalytics: BessAnalytics
    pvAnalytics: PvAnalytics
    gridAnalytics: GridAnalytics
    loadAnalytics: LoadAnalytics
    alarmAnalytics: AlarmAnalytics
    recommendationInsights: list[RecommendationInsight]
