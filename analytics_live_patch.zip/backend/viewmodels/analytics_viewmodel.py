from __future__ import annotations

import copy
import csv
import logging
import threading
from dataclasses import asdict
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import Property, QObject, QTimer, Signal, Slot

from backend.services.analytics.calculator import AnalyticsCalculator
from backend.models.analytics import AnalyticsFilter, to_map
from backend.services.config.export_paths_service import export_subdir
from backend.services.simulators.analytics_simulator import AnalyticsSimulator
from backend.services.analytics.live_dataset_builder import LiveAnalyticsDatasetBuilder
from backend.services.analytics.recommendation_engine import RecommendationEngine

logger = logging.getLogger(__name__)

_LIVE_POLL_MS = 30000        # rollup Influx chỉ cập nhật mỗi ~30s (rollup_daemon), poll nhanh hơn là vô ích
_SIM_POLL_MS = 5000
_MAX_PENDING_RETRIES = 6     # historian/MySQL trả rỗng ở lần gọi đầu (refresh nền) -> thử lại
_RETRY_DELAY_MS = 1500


class AnalyticsViewModel(QObject):

    analyticsUpdated = Signal()
    filterChanged = Signal()
    recommendationUpdated = Signal()
    exportCompleted = Signal(str)
    errorChanged = Signal()
    loadingChanged = Signal()
    _buildReady = Signal(int, object)

    def __init__(
        self,
        topology_vm=None,
        historian_service=None,
        event_service=None,
        influx_client=None,
        settings_vm=None,
        live: bool = False,
    ):
        super().__init__()
        self._filter = AnalyticsFilter()
        self._simulator = AnalyticsSimulator()
        # live=True: đọc historian (Influx power_rollup) + MySQL (alarms, finance_agg_daily) + Influx (SOC).
        # live=False: giữ simulator để app chạy được khi không có hạ tầng.
        self._topology_vm = topology_vm
        self._builder = (
            LiveAnalyticsDatasetBuilder(topology_vm, historian_service, event_service, influx_client, settings_vm)
            if live and topology_vm is not None and historian_service is not None and event_service is not None
            else None
        )
        self._generation = 0
        self._busy = False
        self._pending_job = None
        self._job_lock = threading.Lock()
        self._retries = 0
        self._last_summary: dict = {}
        self._last_alarm_analytics: dict = {}
        self._buildReady.connect(self._apply_result)
        if self._builder is not None and hasattr(topology_vm, "selectedGridChanged"):
            topology_vm.selectedGridChanged.connect(self.refreshAnalytics)
        self._calculator = AnalyticsCalculator()
        self._recommendation_engine = RecommendationEngine()
        self._all_kpis: dict = {}
        self._analytics_kpi: list[dict] = []
        self._power_trend_data: list[dict] = []
        self._energy_balance_data: list[dict] = []
        self._bess_analytics: dict = {}
        self._pv_analytics: dict = {}
        self._grid_analytics: dict = {}
        self._load_analytics: dict = {}
        self._alarm_analytics: dict = {}
        self._recommendation_insights: list[dict] = []
        self._last_error = ""
        self._loading = False
        self._timer = QTimer(self)
        self._timer.setInterval(_LIVE_POLL_MS if self._builder is not None else _SIM_POLL_MS)
        self._timer.timeout.connect(self._refresh_realtime)
        self._timer.start()
        self.refreshAnalytics()

    @Property("QVariant", notify=filterChanged)
    def analyticsFilter(self):
        return asdict(self._filter)

    @Property("QVariant", notify=analyticsUpdated)
    def analyticsKpi(self):
        return copy.deepcopy(self._analytics_kpi)

    @Property("QVariant", notify=analyticsUpdated)
    def powerTrendData(self):
        return copy.deepcopy(self._power_trend_data)

    @Property("QVariant", notify=analyticsUpdated)
    def energyBalanceData(self):
        return copy.deepcopy(self._energy_balance_data)

    @Property("QVariant", notify=analyticsUpdated)
    def bessAnalytics(self):
        return copy.deepcopy(self._bess_analytics)

    @Property("QVariant", notify=analyticsUpdated)
    def pvAnalytics(self):
        return copy.deepcopy(self._pv_analytics)

    @Property("QVariant", notify=analyticsUpdated)
    def gridAnalytics(self):
        return copy.deepcopy(self._grid_analytics)

    @Property("QVariant", notify=analyticsUpdated)
    def loadAnalytics(self):
        return copy.deepcopy(self._load_analytics)

    @Property("QVariant", notify=analyticsUpdated)
    def alarmAnalytics(self):
        return copy.deepcopy(self._alarm_analytics)

    @Property("QVariant", notify=recommendationUpdated)
    def recommendationInsights(self):
        return copy.deepcopy(self._recommendation_insights)

    @Property(bool, constant=True)
    def live(self):
        return self._builder is not None

    @Property(str, notify=errorChanged)
    def lastError(self):
        return self._last_error

    @Property(bool, notify=loadingChanged)
    def loading(self):
        return self._loading

    @Slot("QVariant", result=bool)
    def setTimeRange(self, rangeObject):
        payload = self._plain(rangeObject)
        next_filter = copy.deepcopy(self._filter)
        if isinstance(payload, str):
            next_filter.timeRange = payload
        elif isinstance(payload, dict):
            next_filter.timeRange = str(payload.get("timeRange", payload.get("range", next_filter.timeRange)))
            next_filter.fromTime = str(payload.get("fromTime", payload.get("from", next_filter.fromTime)))
            next_filter.toTime = str(payload.get("toTime", payload.get("to", next_filter.toTime)))
            next_filter.timezone = str(payload.get("timezone", next_filter.timezone))
        else:
            self._set_error("Time range must be a string or object")
            return False

        next_filter.valid, next_filter.message = self._validate_range(next_filter)
        self._filter = next_filter
        self.filterChanged.emit()
        if not self._filter.valid:
            self._set_error(self._filter.message)
            return False
        self._set_error("")
        self.refreshAnalytics()
        return True

    @Slot(str, result=bool)
    def setAssetFilter(self, assetType):
        allowed = ["All system", "BESS", "PV", "Grid", "PCS", "Transformer", "Load", "Alarm"]
        asset = str(assetType)
        if asset not in allowed:
            self._set_error(f"Unsupported asset filter: {asset}")
            return False
        self._filter.assetType = asset
        self.filterChanged.emit()
        self._refresh_filtered_views()
        return True

    @Slot()
    def refreshAnalytics(self):
        self._retries = 0
        self._refresh()

    def _refresh(self):
        if not self._filter.valid:
            self._set_error(self._filter.message)
            return
        if self._builder is None:
            self._refresh_simulator()
            return
        self._set_loading(True)
        self._generation += 1
        job = (self._generation, copy.deepcopy(self._filter))
        with self._job_lock:
            if self._busy:
                self._pending_job = job   # chỉ giữ job mới nhất
                return
            self._busy = True
        self._start_job(job)

    def _start_job(self, job):
        threading.Thread(target=self._run_job, args=job, daemon=True, name="analytics-live").start()

    def _run_job(self, generation: int, analytics_filter: AnalyticsFilter):
        try:
            dataset = self._builder.build(analytics_filter)
            calculated = self._calculator.calculate(dataset)
            payload = {"dataset": dataset, "calculated": calculated}
        except Exception as exc:
            logger.exception("Analytics live build failed")
            payload = {"error": f"Analytics refresh failed: {exc}"}
        with self._job_lock:
            nxt, self._pending_job = self._pending_job, None
            if nxt is None:
                self._busy = False
        self._buildReady.emit(generation, payload)
        if nxt is not None:
            self._start_job(nxt)

    def _apply_result(self, generation: int, payload: dict):
        if generation != self._generation:
            return  # kết quả cũ: đã có yêu cầu mới hơn
        if "error" in payload:
            self._set_error(payload["error"])
            self._set_loading(False)
            return
        dataset, calculated = payload["dataset"], payload["calculated"]
        has_data = bool(dataset["samples"])
        if dataset.get("pending") and self._retries < _MAX_PENDING_RETRIES:
            self._retries += 1
            QTimer.singleShot(_RETRY_DELAY_MS, self._refresh)
            return  # giữ trạng thái loading, historian đang nạp nền
        self._publish(calculated, has_data)
        if has_data:
            self._set_error("")
        else:
            self._set_error("No historian data for the selected range (Influx power_rollup / rollup_daemon)")
        self._set_loading(False)

    def _refresh_simulator(self):
        self._set_loading(True)
        try:
            dataset = self._simulator.generate(self._filter)
            calculated = self._calculator.calculate(dataset)
            self._publish(calculated, True)
            self._set_error("")
        except Exception as exc:
            self._set_error(f"Analytics refresh failed: {exc}")
        finally:
            self._set_loading(False)

    def _publish(self, calculated: dict, has_data: bool):
        self._all_kpis = calculated["analyticsKpi"]
        self._power_trend_data = to_map(calculated["powerTrendData"])
        self._energy_balance_data = to_map(calculated["energyBalanceData"])
        self._bess_analytics = to_map(calculated["bessAnalytics"])
        self._pv_analytics = to_map(calculated["pvAnalytics"])
        self._grid_analytics = to_map(calculated["gridAnalytics"])
        self._load_analytics = to_map(calculated["loadAnalytics"])
        self._alarm_analytics = to_map(calculated["alarmAnalytics"])
        self._last_summary = calculated["summary"]
        self._analytics_kpi = to_map(self._calculator.visible_kpis(self._all_kpis, self._filter))
        # không có số liệu -> không đưa khuyến nghị "mọi thứ bình thường" gây hiểu lầm
        insights = self._recommendation_engine.generate(self._last_summary, self._filter, self._alarm_analytics) if has_data else []
        self._recommendation_insights = to_map(insights)
        self.analyticsUpdated.emit()
        self.recommendationUpdated.emit()

    @Slot(result="QVariant")
    def getAnalyticsKpi(self):
        return self.analyticsKpi

    @Slot(result="QVariant")
    def getPowerTrendData(self):
        return self.powerTrendData

    @Slot(result="QVariant")
    def getEnergyBalanceData(self):
        return self.energyBalanceData

    @Slot(result="QVariant")
    def getBessAnalytics(self):
        return self.bessAnalytics

    @Slot(result="QVariant")
    def getPvAnalytics(self):
        return self.pvAnalytics

    @Slot(result="QVariant")
    def getGridAnalytics(self):
        return self.gridAnalytics

    @Slot(result="QVariant")
    def getLoadAnalytics(self):
        return self.loadAnalytics

    @Slot(result="QVariant")
    def getAlarmAnalytics(self):
        return self.alarmAnalytics

    @Slot(result="QVariant")
    def getRecommendationInsights(self):
        return self.recommendationInsights

    @Slot(str, result=str)
    def exportAnalyticsCsv(self, filePath):
        path = self._resolve_export_path(filePath)
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(["Section", "Label", "Value", "Unit", "Asset", "Note"])
            for kpi in self._analytics_kpi:
                writer.writerow(["KPI", kpi.get("label", ""), kpi.get("value", ""), kpi.get("unit", ""), kpi.get("asset", ""), kpi.get("note", "")])
            writer.writerow([])
            writer.writerow(["PowerTrend", "Timestamp", "Load MW", "PV MW", "BESS MW", "Grid MW", "SOC %"])
            for row in self._power_trend_data:
                writer.writerow(["PowerTrend", row.get("timestamp", ""), row.get("loadMw", ""), row.get("pvMw", ""), row.get("bessMw", ""), row.get("gridMw", ""), row.get("socPct", "")])
            writer.writerow([])
            writer.writerow(["EnergyBalance", "Period", "PV", "Grid Import", "BESS Discharge", "Load", "BESS Charge", "Grid Export", "Loss", "Error %"])
            for row in self._energy_balance_data:
                writer.writerow([
                    "EnergyBalance",
                    row.get("periodLabel", ""),
                    row.get("pvGenerationMwh", ""),
                    row.get("gridImportMwh", ""),
                    row.get("bessDischargeMwh", ""),
                    row.get("loadConsumptionMwh", ""),
                    row.get("bessChargeMwh", ""),
                    row.get("gridExportMwh", ""),
                    row.get("lossMwh", ""),
                    row.get("balanceErrorPct", ""),
                ])
            writer.writerow([])
            writer.writerow(["Insight", "Priority", "Asset", "Title", "Suggested Action", "Expected Impact", "Confidence %"])
            for item in self._recommendation_insights:
                writer.writerow(["Insight", item.get("priority", ""), item.get("relatedAsset", ""), item.get("title", ""), item.get("suggestedAction", ""), item.get("expectedImpact", ""), item.get("confidencePct", "")])
        self.exportCompleted.emit(str(path))
        return str(path)

    def _refresh_filtered_views(self):
        if not self._all_kpis:
            self.refreshAnalytics()
            return
        if self._builder is not None:
            # dữ liệu không đổi theo asset filter: chỉ lọc lại KPI + khuyến nghị, không query lại hạ tầng
            self._analytics_kpi = to_map(self._calculator.visible_kpis(self._all_kpis, self._filter))
            has_data = bool(self._power_trend_data)
            insights = self._recommendation_engine.generate(self._last_summary, self._filter, self._alarm_analytics) if has_data else []
            self._recommendation_insights = to_map(insights)
            self.analyticsUpdated.emit()
            self.recommendationUpdated.emit()
            return
        self._analytics_kpi = to_map(self._calculator.visible_kpis(self._all_kpis, self._filter))
        self.analyticsUpdated.emit()
        self.refreshAnalytics()

    def _refresh_realtime(self):
        if self._filter.timeRange == "Realtime":
            self._retries = 0
            self._refresh()

    def _validate_range(self, analytics_filter: AnalyticsFilter) -> tuple[bool, str]:
        if analytics_filter.timeRange != "Custom range":
            return True, f"{analytics_filter.timeRange} · {analytics_filter.timezone}"
        if not analytics_filter.fromTime or not analytics_filter.toTime:
            return False, "Custom range requires fromTime and toTime"
        try:
            from_time = datetime.fromisoformat(analytics_filter.fromTime)
            to_time = datetime.fromisoformat(analytics_filter.toTime)
        except ValueError:
            return False, "Custom range expects ISO datetime values"
        if from_time > to_time:
            return False, "Custom range invalid: fromTime must be <= toTime"
        return True, f"Custom range · {analytics_filter.timezone}"

    def _resolve_export_path(self, file_path: str) -> Path:
        if file_path:
            path = Path(file_path)
            if path.suffix.lower() != ".csv":
                path = path.with_suffix(".csv")
        else:
            export_dir = export_subdir("analytics_export")
            path = export_dir / f"analytics_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    def _set_error(self, message: str):
        if self._last_error == message:
            return
        self._last_error = message
        self.errorChanged.emit()

    def _set_loading(self, value: bool):
        if self._loading == value:
            return
        self._loading = value
        self.loadingChanged.emit()

    def _plain(self, value):
        if hasattr(value, "toVariant"):
            value = value.toVariant()
        if isinstance(value, dict):
            return {str(key): self._plain(item) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [self._plain(item) for item in value]
        return value
