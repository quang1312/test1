import QtQuick

Rectangle {
    id: root
    property var points: []
    property bool showLoad: true
    property bool showPv: true
    property bool showBess: true
    property bool showGrid: true
    property int hoverIndex: -1
    property real hoverX: 0
    property real hoverY: 0

    radius: 8
    color: "#0a1524"
    border.color: "#1e3a5f"
    border.width: 1
    clip: true

    readonly property var series: [
        { key: "loadMw", label: "Load", color: "#a78bfa", enabled: showLoad },
        { key: "pvMw", label: "PV", color: "#facc15", enabled: showPv },
        { key: "bessMw", label: "BESS", color: "#38bdf8", enabled: showBess },
        { key: "gridMw", label: "Grid", color: "#60a5fa", enabled: showGrid }
    ]

    function setSeries(label) {
        if (label === "Load")
            showLoad = !showLoad;
        else if (label === "PV")
            showPv = !showPv;
        else if (label === "BESS")
            showBess = !showBess;
        else if (label === "Grid")
            showGrid = !showGrid;
        chart.requestPaint();
    }

    function value(row, key) {
        return Number(row && row[key] !== undefined ? row[key] : 0);
    }

    onPointsChanged: chart.requestPaint()
    onWidthChanged: chart.requestPaint()
    onHeightChanged: chart.requestPaint()

    Column {
        anchors.fill: parent
        anchors.margins: 14
        spacing: 8

        Item {
            id: chartHeader
            width: parent.width
            height: Math.max(titleBlock.implicitHeight, legendFlow.y + legendFlow.implicitHeight)
            readonly property real titleWidth: Math.min(260, Math.max(210, width * 0.38))
            readonly property real legendX: titleWidth + 14
            readonly property real legendWidth: Math.max(1, width - legendX)
            readonly property real buttonWidth: Math.max(58, Math.min(70, (legendWidth - 32) / 5))

            Column {
                id: titleBlock
                width: chartHeader.titleWidth
                spacing: 2
                Text {
                    width: parent.width
                    text: "POWER TREND CHART"
                    color: "#38bdf8"
                    font.pixelSize: 14
                    font.bold: true
                    elide: Text.ElideRight
                }
                Text {
                    text: "BESS: negative charge, positive discharge · Grid: positive import, negative export"
                    color: "#94a3b8"
                    font.pixelSize: 10
                    elide: Text.ElideRight
                    width: parent.width
                }
            }

            Flow {
                id: legendFlow
                x: chartHeader.legendX
                y: 3
                width: chartHeader.legendWidth
                spacing: 8

                Repeater {
                    model: root.series
                    delegate: Rectangle {
                        required property var modelData
                        width: chartHeader.buttonWidth
                        height: 26
                        radius: 7
                        color: modelData.enabled ? modelData.color + "33" : "#07111f"
                        border.color: modelData.enabled ? modelData.color : "#1e293b"
                        Text {
                            anchors.centerIn: parent
                            text: modelData.label
                            color: modelData.enabled ? modelData.color : "#94a3b8"
                            font.pixelSize: 10
                            font.bold: modelData.enabled
                        }
                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: root.setSeries(modelData.label)
                        }
                    }
                }
            }
        }

        Canvas {
            id: chart
            width: parent.width
            height: Math.max(1, parent.height - chartHeader.height - parent.spacing)

            onPaint: {
                var ctx = getContext("2d");
                ctx.clearRect(0, 0, width, height);
                var data = root.points || [];
                var left = 54;
                var right = width - 26;
                var top = 16;
                var bottom = height - 34;
                ctx.fillStyle = "#07111f";
                ctx.fillRect(left, top, right - left, bottom - top);
                ctx.strokeStyle = "#1e3a5f";
                ctx.strokeRect(left, top, right - left, bottom - top);
                if (data.length < 2) {
                    ctx.fillStyle = "#94a3b8";
                    ctx.textAlign = "center";
                    ctx.fillText("No trend data", width / 2, height / 2);
                    return;
                }
                var minV = -1;
                var maxV = 1;
                for (var i = 0; i < data.length; i++) {
                    maxV = Math.max(maxV, data[i].loadMw || 0, data[i].pvMw || 0, data[i].bessMw || 0, data[i].gridMw || 0, data[i].gridImportLimitMw || 0, data[i].peakDemandMw || 0);
                    minV = Math.min(minV, data[i].bessMw || 0, data[i].gridMw || 0, data[i].gridExportLimitMw || 0);
                }
                maxV = Math.ceil(maxV + 0.5);
                minV = Math.floor(minV - 0.5);
                function xFor(index) { return left + index / Math.max(1, data.length - 1) * (right - left); }
                function yFor(value) { return bottom - (value - minV) / Math.max(0.001, maxV - minV) * (bottom - top); }
                ctx.font = "10px sans-serif";
                ctx.textAlign = "right";
                ctx.textBaseline = "middle";
                for (var gy = 0; gy <= 4; gy++) {
                    var y = top + gy / 4 * (bottom - top);
                    ctx.strokeStyle = "#16263b";
                    ctx.beginPath();
                    ctx.moveTo(left, y);
                    ctx.lineTo(right, y);
                    ctx.stroke();
                    ctx.fillStyle = "#64748b";
                    ctx.fillText((maxV - gy / 4 * (maxV - minV)).toFixed(1), left - 8, y);
                }
                var zeroY = yFor(0);
                ctx.strokeStyle = "#e2e8f055";
                ctx.beginPath();
                ctx.moveTo(left, zeroY);
                ctx.lineTo(right, zeroY);
                ctx.stroke();
                ctx.textAlign = "center";
                ctx.textBaseline = "top";
                var step = Math.max(1, Math.ceil(data.length / 8));
                for (var gx = 0; gx < data.length; gx += step) {
                    var tx = xFor(gx);
                    ctx.fillStyle = "#64748b";
                    ctx.fillText(data[gx].timeLabel || "", tx, bottom + 9);
                }
                function drawLine(key, color, enabled, dashed) {
                    if (!enabled)
                        return;
                    ctx.beginPath();
                    ctx.strokeStyle = color;
                    ctx.lineWidth = dashed ? 1.4 : 2.3;
                    ctx.setLineDash(dashed ? [6, 5] : []);
                    for (var j = 0; j < data.length; j++) {
                        var x = xFor(j);
                        var yv = yFor(root.value(data[j], key));
                        if (j === 0)
                            ctx.moveTo(x, yv);
                        else
                            ctx.lineTo(x, yv);
                    }
                    ctx.stroke();
                    ctx.setLineDash([]);
                }
                for (var s = 0; s < root.series.length; s++)
                    drawLine(root.series[s].key, root.series[s].color, root.series[s].enabled, false);
                drawLine("peakDemandMw", "#ef4444", true, true);
                var hasLimits = false;
                for (var li = 0; li < data.length; li++) {
                    if (data[li].gridImportLimitMw || data[li].gridExportLimitMw) { hasLimits = true; break; }
                }
                if (hasLimits) {
                    drawLine("gridImportLimitMw", "#facc15", true, true);
                    drawLine("gridExportLimitMw", "#facc15", true, true);
                }
                if (root.hoverIndex >= 0 && root.hoverIndex < data.length) {
                    var hx = xFor(root.hoverIndex);
                    root.hoverX = hx;
                    root.hoverY = yFor(data[root.hoverIndex].loadMw || 0);
                    ctx.strokeStyle = "#f8fafc";
                    ctx.beginPath();
                    ctx.moveTo(hx, top);
                    ctx.lineTo(hx, bottom);
                    ctx.stroke();
                }
            }

            MouseArea {
                anchors.fill: parent
                hoverEnabled: true
                onPositionChanged: function(mouse) {
                    var left = 54;
                    var right = chart.width - 26;
                    var data = root.points || [];
                    if (data.length < 2 || mouse.x < left || mouse.x > right) {
                        root.hoverIndex = -1;
                    } else {
                        root.hoverIndex = Math.max(0, Math.min(data.length - 1, Math.round((mouse.x - left) / Math.max(1, right - left) * (data.length - 1))));
                    }
                    chart.requestPaint();
                }
                onExited: {
                    root.hoverIndex = -1;
                    chart.requestPaint();
                }
            }
        }
    }

    Rectangle {
        visible: root.hoverIndex >= 0 && root.points && root.hoverIndex < root.points.length
        width: 226
        height: 112
        radius: 8
        x: Math.min(Math.max(root.hoverX + 20, 10), root.width - width - 10)
        y: 58
        color: "#020617"
        border.color: "#38bdf8"
        z: 20
        Column {
            anchors.fill: parent
            anchors.margins: 10
            spacing: 3
            Text { width: parent.width; text: visible ? root.points[root.hoverIndex].timeLabel : ""; color: "#f8fafc"; font.pixelSize: 12; font.bold: true }
            Text { width: parent.width; text: visible ? "Load " + Number(root.points[root.hoverIndex].loadMw || 0).toFixed(2) + " MW · PV " + Number(root.points[root.hoverIndex].pvMw || 0).toFixed(2) + " MW" : ""; color: "#cbd5e1"; font.pixelSize: 10 }
            Text { width: parent.width; text: visible ? "BESS " + Number(root.points[root.hoverIndex].bessMw || 0).toFixed(2) + " MW · Grid " + Number(root.points[root.hoverIndex].gridMw || 0).toFixed(2) + " MW" : ""; color: "#cbd5e1"; font.pixelSize: 10 }
            Text { width: parent.width; text: visible ? "SOC " + (root.points[root.hoverIndex].socPct === null || root.points[root.hoverIndex].socPct === undefined ? "--" : Number(root.points[root.hoverIndex].socPct).toFixed(1) + "%") : ""; color: "#94a3b8"; font.pixelSize: 10 }
            Text { width: parent.width; text: "Dashed: peak demand and grid import/export limits"; color: "#64748b"; font.pixelSize: 9; elide: Text.ElideRight }
        }
    }
}

