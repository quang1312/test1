import QtQuick

Rectangle {
    id: root
    property var analyticsData: ({})

    radius: 8
    color: "#0a1524"
    border.color: "#1e3a5f"
    border.width: 1
    clip: true

    onAnalyticsDataChanged: pvChart.requestPaint()

    ScrollablePanelBody {
        anchors.fill: parent
        anchors.margins: 6
        spacing: 3

        Text { width: parent.width; text: "PV ANALYTICS"; color: "#facc15"; font.pixelSize: 13; font.bold: true; elide: Text.ElideRight }

        Row {
            width: parent.width
            height: 38
            spacing: 6
            Repeater {
                model: (root.analyticsData.metrics || []).slice(0, 3)
                delegate: MetricTile {
                    required property var modelData
                    width: (parent.width - 12) / 3
                    height: parent.height
                    label: modelData.label
                    value: modelData.value
                    unit: modelData.unit
                    accent: modelData.accent
                }
            }
        }

        Canvas {
            id: pvChart
            width: parent.width
            height: 42
            onPaint: {
                var ctx = getContext("2d");
                ctx.clearRect(0, 0, width, height);
                var points = root.analyticsData.forecastVsActual || root.analyticsData.generationTrend || [];
                ctx.fillStyle = "#07111f";
                ctx.fillRect(0, 0, width, height);
                ctx.strokeStyle = "#1e293b";
                ctx.strokeRect(0, 0, width, height);
                if (points.length < 2)
                    return;
                var maxV = 1;
                for (var i = 0; i < points.length; i++)
                    maxV = Math.max(maxV, points[i].actual || 0, points[i].forecast || 0);
                function xFor(i) { return 8 + i / Math.max(1, points.length - 1) * (width - 16); }
                function yFor(v) { return height - 8 - (v / maxV) * (height - 16); }
                function draw(key, color, dash) {
                    ctx.strokeStyle = color;
                    ctx.lineWidth = 2;
                    ctx.setLineDash(dash ? [5, 4] : []);
                    ctx.beginPath();
                    for (var j = 0; j < points.length; j++) {
                        var x = xFor(j);
                        var y = yFor(points[j][key] || 0);
                        if (j === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
                    }
                    ctx.stroke();
                    ctx.setLineDash([]);
                }
                var hasForecast = false;
                for (var f = 0; f < points.length; f++) {
                    if (points[f].forecast !== undefined && points[f].forecast !== null) { hasForecast = true; break; }
                }
                if (hasForecast)
                    draw("forecast", "#94a3b8", true);
                draw("actual", "#facc15", false);
            }
        }

        Row {
            width: parent.width
            height: 36
            spacing: 6
            Repeater {
                model: root.analyticsData.energyRouting || []
                delegate: Rectangle {
                    required property var modelData
                    width: (parent.width - 18) / 4
                    height: parent.height
                    radius: 6
                    color: "#07111f"
                    border.color: modelData.color || "#1e293b"
                    Column {
                        anchors.centerIn: parent
                        width: parent.width - 8
                        Text { width: parent.width; text: modelData.label; color: "#94a3b8"; font.pixelSize: 8; horizontalAlignment: Text.AlignHCenter; elide: Text.ElideRight }
                        Text { width: parent.width; text: Number(modelData.value || 0).toFixed(1) + " MWh"; color: modelData.color || "#cbd5e1"; font.pixelSize: 9; font.bold: true; horizontalAlignment: Text.AlignHCenter; elide: Text.ElideRight }
                    }
                }
            }
        }

        Text { width: parent.width; text: "Solid: actual PV · Dashed: forecast · routing includes direct load, BESS charge, export and curtailment"; color: "#94a3b8"; font.pixelSize: 10; elide: Text.ElideRight }
    }
}

