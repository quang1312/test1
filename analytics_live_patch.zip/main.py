# This Python file uses the following encoding: utf-8
# Khai báo encoding UTF-8 để hỗ trợ ký tự tiếng Việt và Unicode
from __future__ import annotations

import logging
import os
import sys
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtQml import QQmlApplicationEngine
from PySide6.QtQuickControls2 import QQuickStyle
from PySide6.QtWidgets import QApplication

from backend.services.logging_config import install_excepthook, setup_logging
from backend.viewmodels.alarm_viewmodel import AlarmViewModel           # Module cảnh báo theo dữ liệu MySQL thật
from backend.viewmodels.analytics_viewmodel import AnalyticsViewModel   # Module quản lý phân tích dữ liệu năng lượng
from backend.viewmodels.auth_viewmodel import AuthViewModel             # Module xác thực người dùng và phân quyền giao diện
from backend.viewmodels.event_viewmodel import EventViewModel           # Module quản lý sự kiện hệ thống
from backend.models.bess_data import BessDataStore
from backend.models.data import PmsDataStore
from backend.models.pcs_data import PcsDataStore
from backend.models.pqm_data import PqmDataStore
from backend.models.solar_data import SolarDataStore
from backend.viewmodels.report_viewmodel import ReportViewModel         # Module tạo và xuất báo cáo
from backend.services.config.database_settings_service import DatabaseSettingsService
from backend.services.events.event_data_service import MySqlEventService, SimulatorEventService
from backend.services.historian.historian_service import RollupHistorianService, SimulatorHistorianService
from backend.services.mysql.mysql_client import MySqlClient
from backend.services.nats.bess_nats_client import BessNatsClient
from backend.services.nats.nats_client import NatsClient
from backend.services.nats.simple_device_nats_client import SimpleDeviceNatsClient
from backend.services.config.pms_config_service import PmsConfigService
from backend.services.influx.influx_client import InfluxClient
from backend.services.rollup.rollup_store import GRANULARITY_DAY, GRANULARITY_HOUR, GRANULARITY_MONTH, InfluxRollupStore
from backend.services.realtime.realtime_service import NatsRealtimeService, SimulatorRealtimeService
from backend.viewmodels.settings_viewmodel import SettingsViewModel     # Module lưu/tải cấu hình người dùng
from backend.viewmodels.time_sync_viewmodel import TimeSyncViewModel    # Đồng bộ thời gian hệ thống qua GPS/NTP
from backend.viewmodels.battery_viewmodel import BatteryViewModel
from backend.viewmodels.energy_balance_viewmodel import EnergyBalanceViewModel
from backend.viewmodels.forecast_viewmodel import ForecastViewModel
from backend.viewmodels.overview_viewmodel import OverviewViewModel
from backend.viewmodels.pcs_viewmodel import PcsViewModel
from backend.viewmodels.pms_topology_viewmodel import PmsTopologyViewModel
from backend.viewmodels.power_monitoring_viewmodel import PowerMonitoringViewModel
from backend.viewmodels.site_facts_viewmodel import SiteFactsViewModel
from backend.viewmodels.sld_viewmodel import SldViewModel
from backend.viewmodels.weather_viewmodel import WeatherViewModel       # Module lấy dữ liệu thời tiết (bức xạ, nhiệt độ)
from backend.viewmodels.microgrid_viewmodels import (       # Backend mô phỏng dữ liệu EMS/HMI
    MaintenanceCommandViewModel,
    MicrogridAlarmViewModel,
    MicrogridLegacySldViewModel,
    MicrogridOverviewViewModel,
    MicrogridRealtimeViewModel,
)

# ─── Điểm vào ứng dụng (Entry Point) ───
if __name__ == "__main__":
    log_path = setup_logging()
    install_excepthook()
    app_logger = logging.getLogger("backend.app")

    from backend.build_info import BUILD_TIME, VERSION
    print(f"QT_dashboard_app {VERSION} (built {BUILD_TIME})")
    app_logger.info("Application startup version=%s build_time=%s log_file=%s", VERSION, BUILD_TIME, log_path)

    QQuickStyle.setStyle("Fusion")  # Chọn style Fusion cho QML Controls (không phụ thuộc OS)
    app = QApplication(sys.argv)  # Tạo ứng dụng Qt, nhận tham số dòng lệnh
    engine = QQmlApplicationEngine()                        # Engine nạp và hiển thị file QML
    engine.addImportPath(Path(__file__).parent)             # Thêm thư mục gốc dự án vào đường dẫn import QML

    # Khởi tạo tất cả backend Python – mỗi object tương ứng với một vùng chức năng của HMI
    microgrid_overview = MicrogridOverviewViewModel()         # Backend tab Tổng quan lưới điện
    microgrid_sld = MicrogridLegacySldViewModel(microgrid_overview) # Backend tab Sơ đồ đơn tuyến, đồng bộ nguồn mô phỏng
    microgrid_realtime = MicrogridRealtimeViewModel(microgrid_overview)  # Backend BESS / PCS / PV / Project đồng bộ source
    microgrid_alarm = MicrogridAlarmViewModel()               # Backend bảng cảnh báo
    settings_manager = SettingsViewModel()                    # Quản lý cài đặt người dùng
    auth_manager = AuthViewModel(settings_manager)             # Quản lý đăng nhập, phiên làm việc và quyền truy cập
    settings_manager.setAuthManager(auth_manager)            # Cho backend cài đặt kiểm tra quyền trước khi ghi dữ liệu
    time_sync_manager = TimeSyncViewModel(settings_manager)    # Đồng bộ thời gian qua GPS NTP
    weather_manager = WeatherViewModel()                      # Dữ liệu thời tiết và bức xạ
    site_facts_manager = SiteFactsViewModel()                 # Số liệu site tĩnh (diện tích, công suất lắp đặt...), hot-reload từ backend/config/site_facts.json
    maintenance_commands = MaintenanceCommandViewModel()      # Gửi lệnh điều khiển bảo trì
    pms_config_service = PmsConfigService()                 # Service đọc topology PMS từ pms_config.json

    # EMS_DATA_SOURCE=live dùng NATS/InfluxDB/MySQL (config/database_settings.json);
    # mặc định "simulator" để app luôn chạy được không cần hạ tầng thật.
    data_source = os.getenv("EMS_DATA_SOURCE", "live").strip().lower()
    bess_nats_client: BessNatsClient | None = None
    pcs_nats_client: SimpleDeviceNatsClient | None = None
    pqm_nats_client: SimpleDeviceNatsClient | None = None
    solar_nats_client: SimpleDeviceNatsClient | None = None
    nats_client: NatsClient | None = None
    if data_source == "live":
        db_settings = DatabaseSettingsService().load()
        nats_client = NatsClient(db_settings.nats)
        nats_client.start()
        mysql_client = MySqlClient(db_settings.mysql)
        realtime_service = NatsRealtimeService(nats_client)             # Nguồn realtime NATS
        influx_client = InfluxClient(db_settings.influx)
        historian_service = RollupHistorianService(
            InfluxRollupStore(influx_client, GRANULARITY_HOUR),
            InfluxRollupStore(influx_client, GRANULARITY_DAY),
            InfluxRollupStore(influx_client, GRANULARITY_MONTH),
        )
        event_service = MySqlEventService(mysql_client)                 # Nguồn alarm/event MySQL
        app_logger.info(
            "Config data_source=live nats=%s:%s influx=%s:%s mysql=%s:%s",
            db_settings.nats.host, db_settings.nats.port,
            db_settings.influx.host, db_settings.influx.port,
            db_settings.mysql.host, db_settings.mysql.port,
        )
    else:
        realtime_service = SimulatorRealtimeService()           # Nguồn realtime mô phỏng, thay được bằng NATS
        historian_service = SimulatorHistorianService()         # Nguồn chart mô phỏng, thay được bằng InfluxDB
        event_service = SimulatorEventService()                 # Nguồn alarm/event mô phỏng, thay được bằng MySQL
        app_logger.info("Config data_source=simulator")

    pms_data_store = PmsDataStore()                         # Current-state store theo Device/PwrSource/Grid
    pms_config = PmsTopologyViewModel(pms_config_service)   # ViewModel topology cho QML
    report_manager = ReportViewModel(                        # Tạo báo cáo định kỳ từ historian/alarm thật
        topology_vm=pms_config,
        historian_service=historian_service,
        event_service=event_service,
        auth_vm=auth_manager,
    )
    analytics_manager = AnalyticsViewModel(                  # Phân tích: live đọc historian/MySQL/Influx, simulator thì dùng số giả lập
        topology_vm=pms_config,
        historian_service=historian_service,
        event_service=event_service,
        influx_client=influx_client if data_source == "live" else None,  # SOC BESS: measurement BAT_VF_01 (L.SOC)
        settings_vm=settings_manager,                         # dung lượng BESS định mức (tính equivalent cycles)
        live=data_source == "live",
    )
    bess_store = BessDataStore()                             # Store cấp thiết bị BESS/BMS
    pcs_store = PcsDataStore()                               # Store cấp thiết bị PCS
    pqm_store = PqmDataStore()                               # Store cấp thiết bị đo đếm PQM (grid/bess/solar/load)
    solar_store = SolarDataStore()                           # Store cấp thiết bị Solar (PV)
    pms_runtime = OverviewViewModel(                        # ViewModel overview theo MainGrid được chọn
        topology_vm=pms_config,
        realtime_service=realtime_service,
        historian_service=historian_service,
        event_service=event_service,
        data_store=pms_data_store,
        pqm_store=pqm_store,                                   # voltage/current thật (Grid) cho bảng Realtime Monitoring
        solar_store=solar_store,                               # voltage/current thật (Solar, chỉ Huawei)
        bess_store=bess_store,                                 # voltage/current thật (BESS pack)
    )
    bess_pcs_fallback = microgrid_realtime if data_source != "live" else None
    pms_battery = BatteryViewModel(                         # ViewModel BESS theo config + data store
        topology_vm=pms_config,
        bess_store=bess_store,
        fallback_realtime=bess_pcs_fallback,
        event_service=event_service,                          # cross-check status với alarm MySQL active, cùng nguồn tab Cảnh báo
        nats_client=nats_client,
        settings_vm=settings_manager,                         # rated energy/container: đọc chung với trang Settings
        influx_client=influx_client if data_source == "live" else None,  # cell volt/temp: đọc measurement CellVolt/CellTemp
    )
    pms_pcs = PcsViewModel(                                  # ViewModel PCS theo config + data store
        topology_vm=pms_config,
        pcs_store=pcs_store,
        fallback_realtime=bess_pcs_fallback,
        event_service=event_service,
        nats_client=nats_client,
        realtime_service=realtime_service,      # fallback P/Q nhanh từ pwr_src_grp trong lúc chờ pcs0 riêng
        data_store=pms_data_store,
        settings_vm=settings_manager,           # rated power: đọc chung với trang Settings
        site_facts_vm=site_facts_manager,       # rtMvVoltageKv (gridVoltageKv): số tĩnh site_facts.json
        influx_client=influx_client if data_source == "live" else None,  # chart P/Q: đọc measurement system_snapshot
    )
    pms_sld = SldViewModel(                                  # ViewModel SLD theo MainGrid được chọn
        topology_vm=pms_config,
        realtime_service=realtime_service,
        data_store=pms_data_store,
        bess_store=bess_store,
        pcs_store=pcs_store,                                  # AC voltage BESS: đọc thật từ PCS trong group (line_voltage_ab_v)
        solar_store=solar_store,
        historian_service=historian_service,
        settings_vm=settings_manager,                         # PV inverter rated power: đọc chung với trang Settings
        site_facts_vm=site_facts_manager,                     # điện áp/tần số lưới: số tĩnh site_facts.json, không đo được ở mức bus tổng hợp
        event_service=event_service,                          # status Normal/Warning/Fault theo alarm MySQL active, cùng nguồn với tab Cảnh báo/PCS
        nats_client=nats_client,                               # heartbeat systemsts.dev.sts.<id> để phát hiện PV Offline, giống BESS/PCS
        influx_client=influx_client if data_source == "live" else None,  # chart P/Q PV: đọc measurement system_snapshot
    )
    pms_power_monitoring = PowerMonitoringViewModel(          # ViewModel tab Power Monitoring — PQM thật (grid/bess/solar/load)
        topology_vm=pms_config,
        pqm_store=pqm_store,
        influx_client=influx_client if data_source == "live" else None,  # trend 15m/1h: đọc measurement system_snapshot
        rollup_hourly=InfluxRollupStore(influx_client, GRANULARITY_HOUR) if data_source == "live" else None,
        rollup_daily=InfluxRollupStore(influx_client, GRANULARITY_DAY) if data_source == "live" else None,
    )
    if data_source == "live":
        bess_nats_client = BessNatsClient(                   # BAT_VF_01: brmu0/hvac0/chiller0/bcuN/bcuN.moduleM
            db_settings.nats,
            lambda: pms_config.topology_model,
            bess_store,
        )
        bess_nats_client.telemetryUpdated.connect(pms_battery.notify_data_changed)
        bess_nats_client.telemetryUpdated.connect(pms_sld.notify_data_changed)
        bess_nats_client.start()

        pcs_nats_client = SimpleDeviceNatsClient(            # PCS_VINFAST_TCP_SIM: display.dev.<id>.pcs0
            db_settings.nats, "pcs0", "PCS", "_DEVCFG_DEVTYPE_PCS",
            lambda: pms_config.topology_model,
            lambda source_id, device_id, fields: pcs_store.apply_nats_fields(source_id, device_id, fields),
            lambda source_id, device_id: pcs_store.clear(source_id, device_id),
        )
        pcs_nats_client.telemetryUpdated.connect(pms_pcs.notify_data_changed)
        pcs_nats_client.telemetryUpdated.connect(pms_sld.notify_data_changed)
        pcs_nats_client.start()

        pqm_nats_client = SimpleDeviceNatsClient(            # PQM_VINFAST_TCP_SIM: display.dev.<id>.pqm0
            db_settings.nats, "pqm0", "PQM", "_DEVCFG_DEVTYPE_PQM",
            lambda: pms_config.topology_model,
            lambda source_id, device_id, fields: pqm_store.apply_nats_fields(source_id, device_id, fields),
            lambda source_id, device_id: pqm_store.clear(source_id, device_id),
        )
        pqm_nats_client.telemetryUpdated.connect(pms_sld.notify_data_changed)
        pqm_nats_client.telemetryUpdated.connect(pms_power_monitoring.notify_data_changed)
        pqm_nats_client.start()

        solar_nats_client = SimpleDeviceNatsClient(          # SOLAR_VINFAST_TCP_SIM: display.dev.<id>.solar0
            db_settings.nats, "solar0", "SOLAR", "_DEVCFG_DEVTYPE_SOLAR",
            lambda: pms_config.topology_model,
            lambda source_id, device_id, fields: solar_store.apply_nats_fields(source_id, device_id, fields),
            lambda source_id, device_id: solar_store.clear(source_id, device_id),
        )
        solar_nats_client.telemetryUpdated.connect(pms_sld.notify_data_changed)
        solar_nats_client.start()
    pms_energy_balance = EnergyBalanceViewModel(              # ViewModel Energy Balance theo PowerSourceGroup của grid
        topology_vm=pms_config,
        realtime_service=realtime_service,
        data_store=pms_data_store,
        historian_service=historian_service,
        event_service=event_service,  # tổng ngày ưu tiên đọc MySQL finance_agg_daily (ledger thật của PMS)
    )
    pms_alarm = AlarmViewModel(                               # ViewModel cảnh báo từ MySQL `alarms` khi live
        topology_vm=pms_config,
        event_service=event_service,
        live=data_source == "live",
    )
    forecast_manager = ForecastViewModel(                     # Solar/Demand/BESS forecast từ measurement flex_psg
        topology_vm=pms_config,
        influx_client=influx_client if data_source == "live" else None,
    )
    event_manager = EventViewModel(                           # Nhật ký sự kiện — Alarm Event từ MySQL `alarms` khi live
        event_service=event_service,
        topology_vm=pms_config,
        live=data_source == "live",
    )

    # Đăng ký mỗi backend với context QML bằng tên biến – QML dùng tên này để truy cập
    engine.rootContext().setContextProperty("microgridOverview", microgrid_overview)
    engine.rootContext().setContextProperty("microgridSld", microgrid_sld)
    engine.rootContext().setContextProperty("microgridRealtime", microgrid_realtime)
    engine.rootContext().setContextProperty("microgridAlarm", microgrid_alarm)
    engine.rootContext().setContextProperty("settingsManager", settings_manager)
    engine.rootContext().setContextProperty("authManager", auth_manager)
    engine.rootContext().setContextProperty("timeSyncManager", time_sync_manager)
    engine.rootContext().setContextProperty("weatherManager", weather_manager)
    engine.rootContext().setContextProperty("siteFacts", site_facts_manager)
    engine.rootContext().setContextProperty("analyticsManager", analytics_manager)
    engine.rootContext().setContextProperty("eventManager", event_manager)
    engine.rootContext().setContextProperty("reportManager", report_manager)
    engine.rootContext().setContextProperty("maintenanceCommands", maintenance_commands)
    engine.rootContext().setContextProperty("pmsConfig", pms_config)
    engine.rootContext().setContextProperty("pmsRuntime", pms_runtime)
    engine.rootContext().setContextProperty("pmsBattery", pms_battery)
    engine.rootContext().setContextProperty("pmsPcs", pms_pcs)
    engine.rootContext().setContextProperty("pmsSld", pms_sld)
    engine.rootContext().setContextProperty("pmsPowerMonitoring", pms_power_monitoring)
    engine.rootContext().setContextProperty("pmsEnergyBalance", pms_energy_balance)
    engine.rootContext().setContextProperty("pmsAlarm", pms_alarm)
    engine.rootContext().setContextProperty("forecastManager", forecast_manager)

    engine.loadFromModule("HMI", "Home")  # Nạp file Home.qml từ module HMI làm cửa sổ chính
    if not engine.rootObjects():
        sys.exit(-1) 

    if sys.platform == "win32":
        main_window = engine.rootObjects()[0]
        main_window.showMaximized()
    else:
        main_window = engine.rootObjects()[0]
        main_window.setFlag(Qt.FramelessWindowHint, True)
        screen = app.primaryScreen()
        if screen is not None:
            main_window.setGeometry(screen.geometry())
        main_window.showFullScreen()
    app.aboutToQuit.connect(lambda: app_logger.info("Application shutdown"))
    sys.exit(app.exec())  # Chạy vòng lặp sự kiện Qt; thoát khi người dùng đóng cửa sổ
