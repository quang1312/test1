pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls.Basic as Basic
import "components"

Rectangle {
    id: root

    property var dataSource: null
    property var energyBalanceSource: null
    property var sldSource: null
    property string selectedFromDate: Qt.formatDate(new Date(), "dd/MM/yyyy")
    property string selectedToDate: Qt.formatDate(new Date(), "dd/MM/yyyy")
    property string selectedStartTime: "00:00"
    property string selectedEndTime: "23:59"
    property string selectedTimeRange: "00:00 - 23:59"
    property string selectedSite: energyBalanceSource ? energyBalanceSource.selectedGridName : "All Sites"
    property string selectedViewMode: "Energy (kWh)"
    property string trendMetric: "kWh"
    property string trendPeriod: "Daily"
    property string statusMessage: ""
    readonly property color bgColor: "#031624"
    readonly property color panelColor: "#071c2b"
    readonly property color panelHeaderColor: "#092235"
    readonly property color cardColor: "#082034"
    readonly property color lineColor: "#16415f"
    readonly property color textColor: "#eef6ff"
    readonly property color mutedTextColor: "#9db2c5"
    readonly property color blueColor: "#128cff"
    readonly property color cyanColor: "#20c7d7"
    readonly property color greenColor: "#3bd15b"
    readonly property color yellowColor: "#ffc323"
    readonly property color orangeColor: "#f59e0b"
    readonly property color redColor: "#ff4038"
    readonly property color violetColor: "#8b5cf6"
    readonly property color grayColor: "#7f8ea3"
    property real boardScale: Math.min(width / board.width, height / board.height)

    color: bgColor
    radius: 8
    border.color: "#12324b"
    border.width: 1
    clip: true

    function numberValue(value, fallbackValue) {
        var n = Number(value);
        return isNaN(n) ? fallbackValue : n;
    }

    function fmt(value, digits) {
        return numberValue(value, 0).toFixed(digits);
    }

    function nextValue(current, values) {
        var index = values.indexOf(current);
        return values[(index + 1) % values.length];
    }

    function showStatus(message) {
        statusMessage = message;
        statusTimer.restart();
    }

    // Filters that change what the BACKEND returns (date/time range, grid, trend period).
    function touchFilters(message) {
        scheduleRefresh();
        showStatus(message);
    }

    // Filters that only change how the SAME data is displayed (kWh/% view, trend metric).
    // No backend call, no snapshot rebuild: bindings re-evaluate and the canvases repaint.
    function touchDisplay(message) {
        showStatus(message);
    }

    function selectedDateRange() {
        return selectedFromDate === selectedToDate ? selectedFromDate : selectedFromDate + " - " + selectedToDate;
    }

    function setDateTimeRange(fromDateValue, toDateValue, startValue, endValue) {
        selectedFromDate = fromDateValue;
        selectedToDate = toDateValue;
        selectedStartTime = startValue;
        selectedEndTime = endValue;
        selectedTimeRange = selectedStartTime + " - " + selectedEndTime;
        touchFilters("Time range: " + selectedDateRange() + " " + selectedTimeRange);
    }

    function exportEnergyBalance() {
        if (!dataSource || !dataSource.exportEnergyBalanceCsv) {
            showStatus("Export backend is not connected");
            return;
        }
        var path = dataSource.exportEnergyBalanceCsv(selectedDateRange(), selectedTimeRange, selectedSite);
        showStatus(path && path.length > 0 ? "Exported: " + path : "Export failed");
    }

    function flowUnit() {
        if (selectedViewMode === "Percent (%)")
            return "%";
        return "kWh";
    }

    function flowValue(valueKwh, referenceKwh) {
        if (selectedViewMode === "Percent (%)")
            return fmt(valueKwh / Math.max(1, referenceKwh) * 100, 1) + "%";
        return comma(valueKwh, 0) + " kWh";
    }

    function comma(value, digits) {
        var text = fmt(value, digits);
        var parts = text.split(".");
        var sign = "";
        if (parts[0].charAt(0) === "-") {
            sign = "-";
            parts[0] = parts[0].substring(1);
        }
        var out = "";
        while (parts[0].length > 3) {
            out = "," + parts[0].slice(-3) + out;
            parts[0] = parts[0].slice(0, -3);
        }
        out = sign + parts[0] + out;
        return parts.length > 1 ? out + "." + parts[1] : out;
    }

    // Axis scaling shared by the charts: same kWh -> MWh switch as the KPI tiles.
    function axisUnit(maxKwh, percent) {
        if (percent)
            return { divisor: 1, unit: "%", digits: 0 };
        if (Math.abs(maxKwh) > 10000)
            return { divisor: 1000, unit: "MWh", digits: 1 };
        return { divisor: 1, unit: "kWh", digits: 0 };
    }

    function formatEnergyKwh(valueKwh) {
        if (Math.abs(valueKwh) > 10000)
            return { value: comma(valueKwh / 1000, 2), unit: "MWh" };
        return { value: comma(valueKwh, 0), unit: "kWh" };
    }

    function gridOptions() {
        if (!energyBalanceSource || !energyBalanceSource.availableGrids)
            return ["All Sites"];
        var rows = energyBalanceSource.availableGrids;
        var names = [];
        for (var i = 0; i < rows.length; i++)
            names.push(rows[i].name);
        return names.length > 0 ? names : ["All Sites"];
    }

    readonly property var emptySnapshot: ({
        sourceRows: [], outputRows: [], summaryRows: [], timeSeries: [], trendRows: [],
        totalInputKwh: 0, totalOutputKwh: 0, lossKwh: 0, netKwh: 0, efficiencyPct: 0, carbonTon: null
    })
    property var snapshotData: emptySnapshot
    property bool snapshotLoading: false
    property int pendingRetries: 0
    readonly property int maxPendingRetries: 25      // 25 x 400 ms, then give up (MySQL down)

    readonly property string snapshotNote: snapshotData && snapshotData.note ? snapshotData.note : ""

    function energySnapshot() {
        return snapshotData;
    }

    // One backend call per refresh (never from inside a binding).
    function refreshSnapshot() {
        var snap = _fetchEnergySnapshot();
        if (snap.pending && pendingRetries < maxPendingRetries) {
            // MySQL aggregates still loading in the background: keep the last good numbers
            // (dimmed) instead of flashing zeros, and poll again shortly.
            snapshotLoading = true;
            return;
        }
        snapshotLoading = false;
        pendingRetries = 0;
        // Same numbers as last time -> don't touch bindings / repaint 5 canvases for nothing.
        if (JSON.stringify(snap) === JSON.stringify(snapshotData))
            return;
        snapshotData = snap;
    }

    function scheduleRefresh() {
        pendingRetries = 0;
        refreshDebounce.restart();      // coalesces bursts (grid change fires several signals)
    }

    function _fetchEnergySnapshot() {
        if (energyBalanceSource && energyBalanceSource.energyBalanceSnapshot) {
            return energyBalanceSource.energyBalanceSnapshot(
                selectedDateRange(),
                selectedTimeRange,
                selectedSite,
                selectedViewMode,
                "kWh",
                trendPeriod
            );
        }
        if (dataSource && dataSource.energyBalanceSnapshot) {
            return dataSource.energyBalanceSnapshot(
                selectedDateRange(),
                selectedTimeRange,
                selectedSite,
                selectedViewMode,
                trendMetric,
                trendPeriod
            );
        }
        return {
            sourceRows: [],
            outputRows: [],
            summaryRows: [],
            timeSeries: [],
            trendRows: [],
            totalInputKwh: 0,
            totalOutputKwh: 0,
            lossKwh: 0,
            netKwh: 0,
            efficiencyPct: 0,
            carbonTon: 0
        };
    }

    function sourceRows() {
        return energySnapshot().sourceRows || [];
    }

    function totalInputKwh() {
        return numberValue(energySnapshot().totalInputKwh, 0);
    }

    function totalOutputKwh() {
        return numberValue(energySnapshot().totalOutputKwh, 0);
    }

    function lossKwh() {
        return numberValue(energySnapshot().lossKwh, 0);
    }

    function netKwh() {
        return numberValue(energySnapshot().netKwh, 0);
    }

    function efficiencyPct() {
        return numberValue(energySnapshot().efficiencyPct, 0);
    }

    function carbonTon() {
        var v = energySnapshot().carbonTon;
        return (v === null || v === undefined) ? null : v;
    }

    function totalInputChangePct() {
        var v = energySnapshot().totalInputChangePct;
        return v === undefined ? null : v;
    }

    function totalOutputChangePct() {
        var v = energySnapshot().totalOutputChangePct;
        return v === undefined ? null : v;
    }

    function lossChangePct() {
        var v = energySnapshot().lossChangePct;
        return v === undefined ? null : v;
    }

    function netChangePct() {
        var v = energySnapshot().netChangePct;
        return v === undefined ? null : v;
    }

    function efficiencyChangePct() {
        var v = energySnapshot().efficiencyChangePct;
        return v === undefined ? null : v;
    }

    function carbonChangePct() {
        var v = energySnapshot().carbonChangePct;
        return v === undefined ? null : v;
    }

    function changeText(pct) {
        if (pct === null || pct === undefined)
            return "No data   vs Yesterday";
        var arrow = pct >= 0 ? "↑" : "↓";
        return arrow + " " + Math.abs(pct).toFixed(1) + "%   vs Yesterday";
    }

    function changeColor(pct, lowerIsBetter) {
        if (pct === null || pct === undefined)
            return mutedTextColor;
        var improved = lowerIsBetter ? pct <= 0 : pct >= 0;
        return improved ? greenColor : redColor;
    }

    function outputRows() {
        return energySnapshot().outputRows || [];
    }

    function summaryRows() {
        return energySnapshot().summaryRows || [];
    }

    function timeSeries() {
        return energySnapshot().timeSeries || [];
    }

    function trendRows() {
        var rows = energySnapshot().trendRows || [];
        if (trendMetric !== "%")
            return rows;
        var out = [];
        for (var i = 0; i < rows.length; i++) {
            var eff = Math.min(100, numberValue(rows[i].output, 0) / Math.max(1, numberValue(rows[i].input, 0)) * 100);
            out.push({ fullDate: rows[i].fullDate, label: rows[i].label, input: 100, output: eff, net: 100 - eff, efficiency: eff });
        }
        return out;
    }

    function redrawCharts() {
        flowCanvas.requestPaint();
        timeChart.requestPaint();
        trendChart.requestPaint();
        inputDonut.requestPaint();
        outputDonut.requestPaint();
    }

    // Charts repaint themselves when their data changes (onPointsChanged / onRowsChanged),
    // so only a resize needs a manual repaint.
    onWidthChanged: redrawCharts()
    onHeightChanged: redrawCharts()
    onSnapshotDataChanged: flowCanvas.requestPaint()

    Component.onCompleted: refreshSnapshot()

    Timer { id: refreshDebounce; interval: 120; repeat: false; onTriggered: root.refreshSnapshot() }

    // Energy/finance data comes from MySQL daily aggregates + historian: it changes slowly,
    // so a slow poll is enough (was: rebuild on every 0.5-1 s simulator/NATS tick).
    Timer {
        interval: 15000
        repeat: true
        running: root.visible
        onTriggered: root.refreshSnapshot()
    }

    Timer {
        interval: 400
        repeat: true
        running: root.visible && root.snapshotLoading
        onTriggered: {
            root.pendingRetries++;
            root.refreshSnapshot();
        }
    }

    Connections {
        target: root.energyBalanceSource
        function onDataChanged() {
            root.selectedSite = root.energyBalanceSource ? root.energyBalanceSource.selectedGridName : root.selectedSite;
            root.scheduleRefresh();
        }
        function onSelectedGridChanged() {
            root.selectedSite = root.energyBalanceSource ? root.energyBalanceSource.selectedGridName : root.selectedSite;
            root.scheduleRefresh();
        }
    }

    Repeater {
        model: 58
        Rectangle {
            required property int index
            x: index * 42
            width: 1
            height: parent.height
            color: "#0d2a40"
            opacity: 0.38
        }
    }

    Repeater {
        model: 36
        Rectangle {
            required property int index
            y: index * 36
            width: parent.width
            height: 1
            color: "#0d2a40"
            opacity: 0.24
        }
    }

    Item {
        id: board
        width: 1780
        height: 1120
        anchors.centerIn: parent
        scale: root.boardScale
        opacity: root.snapshotLoading ? 0.55 : 1.0
        Behavior on opacity { NumberAnimation { duration: 120 } }

        Row {
            x: 780
            y: 0
            height: 44
            spacing: 18

            DateTimeRangePicker {
                width: 608
                fromDate: root.selectedFromDate
                toDate: root.selectedToDate
                startTime: root.selectedStartTime
                endTime: root.selectedEndTime
                textColor: root.textColor
                mutedTextColor: root.mutedTextColor
                accentColor: root.blueColor
                fieldColor: "#071827"
                hoverColor: "#0a2438"
                borderColor: "#173852"
                onRangeEdited: function(fromDateValue, toDateValue, startValue, endValue) {
                    root.setDateTimeRange(fromDateValue, toDateValue, startValue, endValue);
                }
            }
            FilterCombo {
                width: 208
                value: root.selectedSite
                options: root.gridOptions()
                onSelected: function(value) {
                    root.selectedSite = value;
                    if (root.energyBalanceSource && root.energyBalanceSource.setSelectedGridByName)
                        root.energyBalanceSource.setSelectedGridByName(value);
                    root.touchFilters("Main grid: " + root.selectedSite);   // debounced, no sync fetch
                }
            }
            ExportButton {
                width: 130
                onClicked: root.exportEnergyBalance()
            }
        }

        Rectangle {
            x: 1240
            y: 44
            width: 520
            height: 26
            radius: 5
            visible: root.statusMessage.length > 0 || root.snapshotLoading || root.snapshotNote.length > 0
            color: "#08243a"
            border.color: root.blueColor
            border.width: 1
            z: 20

            Text {
                anchors.fill: parent
                anchors.leftMargin: 12
                anchors.rightMargin: 12
                text: root.snapshotLoading ? "Loading data..." : (root.statusMessage.length > 0 ? root.statusMessage : root.snapshotNote)
                color: "#ccecff"
                font.pixelSize: 12
                font.bold: true
                verticalAlignment: Text.AlignVCenter
                elide: Text.ElideRight
            }
        }

        Row {
            id: kpiRow
            x: 0
            y: 58
            spacing: 12

            KpiTile { width: 287; title: "TOTAL ENERGY INPUT"; value: root.formatEnergyKwh(root.totalInputKwh()).value; unitText: root.formatEnergyKwh(root.totalInputKwh()).unit; changeText: root.changeText(root.totalInputChangePct()); changeColor: root.changeColor(root.totalInputChangePct(), false); iconSource: "assets/icons/energy_input.svg"; accent: root.blueColor }
            KpiTile { width: 287; title: "TOTAL ENERGY OUTPUT"; value: root.formatEnergyKwh(root.totalOutputKwh()).value; unitText: root.formatEnergyKwh(root.totalOutputKwh()).unit; changeText: root.changeText(root.totalOutputChangePct()); changeColor: root.changeColor(root.totalOutputChangePct(), false); iconSource: "assets/icons/energy_output.svg"; accent: root.greenColor }
            KpiTile { width: 287; title: "NET ENERGY BALANCE"; value: root.formatEnergyKwh(root.netKwh()).value; unitText: root.formatEnergyKwh(root.netKwh()).unit; changeText: root.changeText(root.netChangePct()); changeColor: root.changeColor(root.netChangePct(), false); iconSource: "assets/icons/energy_balance.svg"; accent: root.violetColor }
            KpiTile { width: 287; title: "ENERGY LOSSES"; value: root.formatEnergyKwh(root.lossKwh()).value; unitText: root.formatEnergyKwh(root.lossKwh()).unit; changeText: root.changeText(root.lossChangePct()); changeColor: root.changeColor(root.lossChangePct(), true); iconSource: "assets/icons/energy_loss.svg"; accent: root.redColor }
            KpiTile { width: 287; title: "BALANCE EFFICIENCY"; value: root.fmt(root.efficiencyPct(), 1); unitText: "%"; changeText: root.changeText(root.efficiencyChangePct()); changeColor: root.changeColor(root.efficiencyChangePct(), false); iconSource: "assets/icons/efficiency.svg"; accent: root.cyanColor }
            KpiTile { width: 287; title: "CARBON EMISSIONS"; value: root.carbonTon() === null ? "--" : root.fmt(root.carbonTon(), 2); unitText: root.carbonTon() === null ? "" : "ton"; changeText: root.changeText(root.carbonChangePct()); changeColor: root.changeColor(root.carbonChangePct(), true); iconSource: "assets/icons/carbon.svg"; accent: root.greenColor }
        }

        PanelCard {
            x: 0
            y: 190
            width: 1140
            height: 500
            title: "ENERGY BALANCE FLOW DIAGRAM"

            Text {
                x: 18
                y: 62
                text: "View by:"
                color: root.mutedTextColor
                font.pixelSize: 13
                font.bold: true
            }

            FilterCombo {
                x: 86
                y: 52
                width: 190
                value: root.selectedViewMode
                options: ["Energy (kWh)", "Percent (%)"]
                onSelected: function(value) {
                    root.selectedViewMode = value;
                    root.touchDisplay("Flow diagram view: " + root.selectedViewMode);
                }
            }

            Text {
                x: 18
                y: 92
                width: 340
                height: 24
                text: "INPUT (" + root.flowValue(root.totalInputKwh(), root.totalInputKwh()) + ")"
                color: root.textColor
                font.pixelSize: 15
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
                elide: Text.ElideRight
            }

            Text {
                x: 455
                y: 92
                width: 230
                height: 24
                text: "SYSTEM"
                color: root.textColor
                font.pixelSize: 16
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
            }

            Text {
                x: 782
                y: 92
                width: 340
                height: 24
                text: "OUTPUT (" + root.flowValue(root.totalOutputKwh(), root.totalInputKwh()) + ")"
                color: root.textColor
                font.pixelSize: 15
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
                elide: Text.ElideRight
            }

            Canvas {
                id: flowCanvas
                x: 0
                y: 72
                width: parent.width
                height: parent.height - 72
                z: 0

                function rowEnergy(row) {
                    var value = Number(row && row.value !== undefined ? row.value : 0);
                    return isNaN(value) ? 0 : Math.max(0, value);
                }

                function totalEnergy(rows) {
                    var total = 0;
                    for (var i = 0; i < rows.length; i++)
                        total += rowEnergy(rows[i]);
                    return Math.max(1, total);
                }

                function laneWidths(rows, total, stackHeight, gap) {
                    var count = Math.max(1, rows.length);
                    var usable = Math.max(0, stackHeight - Math.max(0, count - 1) * gap);
                    var widths = [];
                    var widthTotal = 0;
                    for (var i = 0; i < rows.length; i++) {
                        var energy = rowEnergy(rows[i]);
                        var widthValue = energy <= 0 ? 0 : energy / total * usable;
                        widthValue = energy <= 0 ? 0 : Math.max(7, Math.min(44, widthValue));
                        widths.push(widthValue);
                        widthTotal += widthValue;
                    }
                    if (widthTotal > usable && widthTotal > 0) {
                        var scale = usable / widthTotal;
                        for (var j = 0; j < widths.length; j++)
                            widths[j] = Math.max(5, widths[j] * scale);
                    }
                    return widths;
                }

                function laneCenters(widths, topY, gap) {
                    var centers = [];
                    var cursor = topY;
                    for (var i = 0; i < widths.length; i++) {
                        centers.push(cursor + widths[i] / 2);
                        cursor += widths[i] + gap;
                    }
                    return centers;
                }

                function nodeCenterY(index) {
                    return 79 + index * 58;
                }

                function drawRibbonPath(ctx, x1, y1, x2, y2, bend) {
                    ctx.beginPath();
                    ctx.moveTo(x1, y1);
                    if (Math.abs(x2 - x1) < 4)
                        ctx.bezierCurveTo(x1, y1 + bend, x2, y2 - bend, x2, y2);
                    else
                        ctx.bezierCurveTo(x1 + bend, y1, x2 - bend, y2, x2, y2);
                }

                function drawRibbon(ctx, x1, y1, x2, y2, color, widthValue, bend) {
                    if (widthValue <= 0)
                        return;
                    ctx.save();
                    ctx.lineCap = "butt";
                    ctx.lineJoin = "round";

                    drawRibbonPath(ctx, x1, y1, x2, y2, bend);
                    ctx.strokeStyle = color;
                    ctx.lineWidth = widthValue + 9;
                    ctx.globalAlpha = 0.14;
                    ctx.stroke();

                    drawRibbonPath(ctx, x1, y1, x2, y2, bend);
                    ctx.strokeStyle = color;
                    ctx.lineWidth = widthValue;
                    ctx.globalAlpha = 0.84;
                    ctx.stroke();

                    drawRibbonPath(ctx, x1, y1, x2, y2, bend);
                    ctx.strokeStyle = "#ffffff";
                    ctx.lineWidth = Math.max(1.5, widthValue * 0.22);
                    ctx.globalAlpha = 0.11;
                    ctx.stroke();
                    ctx.restore();
                }

                onPaint: {
                    var ctx = getContext("2d");
                    ctx.clearRect(0, 0, width, height);
                    var inputs = root.sourceRows();
                    var outputs = root.outputRows();
                    var laneGap = 6;
                    var stackTop = 108;
                    var stackHeight = 132;
                    var inputTotal = totalEnergy(inputs);
                    var outputTotal = totalEnergy(outputs);
                    var inputWidths = laneWidths(inputs, inputTotal, stackHeight, laneGap);
                    var outputWidths = laneWidths(outputs, outputTotal, stackHeight, laneGap);
                    var inputCenters = laneCenters(inputWidths, stackTop, laneGap);
                    var outputCenters = laneCenters(outputWidths, stackTop, laneGap);
                    for (var i = 0; i < inputs.length; i++) {
                        drawRibbon(ctx, 358, nodeCenterY(i), 465, inputCenters[i], inputs[i].color, inputWidths[i], 78);
                    }
                    for (var j = 0; j < outputs.length; j++) {
                        drawRibbon(ctx, 675, outputCenters[j], 782, nodeCenterY(j), outputs[j].color, outputWidths[j], 78);
                    }
                    var lossWidth = Math.max(6, Math.min(30, root.lossKwh() / Math.max(1, root.totalInputKwh()) * stackHeight));
                    drawRibbon(ctx, 570, 250, 570, 308, root.orangeColor, lossWidth, 34);
                }

                Component.onCompleted: requestPaint()
            }

            Repeater {
                model: root.sourceRows()
                FlowNode {
                    required property var modelData
                    required property int index
                    x: 18
                    y: 126 + index * 58
                    width: 340
                    title: modelData.label
                    value: root.flowValue(modelData.value, root.totalInputKwh())
                    share: "(" + root.fmt(modelData.percent, 1) + "%)"
                    iconText: modelData.icon
                    accent: modelData.color
                    inactive: Number(modelData.value) <= 0
                }
            }

            Rectangle {
                x: 455
                y: 160
                width: 230
                height: 154
                radius: 8
                color: "#091b2c"
                border.color: "#2b4b65"
                border.width: 1
                z: 3

                Column {
                    anchors.centerIn: parent
                    width: parent.width - 36
                    spacing: 8
                    Text { width: parent.width; height: 18; text: "SYSTEM CONSUMPTION"; color: root.textColor; font.pixelSize: 13; font.bold: true; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
                    Item {
                        width: parent.width
                        height: 28
                        AppIcon {
                            anchors.centerIn: parent
                            width: 25
                            height: 25
                            name: "zap"
                            tint: root.orangeColor
                        }
                    }
                    Text { width: parent.width; height: 30; text: root.flowValue(root.totalOutputKwh(), root.totalInputKwh()); color: root.textColor; font.pixelSize: 22; font.bold: true; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
                    Rectangle { width: parent.width; height: 1; color: root.lineColor }
                    Text { width: parent.width; height: 18; text: "BALANCE EFFICIENCY"; color: root.mutedTextColor; font.pixelSize: 12; font.bold: true; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
                    Text { width: parent.width; height: 30; text: root.fmt(root.efficiencyPct(), 1) + "%"; color: root.textColor; font.pixelSize: 22; font.bold: true; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
                }
            }

            Rectangle {
                x: 460
                y: 370
                width: 220
                height: 88
                radius: 7
                color: "#1b1720"
                border.color: "#8f3d21"
                border.width: 1
                z: 3

                Column {
                    anchors.centerIn: parent
                    width: parent.width - 28
                    spacing: 4
                    Text { width: parent.width; height: 18; text: "ENERGY LOSSES"; color: root.textColor; font.pixelSize: 13; font.bold: true; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
                    Text { width: parent.width; height: 25; text: root.flowValue(root.lossKwh(), root.totalInputKwh()); color: root.textColor; font.pixelSize: 18; font.bold: true; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
                    Text { width: parent.width; height: 18; text: "(" + root.fmt(root.lossKwh() / Math.max(1, root.totalInputKwh()) * 100, 1) + "%)"; color: "#d6b9a8"; font.pixelSize: 13; font.bold: true; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter }
                }
            }

            Repeater {
                model: root.outputRows()
                FlowNode {
                    required property var modelData
                    required property int index
                    x: 782
                    y: 126 + index * 58
                    width: 340
                    title: modelData.label
                    value: root.flowValue(modelData.value, root.totalOutputKwh())
                    share: ""
                    iconText: modelData.icon
                    accent: modelData.color
                    compact: true
                    inactive: Number(modelData.value) <= 0
                }
            }
        }

        PanelCard {
            x: 1154
            y: 190
            width: 626
            height: 230
            title: "ENERGY BALANCE SUMMARY"

            Column {
                x: 18
                y: 54
                width: parent.width - 36
                spacing: 2

                Repeater {
                    model: root.summaryRows()
                    SummaryRow {
                        required property var modelData
                        width: parent.width
                        label: modelData.label
                        value: modelData.value
                        iconSource: modelData.icon
                        accent: modelData.color
                    }
                }
            }
        }

        PanelCard {
            x: 1154
            y: 434
            width: 626
            height: 256
            title: root.selectedFromDate === root.selectedToDate ? "ENERGY BALANCE BY TIME OF DAY" : "ENERGY BALANCE BY DAY"

            LineChart {
                id: timeChart
                x: 22
                y: 60
                width: parent.width - 44
                height: parent.height - 92
                points: root.timeSeries()
            }

            Row {
                x: 164
                y: parent.height - 30
                spacing: 32
                LegendDot { label: "Input"; accent: root.blueColor }
                LegendDot { label: "Output"; accent: root.greenColor }
                LegendDot { label: "Net Balance"; accent: root.violetColor }
            }
        }

        PanelCard {
            x: 0
            y: 704
            width: 430
            height: 392
            title: "ENERGY BALANCE TREND (" + root.trendPeriod.toUpperCase() + ")"

            Row {
                id: trendControlRow
                x: parent.width - width - 16
                y: 58
                width: 206
                height: 30
                spacing: 6
                SmallTab { width: 38; label: "kWh"; selected: root.trendMetric === "kWh"; onClicked: { root.trendMetric = "kWh"; root.touchDisplay("Trend metric: kWh"); } }
                SmallTab { width: 38; label: "%"; selected: root.trendMetric === "%"; onClicked: { root.trendMetric = "%"; root.touchDisplay("Trend metric: %"); } }
                FilterCombo {
                    width: 74
                    height: 30
                    value: root.trendPeriod
                    options: ["Daily", "Weekly", "Monthly"]
                    onSelected: function(value) {
                        root.trendPeriod = value;
                        root.touchFilters("Trend period: " + root.trendPeriod);
                    }
                }
            }

            TrendChart {
                id: trendChart
                x: 18
                y: 96
                width: parent.width - 36
                height: parent.height - 136
                points: root.trendRows()
                percent: root.trendMetric === "%"
            }

            Row {
                x: 66
                y: parent.height - 30
                spacing: 28
                LegendDot { label: "Input"; accent: root.blueColor }
                LegendDot { label: "Output"; accent: root.greenColor }
                LegendDot { label: "Net Balance"; accent: root.violetColor }
            }
        }

        PanelCard {
            x: 442
            y: 704
            width: 430
            height: 392
            title: "ENERGY BALANCE BY SOURCE (INPUT)"

            DonutChart {
                id: inputDonut
                x: 24
                y: 76
                width: 174
                height: 174
                rows: root.sourceRows()
                totalText: root.formatEnergyKwh(root.totalInputKwh()).value
                unitText: root.formatEnergyKwh(root.totalInputKwh()).unit
            }

            LegendList {
                x: 214
                y: 72
                width: 196
                rows: root.sourceRows()
            }
        }

        PanelCard {
            x: 884
            y: 704
            width: 430
            height: 392
            title: "ENERGY BALANCE BY CONSUMPTION (OUTPUT)"

            DonutChart {
                id: outputDonut
                x: 24
                y: 76
                width: 174
                height: 174
                rows: root.outputRows()
                totalText: root.formatEnergyKwh(root.totalOutputKwh()).value
                unitText: root.formatEnergyKwh(root.totalOutputKwh()).unit
            }

            LegendList {
                x: 214
                y: 72
                width: 196
                rows: root.outputRows()
            }
        }

        PanelCard {
            x: 1326
            y: 704
            width: 454
            height: 392
            title: root.trendPeriod.toUpperCase() + " ENERGY BALANCE REPORT"

            Row {
                x: 18
                y: 58
                height: 24
                Text { width: 84; height: parent.height; text: "DATE"; color: root.mutedTextColor; font.pixelSize: 10; font.bold: true; verticalAlignment: Text.AlignVCenter }
                Text { width: 90; height: parent.height; text: "INPUT"; color: root.mutedTextColor; font.pixelSize: 10; font.bold: true; horizontalAlignment: Text.AlignRight; verticalAlignment: Text.AlignVCenter }
                Text { width: 96; height: parent.height; text: "OUTPUT"; color: root.mutedTextColor; font.pixelSize: 10; font.bold: true; horizontalAlignment: Text.AlignRight; verticalAlignment: Text.AlignVCenter }
                Text { width: 102; height: parent.height; text: "NET"; color: root.mutedTextColor; font.pixelSize: 10; font.bold: true; horizontalAlignment: Text.AlignRight; verticalAlignment: Text.AlignVCenter }
                Text { width: 46; height: parent.height; text: "EFF."; color: root.mutedTextColor; font.pixelSize: 10; font.bold: true; horizontalAlignment: Text.AlignRight; verticalAlignment: Text.AlignVCenter }
            }

            Rectangle { x: 18; y: 84; width: parent.width - 36; height: 1; color: root.lineColor }

            Column {
                x: 18
                y: 92
                width: parent.width - 36
                spacing: 1

                Repeater {
                    model: root.trendRows().slice().reverse()
                    ReportRow {
                        required property var modelData
                        width: parent.width
                        dateText: modelData.fullDate
                        inputText: root.comma(modelData.input, 0)
                        outputText: root.comma(modelData.output, 0)
                        netText: root.comma(modelData.net, 0)
                        efficiencyText: root.fmt(modelData.efficiency, 1) + "%"
                    }
                }
            }

            Text {
                x: 18
                y: parent.height - 26
                width: parent.width - 36
                text: "Note: All values are calculated based on selected time range and site."
                color: root.mutedTextColor
                font.pixelSize: 11
                elide: Text.ElideRight
            }
        }
    }

    Timer {
        id: statusTimer
        interval: 2600
        repeat: false
        onTriggered: root.statusMessage = ""
    }

    component PanelCard: Rectangle {
        id: panel
        default property alias content: contentLayer.data
        property string title: ""

        radius: 8
        color: root.panelColor
        border.color: "#143a56"
        border.width: 1
        clip: true

        Rectangle {
            x: 1
            y: 1
            width: parent.width - 2
            height: 49
            radius: 7
            color: root.panelHeaderColor
        }

        Rectangle {
            x: 0
            y: 49
            width: parent.width
            height: 1
            color: root.lineColor
        }

        Text {
            x: 16
            y: 15
            width: parent.width - 32
            height: 20
            text: panel.title
            color: root.textColor
            font.pixelSize: 16
            font.bold: true
            verticalAlignment: Text.AlignVCenter
            elide: Text.ElideRight
        }

        Item {
            id: contentLayer
            anchors.fill: parent
        }
    }

    component KpiTile: Rectangle {
        id: card
        property string title: ""
        property string value: ""
        property string unitText: ""
        property string changeText: ""
        property string iconSource: ""
        property color accent: root.blueColor
        property color changeColor: root.greenColor

        height: 118
        radius: 8
        color: root.cardColor
        border.color: "#143a56"
        border.width: 1
        clip: true

        Rectangle {
            x: 20
            y: 24
            width: 54
            height: 54
            radius: 27
            color: Qt.rgba(card.accent.r, card.accent.g, card.accent.b, 0.14)
            border.color: card.accent
            border.width: 1

            Image {
                anchors.centerIn: parent
                width: 30
                height: 30

                source: card.iconSource
                fillMode: Image.PreserveAspectFit
            }
        }

        Text {
            x: 84
            y: 20
            width: parent.width - 100
            text: card.title
            color: root.mutedTextColor
            font.pixelSize: 13
            font.bold: true
            fontSizeMode: Text.Fit
            minimumPixelSize: 9
            elide: Text.ElideRight
            horizontalAlignment: Text.AlignLeft
        }

        Row {
            x: 84
            y: 48
            width: parent.width - 100
            spacing: 8
            Text { text: card.value; color: root.textColor; font.pixelSize: 26; font.bold: true }
            Text { text: card.unitText; color: "#d3e4f3"; font.pixelSize: 14; font.bold: true; anchors.baseline: parent.children[0].baseline }
        }

        Text {
            x: 84
            y: 90
            width: parent.width - 100
            text: card.changeText
            color: card.changeColor
            font.pixelSize: 12
            font.bold: true
            elide: Text.ElideRight
        }
    }

    component FilterBox: Rectangle {
        id: filter
        property string label: ""
        property string iconText: ""
        signal clicked()

        width: 160
        height: 36
        radius: 6
        color: filterMouse.containsMouse ? "#0a2438" : "#071827"
        border.color: filterMouse.containsMouse ? root.blueColor : "#173852"
        border.width: 1

        Text {
            x: 14
            y: 0
            width: parent.width - 42
            height: parent.height
            text: filter.label
            color: root.textColor
            font.pixelSize: 13
            font.bold: true
            verticalAlignment: Text.AlignVCenter
            elide: Text.ElideRight
        }

        Text {
            x: parent.width - 28
            y: 0
            width: 18
            height: parent.height
            text: filter.iconText
            color: "#b9988c"
            font.pixelSize: 15
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
        }

        MouseArea {
            id: filterMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: filter.clicked()
        }
    }

    component FilterCombo: Item {
        id: filterCombo
        property string value: ""
        property var options: []
        signal selected(string value)

        width: 160
        height: 36
        z: combo.popup.visible ? 80 : 1

        Basic.ComboBox {
            id: combo
            anchors.fill: parent
            model: filterCombo.options
            currentIndex: Math.max(0, filterCombo.options.indexOf(filterCombo.value))
            onActivated: function(index) {
                if (index >= 0 && index < filterCombo.options.length)
                    filterCombo.selected(filterCombo.options[index]);
            }
            contentItem: Text {
                leftPadding: 14
                rightPadding: 34
                text: filterCombo.value || combo.displayText
                color: root.textColor
                font.pixelSize: 13
                font.bold: true
                verticalAlignment: Text.AlignVCenter
                elide: Text.ElideRight
            }
            indicator: Text {
                x: combo.width - width - 12
                y: 0
                width: 18
                height: combo.height
                text: "⌄"
                color: "#b9988c"
                font.pixelSize: 15
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
            }
            background: Rectangle {
                radius: 6
                color: combo.hovered ? "#0a2438" : "#071827"
                border.color: combo.hovered || combo.activeFocus ? root.blueColor : "#173852"
                border.width: 1
            }
            delegate: Basic.ItemDelegate {
                id: comboDelegate
                required property int index
                required property string modelData
                width: combo.width
                height: 34
                highlighted: combo.highlightedIndex === index
                contentItem: Text {
                    text: comboDelegate.modelData
                    color: comboDelegate.highlighted ? "#031624" : root.textColor
                    font.pixelSize: 12
                    font.bold: true
                    verticalAlignment: Text.AlignVCenter
                    elide: Text.ElideRight
                }
                background: Rectangle {
                    color: comboDelegate.highlighted ? root.blueColor : "#071827"
                }
            }
            popup: Basic.Popup {
                y: combo.height + 4
                width: combo.width
                implicitHeight: contentItem.implicitHeight
                padding: 0
                background: Rectangle {
                    radius: 6
                    color: "#071827"
                    border.color: root.blueColor
                    border.width: 1
                }
                contentItem: ListView {
                    clip: true
                    implicitHeight: Math.min(contentHeight, 180)
                    model: combo.popup.visible ? combo.delegateModel : null
                    currentIndex: combo.highlightedIndex
                }
            }
        }
    }

    component ExportButton: Rectangle {
        id: exportButton
        signal clicked()

        width: 128
        height: 38
        radius: 6
        color: exportMouse.containsMouse ? "#1260cc" : "#0d47a1"
        border.color: exportMouse.containsMouse ? "#44a8ff" : "#1d6fd7"
        border.width: 1

        Row {
            anchors.centerIn: parent
            spacing: 9
            Text { text: "▣"; color: "#dcecff"; font.pixelSize: 16; font.bold: true; anchors.verticalCenter: parent.verticalCenter }
            Text { text: "Export"; color: "#eef6ff"; font.pixelSize: 14; font.bold: true; anchors.verticalCenter: parent.verticalCenter }
        }

        MouseArea {
            id: exportMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: exportButton.clicked()
        }
    }

    component FlowNode: Rectangle {
        id: node
        property string title: ""
        property string value: ""
        property string share: ""
        property string iconText: ""
        property color accent: root.blueColor
        property bool compact: false
        property bool inactive: false
        readonly property color effectiveAccent: inactive ? root.grayColor : accent

        height: 50
        radius: 6
        color: node.inactive ? "#071b2a" : "#071f31"
        border.color: node.effectiveAccent
        border.width: 1
        z: 4

        Rectangle {
            x: 9
            anchors.verticalCenter: parent.verticalCenter
            width: 34
            height: 34
            radius: 17
            color: Qt.rgba(node.effectiveAccent.r, node.effectiveAccent.g, node.effectiveAccent.b, node.inactive ? 0.08 : 0.13)
            border.color: node.effectiveAccent
            border.width: 1

            AppIcon {
                anchors.centerIn: parent 
                width: 22
                height: 22
                name: node.iconText
                tint: node.effectiveAccent
            }
        }

        Text {
            x: 56
            y: node.compact ? 6 : 5
            width: node.compact ? node.width - 68 : 124
            height: node.compact ? 19 : 20
            text: node.title
            color: node.inactive ? "#9db2c5" : "#d7e3ed"
            font.pixelSize: 13
            font.bold: true
            verticalAlignment: Text.AlignVCenter
            elide: Text.ElideRight
        }

        Text {
            x: node.compact ? 56 : 198
            y: node.compact ? 27 : 5
            width: node.compact ? node.width - 68 : node.width - 210
            height: node.compact ? 18 : 20
            text: node.value
            color: node.compact ? node.effectiveAccent : node.inactive ? "#9db2c5" : "#d4e0ea"
            font.pixelSize: node.compact ? 12 : 12
            font.bold: true
            horizontalAlignment: node.compact ? Text.AlignLeft : Text.AlignRight
            verticalAlignment: Text.AlignVCenter
            elide: Text.ElideRight
        }

        Text {
            visible: !node.compact
            x: 198
            y: 27
            width: node.width - 210
            height: 18
            text: node.share
            color: node.effectiveAccent
            font.pixelSize: 12
            font.bold: true
            horizontalAlignment: Text.AlignRight
            verticalAlignment: Text.AlignVCenter
            elide: Text.ElideRight
        }
    }

    component SummaryRow: Row {
        id: row
        property string label: ""
        property string value: ""
        property string iconSource: ""
        property color accent: root.blueColor

        height: 22
        spacing: 10

        Image {
            width: 20
            height: 20
            source: iconSource
            fillMode: Image.PreserveAspectFit
        }

        Text {
            width: row.width - 180
            height: row.height
            text: row.label
            color: "#d7e3ed"
            font.pixelSize: 12
            font.bold: true
            verticalAlignment: Text.AlignVCenter
            elide: Text.ElideRight
        }

        Text {
            width: 136
            height: row.height
            text: row.value
            color: "#d7e3ed"
            font.pixelSize: 12
            font.bold: true
            horizontalAlignment: Text.AlignRight
            verticalAlignment: Text.AlignVCenter
            elide: Text.ElideRight
        }
    }

    component LineChart: Canvas {
        id: chart
        property var points: []
        onPointsChanged: requestPaint()

        onPaint: {
            var ctx = getContext("2d");
            ctx.clearRect(0, 0, width, height);
            var padL = 62;
            var padR = 18;
            var padT = 22;
            var padB = 34;
            var plotW = width - padL - padR;
            var plotH = height - padT - padB;
            var rows = chart.points || [];
            var maxV = 1;
            var minV = 0;
            for (var i = 0; i < rows.length; i++) {
                maxV = Math.max(maxV, rows[i].input, rows[i].output, rows[i].net);
                minV = Math.min(minV, rows[i].net);
            }
            var range = Math.max(1, maxV - minV);
            var au = root.axisUnit(Math.max(Math.abs(maxV), Math.abs(minV)), false);
            ctx.strokeStyle = "#143a56";
            ctx.lineWidth = 1;
            ctx.fillStyle = root.mutedTextColor;
            ctx.font = "11px sans-serif";
            ctx.textAlign = "left";
            for (var gy = 0; gy <= 4; gy++) {
                var y = padT + plotH * gy / 4;
                ctx.beginPath();
                ctx.moveTo(padL, y);
                ctx.lineTo(width - padR, y);
                ctx.stroke();
                var label = maxV - range * gy / 4;
                ctx.fillText(root.comma(label / au.divisor, au.digits), 4, y + 4);
            }
            ctx.fillText(au.unit, 4, padT - 1);
            function xAt(index) { return padL + plotW * index / Math.max(1, rows.length - 1); }
            function yAt(value) { return padT + (maxV - value) / range * plotH; }
            function drawLine(key, color) {
                if (rows.length < 2)
                    return;
                ctx.beginPath();
                for (var j = 0; j < rows.length; j++) {
                    var x = xAt(j);
                    var y = yAt(rows[j][key]);
                    if (j === 0)
                        ctx.moveTo(x, y);
                    else
                        ctx.lineTo(x, y);
                }
                ctx.strokeStyle = color;
                ctx.lineWidth = 2.4;
                ctx.stroke();
            }
            drawLine("input", root.blueColor);
            drawLine("output", root.greenColor);
            drawLine("net", root.violetColor);
            ctx.fillStyle = root.mutedTextColor;
            var labelStep = Math.max(2, Math.ceil(rows.length / 12));
            for (var lx = 0; lx < rows.length; lx += labelStep)
                ctx.fillText(rows[lx].label, xAt(lx) - 16, height - 10);
        }
    }

    component TrendChart: Canvas {
        id: chart
        property var points: []
        property bool percent: false
        onPointsChanged: requestPaint()
        onPercentChanged: requestPaint()

        onPaint: {
            var ctx = getContext("2d");
            ctx.clearRect(0, 0, width, height);
            var rows = chart.points || [];
            var padL = 52;
            var padT = 22;
            var padB = 30;
            var plotW = width - padL - 16;
            var plotH = height - padT - padB;
            var maxV = 1;
            for (var i = 0; i < rows.length; i++)
                maxV = Math.max(maxV, rows[i].input, rows[i].output);
            var au = root.axisUnit(maxV, chart.percent);
            ctx.strokeStyle = "#143a56";
            ctx.fillStyle = root.mutedTextColor;
            ctx.font = "11px sans-serif";
            for (var gy = 0; gy <= 4; gy++) {
                var y = padT + plotH * gy / 4;
                ctx.beginPath();
                ctx.moveTo(padL, y);
                ctx.lineTo(width - 12, y);
                ctx.stroke();
                ctx.textAlign = "right";
                ctx.fillText(root.comma(maxV * (1 - gy / 4) / au.divisor, au.digits), padL - 8, y + 4);
            }
            ctx.textAlign = "left";
            ctx.fillText(au.unit, 4, padT - 1);
            var gap = plotW / Math.max(1, rows.length);
            var barW = Math.min(24, gap * 0.36);
            for (var j = 0; j < rows.length; j++) {
                var cx = padL + gap * j + gap / 2;
                var outH = rows[j].output / maxV * plotH;
                var inH = rows[j].input / maxV * plotH;
                ctx.fillStyle = root.greenColor;
                ctx.globalAlpha = 0.78;
                ctx.fillRect(cx - barW, padT + plotH - outH, barW, outH);
                ctx.fillStyle = root.blueColor;
                ctx.fillRect(cx, padT + plotH - inH, barW, inH);
                ctx.globalAlpha = 1.0;
                ctx.fillStyle = root.mutedTextColor;
                ctx.textAlign = "center";
                ctx.fillText(rows[j].label || (rows[j].fullDate ? rows[j].fullDate.slice(0, 5) : ""), cx, height - 8);
            }
            ctx.beginPath();
            for (var k = 0; k < rows.length; k++) {
                var x = padL + gap * k + gap / 2;
                var yNet = padT + plotH - rows[k].net / maxV * plotH;
                if (k === 0)
                    ctx.moveTo(x, yNet);
                else
                    ctx.lineTo(x, yNet);
            }
            ctx.strokeStyle = root.violetColor;
            ctx.lineWidth = 2;
            ctx.stroke();
        }
    }

    component DonutChart: Item {
        id: donut
        property var rows: []
        property string totalText: ""
        property string unitText: "kWh"
        onRowsChanged: donutCanvas.requestPaint()
        onTotalTextChanged: donutCanvas.requestPaint()
        onUnitTextChanged: donutCanvas.requestPaint()

        function requestPaint() {
            donutCanvas.requestPaint();
        }

        Canvas {
            id: donutCanvas
            anchors.fill: parent
            onPaint: {
                var ctx = getContext("2d");
                ctx.clearRect(0, 0, width, height);
                var rows = donut.rows || [];
                var total = 0;
                for (var i = 0; i < rows.length; i++)
                    total += rows[i].value;
                var cx = width / 2;
                var cy = height / 2;
                var radius = Math.min(width, height) / 2 - 6;
                var start = -Math.PI / 2;
                for (var j = 0; j < rows.length; j++) {
                    var angle = rows[j].value / Math.max(1, total) * Math.PI * 2;
                    ctx.beginPath();
                    ctx.moveTo(cx, cy);
                    ctx.arc(cx, cy, radius, start, start + angle);
                    ctx.closePath();
                    ctx.fillStyle = rows[j].color;
                    ctx.globalAlpha = 0.9;
                    ctx.fill();
                    start += angle;
                }
                ctx.globalAlpha = 1.0;
                ctx.beginPath();
                ctx.arc(cx, cy, radius * 0.58, 0, Math.PI * 2);
                ctx.fillStyle = root.panelColor;
                ctx.fill();
                ctx.fillStyle = root.textColor;
                ctx.font = "bold " + (donut.totalText.length > 7 ? 16 : 18) + "px sans-serif";
                ctx.textAlign = "center";
                ctx.fillText(donut.totalText, cx, cy - 2);
                ctx.fillStyle = root.mutedTextColor;
                ctx.font = "bold 12px sans-serif";
                ctx.fillText(donut.unitText, cx, cy + 18);
            }
            Component.onCompleted: requestPaint()
        }
    }

    component LegendList: Column {
        id: list
        property var rows: []

        spacing: 9
        Repeater {
            model: list.rows || []
            Row {
                id: legendRow
                required property var modelData
                width: list.width
                height: 20
                spacing: 8

                Rectangle {
                    width: 13
                    height: 13
                    radius: 3
                    color: legendRow.modelData.color
                    anchors.verticalCenter: parent.verticalCenter
                }

                Text {
                    width: Math.max(78, list.width * 0.42)
                    height: parent.height
                    text: legendRow.modelData.label
                    color: "#d7e3ed"
                    font.pixelSize: 11
                    font.bold: true
                    elide: Text.ElideRight
                    verticalAlignment: Text.AlignVCenter
                }

                Text {
                    width: list.width - 29 - Math.max(78, list.width * 0.42)
                    height: parent.height
                    text: root.comma(legendRow.modelData.value, 0) + " (" + root.fmt(legendRow.modelData.percent, 1) + "%)"
                    color: "#d7e3ed"
                    font.pixelSize: 10
                    horizontalAlignment: Text.AlignRight
                    verticalAlignment: Text.AlignVCenter
                    elide: Text.ElideRight
                }
            }
        }
    }

    component LegendDot: Row {
        id: dot
        property string label: ""
        property color accent: root.blueColor

        height: 16
        spacing: 8
        Rectangle { width: 24; height: 4; radius: 2; color: dot.accent; anchors.verticalCenter: parent.verticalCenter }
        Text { text: dot.label; color: root.mutedTextColor; font.pixelSize: 11; font.bold: true; anchors.verticalCenter: parent.verticalCenter }
    }

    component SmallTab: Rectangle {
        id: tab
        property string label: ""
        property bool selected: false
        signal clicked()

        width: 44
        height: 30
        radius: 6
        color: selected ? "#0d72d9" : tabMouse.containsMouse ? "#0a2438" : "#081827"
        border.color: selected ? "#1894ff" : tabMouse.containsMouse ? root.blueColor : "#173852"
        border.width: 1
        Text {
            anchors.centerIn: parent
            text: tab.label
            color: tab.selected ? "#eaf6ff" : root.mutedTextColor
            font.pixelSize: 12
            font.bold: true
        }

        MouseArea {
            id: tabMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: tab.clicked()
        }
    }

    component ReportRow: Row {
        id: row
        property string dateText: ""
        property string inputText: ""
        property string outputText: ""
        property string netText: ""
        property string efficiencyText: ""

        height: 18
        Text { width: 84; height: parent.height; text: row.dateText; color: "#d7e3ed"; font.pixelSize: 10; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
        Text { width: 90; height: parent.height; text: row.inputText; color: "#d7e3ed"; font.pixelSize: 10; horizontalAlignment: Text.AlignRight; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
        Text { width: 96; height: parent.height; text: row.outputText; color: "#d7e3ed"; font.pixelSize: 10; horizontalAlignment: Text.AlignRight; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
        Text { width: 102; height: parent.height; text: row.netText; color: "#d7e3ed"; font.pixelSize: 10; horizontalAlignment: Text.AlignRight; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
        Text { width: 46; height: parent.height; text: row.efficiencyText; color: "#d7e3ed"; font.pixelSize: 10; horizontalAlignment: Text.AlignRight; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
    }
}

