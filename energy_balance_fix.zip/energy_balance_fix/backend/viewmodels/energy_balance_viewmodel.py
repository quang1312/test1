from __future__ import annotations

import time
from datetime import date, datetime, timedelta
from typing import Any

from PySide6.QtCore import Property, QObject, Signal, Slot

from backend.models.data import PmsDataStore
from backend.models.energy_balance_data import (
    EnergyBalanceFlowItem,
    EnergyBalanceReportRow,
    EnergyBalanceSnapshot,
    EnergyBalanceSummaryRow,
    EnergyBalanceTimePoint,
)
from backend.models.runtime import PowerHistoryPoint
from backend.models.topology import PmsTopology
from backend.services.events.event_data_service import EventDataService, SimulatorEventService
from backend.services.historian.historian_service import (
    HistorianService,
    SimulatorHistorianService,
    elapsed_buckets,
    local_datetime_for_date,
    local_today_iso,
)
from backend.services.realtime.realtime_service import RealtimeService, SimulatorRealtimeService
from backend.viewmodels.pms_topology_viewmodel import PmsTopologyViewModel

class EnergyBalanceViewModel(QObject):

    selectedGridChanged = Signal()
    dataChanged = Signal()

    _GRID = "_CFG_PWRSRCTYPE_GRID"
    _SOLAR = "_CFG_PWRSRCTYPE_SOLAR"
    _BESS = "_CFG_PWRSRCTYPE_BESS"
    _LOAD = "_CFG_PWRSRCTYPE_LOAD"

    def __init__(
        self,
        topology_vm: PmsTopologyViewModel,
        realtime_service: RealtimeService | None = None,
        data_store: PmsDataStore | None = None,
        historian_service: HistorianService | None = None,
        event_service: EventDataService | None = None,
    ):
        super().__init__()
        self._topology_vm = topology_vm
        self._realtime_service = realtime_service or SimulatorRealtimeService()
        self._data_store = data_store or PmsDataStore()
        self._historian_service = historian_service or SimulatorHistorianService()
        self._event_service = event_service or SimulatorEventService()
        self._snapshot_memo: dict[tuple, tuple[float, dict]] = {}
        self._topology_vm.configChanged.connect(self._handle_config_changed)
        self._topology_vm.selectedGridChanged.connect(self._handle_selected_grid_changed)

    @Property("QVariant", notify=dataChanged)
    def availableGrids(self):
        return [item.to_dict() for item in self._topology.main_grids]

    @Property(int, notify=selectedGridChanged)
    def selectedGridId(self):
        return self._topology_vm.selectedGridId

    @Property(str, notify=selectedGridChanged)
    def selectedGridName(self):
        grid = self._topology.grid_by_id(self._topology_vm.selectedGridId)
        return grid.name if grid else ""

    @Slot(int)
    def setSelectedGrid(self, grid_id: int):
        self._topology_vm.setSelectedGrid(grid_id)

    @Slot(str)
    def setSelectedGridByName(self, grid_name: str):
        for grid in self._topology.main_grids:
            if grid.name == grid_name:
                self.setSelectedGrid(grid.id)
                return

    _MEMO_TTL_S = 2.0

    @Slot(str, str, str, str, str, str, result="QVariant")
    def energyBalanceSnapshot(
        self,
        selected_date: str,
        selected_time_range: str,
        selected_site: str,
        selected_view_mode: str,
        trend_metric: str,
        trend_period: str,
    ):
        args = (
            str(selected_date or ""),
            str(selected_time_range or ""),
            str(selected_site or self.selectedGridName),
            str(selected_view_mode or "Energy (kWh)"),
            str(trend_metric or "kWh"),
            str(trend_period or "Daily"),
        )
        # Flows come only from MySQL/Influx caches (never from the realtime store), so the
        # old realtime_service.refresh() call here was pure overhead on the UI thread.
        key = (self._topology_vm.selectedGridId,) + args
        now = time.monotonic()
        hit = self._snapshot_memo.get(key)
        if hit is not None and now - hit[0] < self._MEMO_TTL_S:
            return hit[1]
        snapshot, pending, note = self._build_snapshot(*args)
        result = snapshot.to_dict()
        result["pending"] = pending          # True -> background data still loading, caller should re-poll
        result["note"] = note                # non-empty -> short message for the status chip
        if not pending:
            if len(self._snapshot_memo) > 32:
                self._snapshot_memo.clear()
            self._snapshot_memo[key] = (now, result)
        self._prefetch_other_grids(args[0], args[5])
        return result

    def _prefetch_other_grids(self, selected_date: str, trend_period: str) -> None:
        """Warm the (non-blocking) MySQL caches of the other grids so switching grid is instant."""
        current = self._topology_vm.selectedGridId
        days = self._dates_in_range(selected_date)
        trend_start, trend_end = self._trend_window(trend_period)
        for grid in self._topology.main_grids:
            if grid.id == current:
                continue
            self._event_service.get_finance_agg_range(grid.id, days[0], days[-1])
            self._event_service.get_finance_agg_range(grid.id, trend_start, trend_end)

    @property
    def _topology(self) -> PmsTopology:
        return self._topology_vm.topology_model

    def _handle_config_changed(self):
        self.dataChanged.emit()

    def _handle_selected_grid_changed(self):
        self.selectedGridChanged.emit()
        self.dataChanged.emit()

    _MAX_PARTIAL_DAYS = 31

    def _build_snapshot(
        self,
        selected_date: str,
        selected_time_range: str,
        selected_site: str,
        selected_view_mode: str,
        trend_metric: str,
        trend_period: str,
    ) -> tuple[EnergyBalanceSnapshot, bool, str]:
        grid_id = self._topology_vm.selectedGridId
        grid = self._topology.grid_by_id(grid_id)

        days = self._dates_in_range(selected_date)
        start_hour, end_hour = self._hour_bounds_from_range(selected_time_range)
        whole = self._whole_day(selected_time_range, start_hour, end_hour)
        multi = len(days) > 1
        note = ""

        # ONE MySQL range lookup for the selected dates and ONE for the trend/yesterday window.
        selected_map = self._event_service.get_finance_agg_range(grid_id, days[0], days[-1])
        trend_start, trend_end = self._trend_window(trend_period)
        trend_map = self._event_service.get_finance_agg_range(grid_id, trend_start, trend_end)
        pending = bool(getattr(self._event_service, "finance_agg_async", False)) and (
            selected_map is None or trend_map is None
        )

        # Hourly historian points are needed (a) for a partial-hour window (finance_agg_daily
        # only has whole-day totals) and (b) for the by-time-of-day chart of a single day.
        # A whole-day multi-day range uses the daily aggregates instead (no extra queries).
        hourly_days: list[str] = []
        if not whole:
            if len(days) > self._MAX_PARTIAL_DAYS:
                note = f"Time window supports up to {self._MAX_PARTIAL_DAYS} days; select a shorter range"
            else:
                hourly_days = days
        elif not multi:
            hourly_days = days[:1]
        hist = {day: self._day_points(grid_id, day) for day in hourly_days}
        if bool(getattr(self._historian_service, "history_async", False)) and any(not pts for pts in hist.values()):
            pending = True

        totals = dict.fromkeys(self._COMPONENT_KEYS, 0.0)
        per_day: list[tuple[str, dict[str, float]]] = []
        if not note:
            for day in days:
                comp = self._day_components(day, whole, selected_map, hist, start_hour, end_hour)
                if comp is None:
                    continue
                per_day.append((day, comp))
                for key in self._COMPONENT_KEYS:
                    totals[key] += comp[key]

        input_rows, output_rows = self._flow_items(totals)
        total_input = sum(item.value for item in input_rows)
        total_output = sum(item.value for item in output_rows)
        loss = max(0.0, total_input - total_output)
        net = total_input - total_output
        efficiency = min(100.0, total_output / max(1.0, total_input) * 100.0)
        carbon = None
        # Savings only exist as whole-day figures -> no value for a partial window.
        financial_totals = self._financial_totals(selected_map, days) if whole else None

        input_rows = self._with_percent(input_rows, total_input)
        output_rows = self._with_percent(output_rows, total_output)
        time_series = self._time_series(multi, per_day, hist.get(days[0]), start_hour, end_hour)
        trend_rows = self._trend_rows(trend_map, trend_metric, trend_period)
        changes = self._vs_yesterday_changes(trend_map)

        snapshot = EnergyBalanceSnapshot(
            selectedDate=selected_date,
            selectedTimeRange=selected_time_range,
            selectedSite=grid.name if grid else selected_site,
            selectedViewMode="Percent (%)" if selected_view_mode == "Percent (%)" else "Energy (kWh)",
            trendMetric="%" if trend_metric == "%" else "kWh",
            trendPeriod=trend_period,
            gridId=grid_id,
            gridName=grid.name if grid else "",
            sourceRows=input_rows,
            outputRows=output_rows,
            summaryRows=self._summary_rows(total_input, total_output, net, loss, efficiency, carbon, financial_totals),
            timeSeries=time_series,
            trendRows=trend_rows,
            totalInputKwh=round(total_input, 1),
            totalOutputKwh=round(total_output, 1),
            lossKwh=round(loss, 1),
            netKwh=round(net, 1),
            efficiencyPct=round(efficiency, 1),
            carbonTon=carbon,
            totalInputChangePct=changes["input"],
            totalOutputChangePct=changes["output"],
            lossChangePct=changes["loss"],
            netChangePct=changes["net"],
            efficiencyChangePct=changes["efficiency"],
            carbonChangePct=None,
        )
        return snapshot, pending, note

    def _day_points(self, grid_id: int, day_iso: str) -> list[PowerHistoryPoint]:
        return self._historian_service.get_power_history(
            grid_id, self._topology, "Today", anchor=local_datetime_for_date(day_iso)
        )

    @staticmethod
    def _point_hour(point: PowerHistoryPoint) -> int | None:
        try:
            return int(point.hour_label[:2])
        except (ValueError, TypeError):
            return None

    @staticmethod
    def _point_components(point: PowerHistoryPoint) -> dict[str, float]:
        """Hourly bucket (avg MW over 1 h) -> kWh per flow, same sign convention as the daily table."""
        return {
            "grid_in": max(0.0, point.grid_mw) * 1000.0,
            "pv": max(0.0, point.pv_mw) * 1000.0,
            "bess_dis": max(0.0, point.bess_mw) * 1000.0,
            "load": point.load_mw * 1000.0,
            "grid_export": max(0.0, -point.grid_mw) * 1000.0,
            "bess_charge": max(0.0, -point.bess_mw) * 1000.0,
        }

    def _day_components(
        self,
        day_iso: str,
        whole: bool,
        day_map: dict[str, dict] | None,
        hist: dict[str, list[PowerHistoryPoint]],
        start_hour: int,
        end_hour: int,
    ) -> dict[str, float] | None:
        if whole:
            row = (day_map or {}).get(day_iso)
            return None if row is None else {key: row.get(key, 0.0) for key in self._COMPONENT_KEYS}
        totals = dict.fromkeys(self._COMPONENT_KEYS, 0.0)
        found = False
        for point in hist.get(day_iso) or []:
            hour = self._point_hour(point)
            if hour is None or not point.has_data or not self._hour_in_range(hour, start_hour, end_hour):
                continue
            found = True
            for key, value in self._point_components(point).items():
                totals[key] += value
        return totals if found else None

    def _flow_items(
        self, totals: dict[str, float]
    ) -> tuple[list[EnergyBalanceFlowItem], list[EnergyBalanceFlowItem]]:
        input_rows = [
            EnergyBalanceFlowItem("grid_import", "Grid Import", round(totals["grid_in"], 1), 0.0, "#128cff", "import", 0, self._GRID),
            EnergyBalanceFlowItem("solar", "Solar PV", round(totals["pv"], 1), 0.0, "#ffc323", "sun-electricity", 0, self._SOLAR),
            EnergyBalanceFlowItem("bess_discharge", "BESS Discharge", round(totals["bess_dis"], 1), 0.0, "#dc2626", "bat_discharging", 0, self._BESS),
        ]
        output_rows = [
            EnergyBalanceFlowItem("load", "Load", round(totals["load"], 1), 0.0, "#3bd15b", "factory", 0, self._LOAD),
            EnergyBalanceFlowItem("bess_charge", "BESS Charge", round(totals["bess_charge"], 1), 0.0, "#8b5cf6", "bat_charging", 0, self._BESS),
            EnergyBalanceFlowItem("grid_export", "Grid Export", round(totals["grid_export"], 1), 0.0, "#20c7d7", "export", 0, self._GRID),
        ]
        return input_rows, output_rows

    # ---- trend periods -------------------------------------------------------------------
    def _trend_periods(self, trend_period: str) -> list[tuple[date, date, str, str]]:
        """(start, end, fullDate, shortLabel) for the 7 trend buckets, oldest first."""
        today = datetime.fromisoformat(local_today_iso()).date()
        periods: list[tuple[date, date, str, str]] = []
        for age in range(self._TREND_COUNT - 1, -1, -1):
            if trend_period == "Weekly":
                end = today - timedelta(days=age * 7)
                start = end - timedelta(days=6)
                periods.append((start, end, start.strftime("%d/%m/%Y"), start.strftime("%d/%m")))
            elif trend_period == "Monthly":
                month_index = today.year * 12 + (today.month - 1) - age
                year, month = divmod(month_index, 12)
                start = date(year, month + 1, 1)
                nxt = date(year + (month + 1) // 12, (month + 1) % 12 + 1, 1)
                end = min(today, nxt - timedelta(days=1))
                periods.append((start, end, start.strftime("%m/%Y"), start.strftime("%m/%y")))
            else:
                day = today - timedelta(days=age)
                periods.append((day, day, day.strftime("%d/%m/%Y"), day.strftime("%d/%m")))
        return periods

    def _trend_window(self, trend_period: str) -> tuple[str, str]:
        periods = self._trend_periods(trend_period)
        return periods[0][0].isoformat(), periods[-1][1].isoformat()

    _COMPONENT_KEYS = ("grid_in", "pv", "bess_dis", "load", "grid_export", "bess_charge")
    _TREND_COUNT = 7

    @staticmethod
    def _whole_day(selected_time_range: str, start_hour: int, end_hour: int) -> bool:
        return all(EnergyBalanceViewModel._hour_in_range_static(h, start_hour, end_hour) for h in range(24))

    @staticmethod
    def _hour_in_range_static(hour: int, start_hour: int, end_hour: int) -> bool:
        if start_hour <= end_hour:
            return start_hour <= hour <= end_hour
        return hour >= start_hour or hour <= end_hour

    _MAX_RANGE_DAYS = 92

    def _dates_in_range(self, selected_date: str) -> list[str]:
        start, end = self._parse_date_range(selected_date)
        if start is None or end is None:
            return [local_today_iso()]
        if end < start:
            start, end = end, start
        span_days = min((end - start).days, self._MAX_RANGE_DAYS - 1)
        return [(start + timedelta(days=i)).isoformat() for i in range(span_days + 1)]

    @staticmethod
    def _parse_date_range(selected_date: str) -> tuple[date | None, date | None]:
        parts = [part.strip() for part in selected_date.split(" - ", 1)]
        start = EnergyBalanceViewModel._parse_display_date(parts[0])
        end = EnergyBalanceViewModel._parse_display_date(parts[-1])
        return start, end

    @staticmethod
    def _parse_display_date(value: str) -> date | None:
        # QML formats picked dates as "dd/MM/yyyy" (see EnergyBalancePanel.qml's DateTimeRangePicker).
        try:
            return datetime.strptime(value.strip(), "%d/%m/%Y").date()
        except (ValueError, AttributeError):
            return None

    def _with_percent(
        self,
        rows: list[EnergyBalanceFlowItem],
        total: float,
    ) -> list[EnergyBalanceFlowItem]:
        return [
            EnergyBalanceFlowItem(
                key=row.key,
                label=row.label,
                value=row.value,
                percent=round(row.value / max(1.0, total) * 100.0, 1),
                color=row.color,
                icon=row.icon,
                group_id=row.group_id,
                group_type=row.group_type,
            )
            for row in rows
        ]

    _FINANCIAL_KEYS = ("saving_load_only",)

    def _financial_totals(self, day_map: dict[str, dict] | None, days: list[str]) -> dict[str, float] | None:
        if not day_map:
            return None
        totals = dict.fromkeys(self._FINANCIAL_KEYS, 0.0)
        found_any = False
        for day_iso in days:
            row = day_map.get(day_iso)
            if row is None:
                continue
            found_any = True
            for key in self._FINANCIAL_KEYS:
                totals[key] += row.get(key, 0.0)
        return totals if found_any else None

    def _summary_rows(
        self,
        total_input: float,
        total_output: float,
        net: float,
        loss: float,
        efficiency: float,
        carbon: float | None,
        financial_totals: dict[str, float] | None,
    ) -> list[EnergyBalanceSummaryRow]:
        if financial_totals is not None:
            savings_value = f"{financial_totals['saving_load_only'] / 1_000_000:,.2f} trđ"
        else:
            savings_value = "--"
        carbon_value = f"{carbon:.2f} ton" if carbon is not None else "--"
        return [
            EnergyBalanceSummaryRow("Total Energy Input", f"{total_input:,.0f} kWh", "#128cff", "./assets/icons/energy_input.svg"),
            EnergyBalanceSummaryRow("Total Energy Output", f"{total_output:,.0f} kWh", "#3bd15b", "./assets/icons/energy_output.svg"),
            EnergyBalanceSummaryRow("Net Energy Balance", f"{net:,.0f} kWh", "#8b5cf6", "./assets/icons/energy_balance.svg"),
            EnergyBalanceSummaryRow("Energy Losses", f"{loss:,.0f} kWh", "#ff4038", "./assets/icons/energy_loss.svg"),
            EnergyBalanceSummaryRow("Balance Efficiency", f"{efficiency:.1f}%", "#20c7d7", "./assets/icons/efficiency.svg"),
            EnergyBalanceSummaryRow("EMS Savings", savings_value, "#22c55e", "./assets/icons/saving_cost.svg"),
            EnergyBalanceSummaryRow("Carbon Emissions", carbon_value, "#22c55e", "./assets/icons/carbon.svg"),
        ]

    def _time_series(
        self,
        multi: bool,
        per_day: list[tuple[str, dict[str, float]]],
        day_points: list[PowerHistoryPoint] | None,
        start_hour: int,
        end_hour: int,
    ) -> list[EnergyBalanceTimePoint]:
        if multi:
            # Several days: one point per day (same numbers as the KPI totals).
            rows = []
            for day_iso, comp in per_day:
                input_kwh = comp["grid_in"] + comp["pv"] + comp["bess_dis"]
                output_kwh = comp["load"] + comp["grid_export"] + comp["bess_charge"]
                rows.append(EnergyBalanceTimePoint(
                    label=datetime.fromisoformat(day_iso).strftime("%d/%m"),
                    input=round(input_kwh, 1), output=round(output_kwh, 1),
                    net=round(input_kwh - output_kwh, 1),
                ))
            return rows
        entries: list[tuple[int, EnergyBalanceTimePoint]] = []
        for point in day_points or []:
            hour = self._point_hour(point)
            if hour is None or not point.has_data or not self._hour_in_range(hour, start_hour, end_hour):
                continue
            comp = self._point_components(point)
            input_kwh = comp["pv"] + comp["grid_in"] + comp["bess_dis"]
            output_kwh = comp["load"] + comp["grid_export"] + comp["bess_charge"]
            sort_key = hour if hour >= start_hour else hour + 24
            entries.append((sort_key, EnergyBalanceTimePoint(
                label=point.hour_label,
                input=round(input_kwh, 1),
                output=round(output_kwh, 1),
                net=round(input_kwh - output_kwh, 1),
            )))
        entries.sort(key=lambda item: item[0])
        return [item[1] for item in entries]

    def _hour_bounds_from_range(self, selected_time_range: str) -> tuple[int, int]:
        try:
            start_raw, end_raw = [part.strip() for part in selected_time_range.split("-", 1)]
            start = datetime.strptime(start_raw, "%H:%M")
            end = datetime.strptime(end_raw, "%H:%M")
            return start.hour, end.hour
        except (ValueError, AttributeError):
            return 0, 23

    def _hour_in_range(self, hour: int, start_hour: int, end_hour: int) -> bool:
        if start_hour <= end_hour:
            return start_hour <= hour <= end_hour
        return hour >= start_hour or hour <= end_hour

    def _trend_rows(
        self,
        trend_map: dict[str, dict] | None,
        trend_metric: str,
        trend_period: str,
    ) -> list[EnergyBalanceReportRow]:
        rows: list[EnergyBalanceReportRow] = []
        if not trend_map:
            return rows
        for start, end, full_label, short_label in self._trend_periods(trend_period):
            totals = dict.fromkeys(self._COMPONENT_KEYS, 0.0)
            found = False
            day = start
            while day <= end:                      # Daily: 1 day, Weekly: 7 days, Monthly: calendar month
                row = trend_map.get(day.isoformat())
                if row is not None:
                    found = True
                    for key in self._COMPONENT_KEYS:
                        totals[key] += row.get(key, 0.0)
                day += timedelta(days=1)
            if not found:
                continue
            input_value = totals["grid_in"] + totals["pv"] + totals["bess_dis"]
            output_value = totals["load"] + totals["grid_export"] + totals["bess_charge"]
            efficiency = min(100.0, output_value / max(1.0, input_value) * 100.0)
            if trend_metric == "%":
                rows.append(EnergyBalanceReportRow(
                    fullDate=full_label, input=100.0, output=round(efficiency, 1),
                    net=round(100.0 - efficiency, 1), efficiency=round(efficiency, 1), label=short_label,
                ))
            else:
                rows.append(EnergyBalanceReportRow(
                    fullDate=full_label, input=round(input_value, 1), output=round(output_value, 1),
                    net=round(input_value - output_value, 1), efficiency=round(efficiency, 1), label=short_label,
                ))
        return rows

    def _vs_yesterday_changes(self, trend_map: dict[str, dict] | None) -> dict[str, float | None]:
        keys = ("input", "output", "loss", "net", "efficiency")
        none = {key: None for key in keys}
        # Only whole-day aggregates exist, so a comparison is only meaningful once the
        # day is fully elapsed (same rule as before, just without any extra query).
        if not trend_map or elapsed_buckets("Today") < 24:
            return none
        today_iso = local_today_iso()
        yesterday_iso = (datetime.fromisoformat(today_iso) - timedelta(days=1)).date().isoformat()
        today_totals = self._breakdown(trend_map.get(today_iso))
        yesterday_totals = self._breakdown(trend_map.get(yesterday_iso))
        if today_totals is None or yesterday_totals is None:
            return none
        return {key: self._pct_change(today_totals[key], yesterday_totals[key]) for key in keys}

    @staticmethod
    def _breakdown(components: dict[str, float] | None) -> dict[str, float] | None:
        if components is None:
            return None
        total_input = components["grid_in"] + components["pv"] + components["bess_dis"]
        total_output = components["load"] + components["grid_export"] + components["bess_charge"]
        return {
            "input": total_input,
            "output": total_output,
            "loss": max(0.0, total_input - total_output),
            "net": total_input - total_output,
            "efficiency": total_output / max(1.0, total_input) * 100.0,
        }

    @staticmethod
    def _pct_change(today_value: float, yesterday_value: float) -> float | None:
        if abs(yesterday_value) < 1e-6:
            return None
        return round((today_value - yesterday_value) / abs(yesterday_value) * 100.0, 1)
