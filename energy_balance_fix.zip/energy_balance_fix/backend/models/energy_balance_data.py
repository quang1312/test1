from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True)
class EnergyBalanceFlowItem:
    key: str
    label: str
    value: float
    percent: float
    color: str
    icon: str
    group_id: int = 0
    group_type: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class EnergyBalanceSummaryRow:
    label: str
    value: str
    color: str
    icon: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class EnergyBalanceTimePoint:
    label: str
    input: float
    output: float
    net: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class EnergyBalanceReportRow:
    fullDate: str
    input: float
    output: float
    net: float
    efficiency: float
    label: str = ""          # short axis label (dd/MM, MM/yy...); empty -> UI derives from fullDate

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class EnergyBalanceSnapshot:
    selectedDate: str = ""
    selectedTimeRange: str = ""
    selectedSite: str = ""
    selectedViewMode: str = "Energy (kWh)"
    trendMetric: str = "kWh"
    trendPeriod: str = "Daily"
    gridId: int = 0
    gridName: str = ""
    sourceRows: list[EnergyBalanceFlowItem] = field(default_factory=list)
    outputRows: list[EnergyBalanceFlowItem] = field(default_factory=list)
    summaryRows: list[EnergyBalanceSummaryRow] = field(default_factory=list)
    timeSeries: list[EnergyBalanceTimePoint] = field(default_factory=list)
    trendRows: list[EnergyBalanceReportRow] = field(default_factory=list)
    totalInputKwh: float = 0.0
    totalOutputKwh: float = 0.0
    lossKwh: float = 0.0
    netKwh: float = 0.0
    efficiencyPct: float = 0.0
    carbonTon: float | None = None
    totalInputChangePct: float | None = None
    totalOutputChangePct: float | None = None
    lossChangePct: float | None = None
    netChangePct: float | None = None
    efficiencyChangePct: float | None = None
    carbonChangePct: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "selectedDate": self.selectedDate,
            "selectedTimeRange": self.selectedTimeRange,
            "selectedSite": self.selectedSite,
            "selectedViewMode": self.selectedViewMode,
            "trendMetric": self.trendMetric,
            "trendPeriod": self.trendPeriod,
            "gridId": self.gridId,
            "gridName": self.gridName,
            "sourceRows": [item.to_dict() for item in self.sourceRows],
            "outputRows": [item.to_dict() for item in self.outputRows],
            "summaryRows": [item.to_dict() for item in self.summaryRows],
            "timeSeries": [item.to_dict() for item in self.timeSeries],
            "trendRows": [item.to_dict() for item in self.trendRows],
            "totalInputKwh": self.totalInputKwh,
            "totalOutputKwh": self.totalOutputKwh,
            "lossKwh": self.lossKwh,
            "netKwh": self.netKwh,
            "efficiencyPct": self.efficiencyPct,
            "carbonTon": self.carbonTon,
            "totalInputChangePct": self.totalInputChangePct,
            "totalOutputChangePct": self.totalOutputChangePct,
            "lossChangePct": self.lossChangePct,
            "netChangePct": self.netChangePct,
            "efficiencyChangePct": self.efficiencyChangePct,
            "carbonChangePct": self.carbonChangePct,
        }
