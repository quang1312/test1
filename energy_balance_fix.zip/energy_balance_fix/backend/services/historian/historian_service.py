from __future__ import annotations

import calendar
import logging
import threading
import time
from abc import ABC, abstractmethod
from collections import OrderedDict
from datetime import datetime, timedelta, timezone

from backend.models.runtime import PowerHistoryPoint
from backend.models.topology import PmsTopology
from backend.services.influx.influx_client import InfluxClient

logger = logging.getLogger(__name__)

_MAX_CACHE_ENTRIES = 256


_HISTORY_TTL_TODAY_S = 3.0        # day still in progress -> new samples keep arriving
_HISTORY_TTL_PAST_S = 300.0       # closed day -> practically immutable


def _history_needs_refresh(ts_map: dict, key: tuple, date_key: str, lock: threading.Lock, cached: bool) -> bool:
    """True when the key was never loaded or its last load is older than the TTL.

    Before, EVERY get_*_history() call started a new thread + Influx query, which turns into a
    query storm as soon as a caller asks for several days (e.g. Energy Balance, hourly x N days)."""
    if not cached:
        return True
    with lock:
        age = time.monotonic() - ts_map.get(key, float("-inf"))
    ttl = _HISTORY_TTL_TODAY_S if date_key >= local_today_iso() else _HISTORY_TTL_PAST_S
    return age > ttl


def _remember(cache: "OrderedDict", key, result, lock: threading.Lock) -> None:
    with lock:
        cache[key] = result
        cache.move_to_end(key)
        while len(cache) > _MAX_CACHE_ENTRIES:
            cache.popitem(last=False)


_LOCAL_TZ = timezone(timedelta(hours=7)) 
PLANT_LOCAL_TZ = _LOCAL_TZ


def _range_start(range_name: str, now: datetime) -> datetime:
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    if range_name == "Last 7 days":
        return today - timedelta(days=6)
    if range_name == "This month":
        return today.replace(day=1)
    if range_name == "This year":
        return today.replace(month=1, day=1)
    return today


def _range_plan(range_name: str, start_dt: datetime) -> tuple[int, str, list[str]]:
    if range_name == "Last 7 days":
        labels = [(start_dt + timedelta(days=i)).strftime("%a %d") for i in range(7)]
        return 7, "day", labels
    if range_name == "This month":
        days_in_month = calendar.monthrange(start_dt.year, start_dt.month)[1]
        labels = [f"{day:02d}" for day in range(1, days_in_month + 1)]
        return days_in_month, "day", labels
    if range_name == "This year":
        labels = [calendar.month_abbr[month] for month in range(1, 13)]
        return 12, "month", labels
    return 24, "hour", [f"{hour:02d}:00" for hour in range(24)]


def local_today_iso(now: datetime | None = None) -> str:
    return (now or datetime.now(_LOCAL_TZ)).date().isoformat()


def local_datetime_for_date(iso_date: str) -> datetime:
    year, month, day = (int(part) for part in iso_date.split("-"))
    return datetime(year, month, day, 12, 0, tzinfo=_LOCAL_TZ)


def elapsed_buckets(range_name: str, now: datetime | None = None) -> int:
    now = now or datetime.now(_LOCAL_TZ)
    if range_name == "This month":
        return now.day
    if range_name == "This year":
        return now.month
    if range_name == "Last 7 days":
        return 7
    return now.hour + 1


def _bucket_start(base: datetime, unit: str, index: int) -> datetime:
    if unit == "hour":
        return base + timedelta(hours=index)
    if unit == "day":
        return base + timedelta(days=index)
    if unit == "month":
        month0 = base.month - 1 + index
        return base.replace(year=base.year + month0 // 12, month=month0 % 12 + 1)
    return base


def _bucket_hours(unit: str, bucket_start: datetime) -> float:
    if unit == "hour":
        return 1.0
    if unit == "day":
        return 24.0
    if unit == "month":
        return calendar.monthrange(bucket_start.year, bucket_start.month)[1] * 24.0
    return 1.0


def to_query_iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _range_bounds(range_name: str, anchor: datetime | None = None) -> tuple[str, str, datetime]:
    start = _range_start(range_name, anchor or datetime.now(_LOCAL_TZ))
    if range_name == "Last 7 days":
        stop = start + timedelta(days=7)
    elif range_name == "This month":
        stop = (start.replace(day=28) + timedelta(days=4)).replace(day=1)
    elif range_name == "This year":
        stop = start.replace(year=start.year + 1)
    else:
        stop = start + timedelta(days=1)
    return to_query_iso(start), to_query_iso(stop), start


def _bucket_index(timestamp: str, unit: str, start_dt: datetime) -> int | None:
    try:
        ts = datetime.fromisoformat(timestamp.replace("Z", "+00:00")).astimezone(_LOCAL_TZ)
    except ValueError:
        return None
    if unit == "hour":
        return ts.hour
    if unit == "day":
        return (ts.date() - start_dt.date()).days
    if unit == "month":
        return (ts.year - start_dt.year) * 12 + (ts.month - start_dt.month)
    return None

GRID_GROUP_TYPE = "_CFG_PWRSRCTYPE_GRID"
SOLAR_GROUP_TYPE = "_CFG_PWRSRCTYPE_SOLAR"
BESS_GROUP_TYPE = "_CFG_PWRSRCTYPE_BESS"
LOAD_GROUP_TYPE = "_CFG_PWRSRCTYPE_LOAD"
ALL_GROUP_TYPES = [GRID_GROUP_TYPE, SOLAR_GROUP_TYPE, BESS_GROUP_TYPE, LOAD_GROUP_TYPE]
SINK_GROUP_TYPES = {LOAD_GROUP_TYPE}

SYSTEM_SNAPSHOT_MEASUREMENT = "system_snapshot"
SNAPSHOT_GROUP_FIELD = "psg_actual_P"
SNAPSHOT_GROUP_FIELD_Q = "psg_actual_Q"
SNAPSHOT_KW_DIVISOR = 10.0


class HistorianService(ABC):
    # True when get_*_history() returns [] only while the first background load is in flight.
    history_async = False

    @abstractmethod
    def get_power_history(
        self, grid_id: int, topology: PmsTopology, range_name: str, anchor: datetime | None = None
    ) -> list[PowerHistoryPoint]:
        raise NotImplementedError

    @abstractmethod
    def get_demand_history(
        self, grid_id: int, topology: PmsTopology, range_name: str, anchor: datetime | None = None
    ) -> list[PowerHistoryPoint]:
        raise NotImplementedError


class SimulatorHistorianService(HistorianService):

    def get_power_history(
        self, grid_id: int, topology: PmsTopology, range_name: str, anchor: datetime | None = None
    ) -> list[PowerHistoryPoint]:
        values = self._grid_values(grid_id, topology)
        return self._build_history(range_name, anchor=anchor, **values)

    def get_demand_history(
        self, grid_id: int, topology: PmsTopology, range_name: str, anchor: datetime | None = None
    ) -> list[PowerHistoryPoint]:
        values = self._grid_values(grid_id, topology)
        return self._build_history(range_name, peak=True, anchor=anchor, **values)

    def _grid_values(self, grid_id: int, topology: PmsTopology) -> dict[str, float]:
        groups = topology.groups_by_grid(grid_id)
        by_type = {item.type: index for index, item in enumerate(groups)}
        return {
            "load_kw": 3670.0 + by_type.get("_CFG_PWRSRCTYPE_LOAD", 0) * 260.0,
            "pv_kw": 5070.0 - by_type.get("_CFG_PWRSRCTYPE_SOLAR", 0) * 320.0,
            "bess_kw": 1010.0 + by_type.get("_CFG_PWRSRCTYPE_BESS", 0) * 180.0,
            "grid_kw": 390.0 + by_type.get("_CFG_PWRSRCTYPE_GRID", 0) * 40.0,
        }

    def _build_history(
        self, range_name: str, load_kw: float, pv_kw: float, bess_kw: float, grid_kw: float,
        peak: bool = False, anchor: datetime | None = None,
    ) -> list[PowerHistoryPoint]:
        start_dt = _range_start(range_name, anchor or datetime.now(_LOCAL_TZ))
        count, unit, labels = _range_plan(range_name, start_dt)
        points: list[PowerHistoryPoint] = []
        for index in range(count):
            factor = 0.78 + 0.22 * ((index % 12) / 11)
            if peak:
                factor *= 1.05 + 0.10 * ((index * 37) % 10) / 10.0
            load_kw_value = load_kw * factor
            hours = _bucket_hours(unit, _bucket_start(start_dt, unit, index))
            points.append(PowerHistoryPoint(
                timestamp=f"2026-07-15T{index % 24:02d}:00:00",
                hour_label=labels[index],
                load_mw=round(load_kw_value / 1000.0, 3),
                pv_mw=round(max(0.0, pv_kw * (1.0 - abs(12 - index % 24) / 14.0)) / 1000.0, 3),
                bess_mw=round(bess_kw / 1000.0, 3),
                grid_mw=round(grid_kw / 1000.0, 3),
                load_kwh=round(load_kw_value * hours, 2),
                bess_charge_kwh=round(max(0.0, -bess_kw) * hours, 2),
            ))
        return points


class InfluxHistorianService(HistorianService):

    history_async = True

    def __init__(self, influx_client: InfluxClient):
        self._influx_client = influx_client
        self._ts: dict[tuple, float] = {}
        self._lock = threading.Lock()
        self._cache: OrderedDict[tuple[int, str, str, str], list[PowerHistoryPoint]] = OrderedDict()
        self._refreshing: set[tuple[int, str, str, str]] = set()

    def get_power_history(
        self, grid_id: int, topology: PmsTopology, range_name: str, anchor: datetime | None = None
    ) -> list[PowerHistoryPoint]:
        return self._get_history(grid_id, topology, range_name, "avg", anchor)

    def get_demand_history(
        self, grid_id: int, topology: PmsTopology, range_name: str, anchor: datetime | None = None
    ) -> list[PowerHistoryPoint]:
        return self._get_history(grid_id, topology, range_name, "max", anchor)

    def _get_history(
        self, grid_id: int, topology: PmsTopology, range_name: str, aggregator: str, anchor: datetime | None = None
    ) -> list[PowerHistoryPoint]:
        date_key = local_today_iso(anchor)
        key = (grid_id, range_name, aggregator, date_key)
        with self._lock:
            cached = key in self._cache
            if cached:
                self._cache.move_to_end(key)
        if _history_needs_refresh(self._ts, key, date_key, self._lock, cached):
            self._schedule_refresh(key, topology, anchor)
        with self._lock:
            return list(self._cache.get(key, []))

    def _schedule_refresh(
        self, key: tuple[int, str, str, str], topology: PmsTopology, anchor: datetime | None
    ) -> None:
        with self._lock:
            if key in self._refreshing:
                return
            self._refreshing.add(key)
        threading.Thread(
            target=self._refresh_worker, args=(key, topology, anchor), daemon=True, name="influx-historian-refresh"
        ).start()

    def _refresh_worker(self, key: tuple[int, str, str, str], topology: PmsTopology, anchor: datetime | None) -> None:
        grid_id, range_name, aggregator, _date_key = key
        try:
            points = self._compute_history(grid_id, topology, range_name, aggregator, anchor)
            _remember(self._cache, key, points, self._lock)
        except Exception:
            logger.exception("InfluxDB historian refresh failed for grid=%s range=%s agg=%s", grid_id, range_name, aggregator)
        finally:
            with self._lock:
                self._ts[key] = time.monotonic()
                self._refreshing.discard(key)

    def _compute_history(
        self, grid_id: int, topology: PmsTopology, range_name: str, aggregator: str, anchor: datetime | None = None
    ) -> list[PowerHistoryPoint]:
        start_iso, stop_iso, start_dt = _range_bounds(range_name, anchor)
        count, unit, labels = _range_plan(range_name, start_dt)
        grid_series = self._group_series(topology, grid_id, GRID_GROUP_TYPE, start_iso, stop_iso, unit, start_dt, aggregator)
        solar_series = self._group_series(topology, grid_id, SOLAR_GROUP_TYPE, start_iso, stop_iso, unit, start_dt, aggregator)
        bess_series = self._group_series(topology, grid_id, BESS_GROUP_TYPE, start_iso, stop_iso, unit, start_dt, aggregator)
        load_series = self._group_series(topology, grid_id, LOAD_GROUP_TYPE, start_iso, stop_iso, unit, start_dt, aggregator, sink=True)
        data_indices = set(grid_series) | set(solar_series) | set(bess_series) | set(load_series)

        points: list[PowerHistoryPoint] = []
        for index in range(count):
            grid_mw = grid_series.get(index, 0.0)
            pv_mw = solar_series.get(index, 0.0)
            bess_mw = bess_series.get(index, 0.0)
            load_mw = load_series.get(index, 0.0)
            points.append(PowerHistoryPoint(
                timestamp=_bucket_start(start_dt, unit, index).isoformat(),
                hour_label=labels[index],
                load_mw=round(load_mw, 3),
                pv_mw=round(pv_mw, 3),
                bess_mw=round(bess_mw, 3),
                grid_mw=round(grid_mw, 3),
                has_data=index in data_indices,
            ))
        return points

    def _group_series(
        self,
        topology: PmsTopology,
        grid_id: int,
        group_type: str,
        start_iso: str,
        stop_iso: str,
        unit: str,
        start_dt: datetime,
        aggregator: str = "avg",
        sink: bool = False,
    ) -> dict[int, float]:
        bucket_totals: dict[int, float] = {}
        for group in topology.groups_by_grid(grid_id):
            if group.type != group_type:
                continue
            rows = self._influx_client.query_range_by_tags(
                SYSTEM_SNAPSHOT_MEASUREMENT, start_iso, stop_iso,
                {"Tgrid_uid": grid_id, "Tpsg_id": group.id},
                fields=[SNAPSHOT_GROUP_FIELD],
            )
            bucket_samples: dict[int, list[float]] = {}
            for row in rows:
                value = row.get(SNAPSHOT_GROUP_FIELD)
                if value is None:
                    continue
                index = _bucket_index(row.get("time", ""), unit, start_dt)
                if index is None:
                    continue
                bucket_samples.setdefault(index, []).append(-float(value) if sink else float(value))
            for index, values in bucket_samples.items():
                agg_value = max(values) if aggregator == "max" else sum(values) / len(values)
                bucket_totals[index] = bucket_totals.get(index, 0.0) + agg_value
        # SNAPSHOT_KW_DIVISOR (raw -> kW) then /1000 (kW -> MW) to match PowerHistoryPoint's unit.
        return {index: total / SNAPSHOT_KW_DIVISOR / 1000.0 for index, total in bucket_totals.items()}


class RollupHistorianService(HistorianService):

    history_async = True

    def __init__(self, hourly_store, daily_store, monthly_store):
        self._ts: dict[tuple, float] = {}
        self._hourly_store = hourly_store
        self._daily_store = daily_store
        self._monthly_store = monthly_store
        self._lock = threading.Lock()
        self._cache: OrderedDict[tuple[int, str, str, str], list[PowerHistoryPoint]] = OrderedDict()
        self._refreshing: set[tuple[int, str, str, str]] = set()

    def get_power_history(
        self, grid_id: int, topology: PmsTopology, range_name: str, anchor: datetime | None = None
    ) -> list[PowerHistoryPoint]:
        return self._get_history(grid_id, range_name, "avg", anchor)

    def get_demand_history(
        self, grid_id: int, topology: PmsTopology, range_name: str, anchor: datetime | None = None
    ) -> list[PowerHistoryPoint]:
        return self._get_history(grid_id, range_name, "max", anchor)

    def _store_for_range(self, range_name: str):
        if range_name == "This year":
            return self._monthly_store
        if range_name in ("Last 7 days", "This month"):
            return self._daily_store
        return self._hourly_store  # "Today" (the default range)

    def _get_history(
        self, grid_id: int, range_name: str, aggregator: str, anchor: datetime | None
    ) -> list[PowerHistoryPoint]:
        date_key = local_today_iso(anchor)
        key = (grid_id, range_name, aggregator, date_key)
        with self._lock:
            cached = key in self._cache
            if cached:
                self._cache.move_to_end(key)
        if _history_needs_refresh(self._ts, key, date_key, self._lock, cached):
            self._schedule_refresh(key, grid_id, range_name, aggregator, anchor)
        with self._lock:
            return list(self._cache.get(key, []))

    def _schedule_refresh(
        self, key: tuple[int, str, str, str], grid_id: int, range_name: str, aggregator: str, anchor: datetime | None
    ) -> None:
        with self._lock:
            if key in self._refreshing:
                return
            self._refreshing.add(key)
        threading.Thread(
            target=self._refresh_worker, args=(key, grid_id, range_name, aggregator, anchor),
            daemon=True, name="rollup-historian-refresh",
        ).start()

    def _refresh_worker(
        self, key: tuple[int, str, str, str], grid_id: int, range_name: str, aggregator: str, anchor: datetime | None
    ) -> None:
        try:
            points = self._compute_history(grid_id, range_name, aggregator, anchor)
            _remember(self._cache, key, points, self._lock)
        except Exception:
            logger.exception("Rollup historian refresh failed for grid=%s range=%s agg=%s", grid_id, range_name, aggregator)
        finally:
            with self._lock:
                self._ts[key] = time.monotonic()
                self._refreshing.discard(key)

    def _compute_history(
        self, grid_id: int, range_name: str, aggregator: str, anchor: datetime | None
    ) -> list[PowerHistoryPoint]:
        start_iso, stop_iso, start_dt = _range_bounds(range_name, anchor)
        count, unit, labels = _range_plan(range_name, start_dt)
        store = self._store_for_range(range_name)
        grid_series = self._series(store, grid_id, GRID_GROUP_TYPE, start_iso, stop_iso, unit, start_dt, aggregator)
        solar_series = self._series(store, grid_id, SOLAR_GROUP_TYPE, start_iso, stop_iso, unit, start_dt, aggregator)
        bess_series = self._series(store, grid_id, BESS_GROUP_TYPE, start_iso, stop_iso, unit, start_dt, aggregator)
        load_series = self._series(store, grid_id, LOAD_GROUP_TYPE, start_iso, stop_iso, unit, start_dt, aggregator)
        data_indices = set(grid_series) | set(solar_series) | set(bess_series) | set(load_series)
        if aggregator == "avg":
            load_energy_series = self._energy_series(store, grid_id, LOAD_GROUP_TYPE, "pos_energy_kwh", start_iso, stop_iso, unit, start_dt)
            bess_charge_series = self._energy_series(store, grid_id, BESS_GROUP_TYPE, "neg_energy_kwh", start_iso, stop_iso, unit, start_dt)
        else:
            load_energy_series = {}
            bess_charge_series = {}

        points: list[PowerHistoryPoint] = []
        for index in range(count):
            points.append(PowerHistoryPoint(
                timestamp=_bucket_start(start_dt, unit, index).isoformat(),
                hour_label=labels[index],
                load_mw=round(load_series.get(index, 0.0), 3),
                pv_mw=round(solar_series.get(index, 0.0), 3),
                bess_mw=round(bess_series.get(index, 0.0), 3),
                grid_mw=round(grid_series.get(index, 0.0), 3),
                has_data=index in data_indices,
                load_kwh=round(load_energy_series.get(index, 0.0), 3),
                bess_charge_kwh=round(bess_charge_series.get(index, 0.0), 3),
            ))
        return points

    def _energy_series(
        self,
        store,
        grid_id: int,
        group_type: str,
        field: str,
        start_iso: str,
        stop_iso: str,
        unit: str,
        start_dt: datetime,
    ) -> dict[int, float]:
        rows = store.query_range(grid_id, group_type, start_iso, stop_iso)
        result: dict[int, float] = {}
        for row in rows:
            index = _bucket_index(row["period_start_utc"], unit, start_dt)
            if index is None:
                continue
            result[index] = result.get(index, 0.0) + row.get(field, 0.0)
        return result

    def _series(
        self,
        store,
        grid_id: int,
        group_type: str,
        start_iso: str,
        stop_iso: str,
        unit: str,
        start_dt: datetime,
        aggregator: str,
    ) -> dict[int, float]:
        rows = store.query_range(grid_id, group_type, start_iso, stop_iso)
        result: dict[int, float] = {}
        for row in rows:
            index = _bucket_index(row["period_start_utc"], unit, start_dt)
            if index is None:
                continue
            value_kw = row["peak_kw"] if aggregator == "max" else row["avg_kw"]
            result[index] = value_kw / 1000.0  # kW rollup rows -> MW, matching PowerHistoryPoint's unit
        return result
