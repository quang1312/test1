from __future__ import annotations

import logging
import threading
import time
from abc import ABC, abstractmethod
from datetime import date, datetime, timedelta

from backend.models.runtime import AlarmSummary, DailyFinancials
from backend.models.topology import PmsTopology
from backend.services.mysql.mysql_client import MySqlClient

logger = logging.getLogger(__name__)


class EventDataService(ABC):
    # True when get_finance_agg_range() returns None only while a background load is
    # still in flight (so callers may poll again). Simulator keeps False: None = no data.
    finance_agg_async = False

    @abstractmethod
    def get_alarm_summary(self, grid_id: int, topology: PmsTopology) -> AlarmSummary:
        raise NotImplementedError

    @abstractmethod
    def get_daily_financials(self, grid_id: int) -> DailyFinancials:
        raise NotImplementedError

    @abstractmethod
    def get_finance_agg_range(self, grid_id: int, start_ymd: str, end_ymd: str) -> dict[str, dict] | None:
        raise NotImplementedError

    @abstractmethod
    def get_alarms(
        self,
        topology: PmsTopology,
        limit: int = 500,
        start_ms: int | None = None,
        end_ms: int | None = None,
        active_only: bool = False,
        total_budget: bool = False,
        history_only: bool = False,
    ) -> list[dict]:
        raise NotImplementedError

    @abstractmethod
    def acknowledge_alarms(self, alarm_ids: list[int]) -> None:
        raise NotImplementedError

    @abstractmethod
    def clear_alarm(self, alarm_id: int) -> None:
        raise NotImplementedError


def alarm_status_for_devices(
    event_service: "EventDataService | None",
    topology: PmsTopology,
    device_ids: set[int] | int,
) -> tuple[str, int]:
    if not event_service:
        return "Normal", 0
    ids = {device_ids} if isinstance(device_ids, int) else device_ids
    if not ids:
        return "Normal", 0
    alarms = event_service.get_alarms(topology, active_only=True)
    active = [item for item in alarms if item.get("deviceUid") in ids and item.get("status") == "Active"]
    if not active:
        return "Normal", 0
    levels = {item.get("level") for item in active}
    if levels & {"Critical", "Fault"}:
        return "Fault", len(active)
    if "Warning" in levels:
        return "Warning", len(active)
    return "Normal", len(active)


class SimulatorEventService(EventDataService):

    def get_alarm_summary(self, grid_id: int, topology: PmsTopology) -> AlarmSummary:
        return AlarmSummary()

    def get_daily_financials(self, grid_id: int) -> DailyFinancials:
        return DailyFinancials()

    def get_finance_agg_range(self, grid_id: int, start_ymd: str, end_ymd: str) -> dict[str, dict] | None:
        return None

    def get_alarms(
        self,
        topology: PmsTopology,
        limit: int = 500,
        start_ms: int | None = None,
        end_ms: int | None = None,
        active_only: bool = False,
        total_budget: bool = False,
        history_only: bool = False,
    ) -> list[dict]:
        return []

    def acknowledge_alarms(self, alarm_ids: list[int]) -> None:
        pass

    def clear_alarm(self, alarm_id: int) -> None:
        pass


class MySqlEventService(EventDataService):

    finance_agg_async = True
    _FINANCE_AGG_TTL_RECENT_S = 5.0      # range includes today/yesterday -> numbers still move
    _FINANCE_AGG_TTL_PAST_S = 300.0      # purely historical range -> practically immutable
    _ACTIVE_ALARMS_SAFETY_CAP = 5000
    _ALARM_COLUMNS = (
        "id, device_uid, alarm_id, is_active, is_acknowledged, level, action, "
        "start_time, acked_time, stop_time, description"
    )
    _SOURCE_TYPE_LABELS = {
        "_CFG_PWRSRCTYPE_GRID": "Grid",
        "_CFG_PWRSRCTYPE_SOLAR": "PV",
        "_CFG_PWRSRCTYPE_LOAD": "Load",
        "_CFG_PWRSRCTYPE_BESS": "BESS",
    }

    def __init__(self, mysql_client: MySqlClient):
        self._mysql_client = mysql_client
        self._lock = threading.Lock()
        self._cache: dict[int, AlarmSummary] = {}
        self._refreshing: set[int] = set()
        self._financials_cache: dict[int, DailyFinancials] = {}
        self._financials_refreshing: set[int] = set()
        self._finance_agg_cache: dict[tuple, dict[str, dict]] = {}
        self._finance_agg_refreshing: set[tuple] = set()
        self._finance_agg_ts: dict[tuple, float] = {}
        self._alarms_cache: dict[tuple, list[dict]] = {}
        self._alarms_refreshing: set[tuple] = set()
        self._logged_errors: set[str] = set()

    def _log_once(self, key: str, msg: str, *args) -> None:
        if key in self._logged_errors:
            return
        self._logged_errors.add(key)
        logger.exception(msg, *args)

    def get_alarm_summary(self, grid_id: int, topology: PmsTopology) -> AlarmSummary:
        self._schedule_refresh(grid_id)
        with self._lock:
            return self._cache.get(grid_id, AlarmSummary())

    def _schedule_refresh(self, grid_id: int) -> None:
        with self._lock:
            if grid_id in self._refreshing:
                return
            self._refreshing.add(grid_id)
        threading.Thread(
            target=self._refresh_worker, args=(grid_id,), daemon=True, name="mysql-alarm-refresh"
        ).start()

    def _refresh_worker(self, grid_id: int) -> None:
        key = f"alarm_summary:{grid_id}"
        try:
            summary = self._compute_alarm_summary(grid_id)
            with self._lock:
                self._cache[grid_id] = summary
            self._logged_errors.discard(key)
        except Exception:
            self._log_once(key, "MySQL alarm summary refresh failed for grid=%s", grid_id)
        finally:
            with self._lock:
                self._refreshing.discard(grid_id)

    def get_daily_financials(self, grid_id: int) -> DailyFinancials:
        self._schedule_financials_refresh(grid_id)
        with self._lock:
            return self._financials_cache.get(grid_id, DailyFinancials())

    def _schedule_financials_refresh(self, grid_id: int) -> None:
        with self._lock:
            if grid_id in self._financials_refreshing:
                return
            self._financials_refreshing.add(grid_id)
        threading.Thread(
            target=self._refresh_financials_worker, args=(grid_id,), daemon=True,
            name="mysql-financials-refresh",
        ).start()

    def _refresh_financials_worker(self, grid_id: int) -> None:
        key = f"financials:{grid_id}"
        try:
            financials = self._compute_daily_financials(grid_id)
            with self._lock:
                self._financials_cache[grid_id] = financials
            self._logged_errors.discard(key)
        except Exception:
            self._log_once(key, "MySQL daily financials refresh failed for grid=%s", grid_id)
        finally:
            with self._lock:
                self._financials_refreshing.discard(grid_id)

    def get_finance_agg_range(self, grid_id: int, start_ymd: str, end_ymd: str) -> dict[str, dict] | None:
        key = (grid_id, start_ymd, end_ymd)
        with self._lock:
            cached = self._finance_agg_cache.get(key)
            age = time.monotonic() - self._finance_agg_ts.get(key, float("-inf"))
        recent = end_ymd >= (date.today() - timedelta(days=1)).isoformat()
        ttl = self._FINANCE_AGG_TTL_RECENT_S if recent else self._FINANCE_AGG_TTL_PAST_S
        # Previously a new thread + SQL query was started on EVERY call (UI polls ~2x/s,
        # one key per day) -> thread/connection storm. Now refresh only when missing or stale.
        if cached is None or age > ttl:
            self._schedule_finance_agg_refresh(key)
        return cached

    def _schedule_finance_agg_refresh(self, key: tuple) -> None:
        with self._lock:
            if key in self._finance_agg_refreshing:
                return
            self._finance_agg_refreshing.add(key)
        threading.Thread(
            target=self._refresh_finance_agg_worker, args=(key,), daemon=True,
            name="mysql-finance-agg-refresh",
        ).start()

    def _refresh_finance_agg_worker(self, key: tuple) -> None:
        grid_id, start_ymd, end_ymd = key
        log_key = f"finance_agg:{key}"
        try:
            result = self._compute_finance_agg_range(grid_id, start_ymd, end_ymd)
            with self._lock:
                self._finance_agg_cache[key] = result
                self._finance_agg_ts[key] = time.monotonic()
            self._logged_errors.discard(log_key)
        except Exception:
            with self._lock:
                self._finance_agg_ts[key] = time.monotonic()   # back off until TTL expires
            self._log_once(log_key, "MySQL finance_agg_daily refresh failed for grid=%s range=%s..%s", grid_id, start_ymd, end_ymd)
        finally:
            with self._lock:
                self._finance_agg_refreshing.discard(key)

    def _compute_finance_agg_range(self, grid_id: int, start_ymd: str, end_ymd: str) -> dict[str, dict]:
        rows = self._mysql_client.fetch_all(
            "SELECT ymd, load_kwh, grid_in_kwh, grid_out_kwh, pv_in_kwh, "
            "bess_chg_kwh, bess_dis_kwh, net_cost_site, saving_load_only, grid_purchase_cost "
            "FROM finance_agg_daily WHERE grid_uid = %s AND ymd BETWEEN %s AND %s",
            (grid_id, start_ymd, end_ymd),
        )
        result: dict[str, dict] = {}
        for row in rows:
            ymd = row.get("ymd")
            ymd_key = ymd.isoformat() if hasattr(ymd, "isoformat") else str(ymd)
            result[ymd_key] = {
                "load": float(row.get("load_kwh") or 0.0),
                "grid_in": float(row.get("grid_in_kwh") or 0.0),
                "grid_export": float(row.get("grid_out_kwh") or 0.0),
                "pv": float(row.get("pv_in_kwh") or 0.0),
                "bess_charge": float(row.get("bess_chg_kwh") or 0.0),
                "bess_dis": float(row.get("bess_dis_kwh") or 0.0),
                "net_cost_site": float(row.get("net_cost_site") or 0.0),
                "saving_load_only": float(row.get("saving_load_only") or 0.0),
                "grid_purchase_cost": float(row.get("grid_purchase_cost") or 0.0),
            }
        return result

    def _compute_daily_financials(self, grid_id: int) -> DailyFinancials:
        rows = self._mysql_client.fetch_all(
            "SELECT net_cost_site FROM finance_agg_daily WHERE grid_uid = %s AND ymd = CURDATE()",
            (grid_id,),
        )
        if not rows:
            return DailyFinancials()
        return DailyFinancials(net_cost_site=float(rows[0].get("net_cost_site") or 0.0), available=True)

    def _compute_alarm_summary(self, grid_id: int) -> AlarmSummary:
        rows = self._mysql_client.fetch_all(
            "SELECT id, device_uid, alarm_id, level, action, start_time, description, "
            "is_acknowledged "
            "FROM alarms WHERE main_grid_uid = %s AND is_active = 1 "
            "ORDER BY start_time DESC LIMIT %s",
            (grid_id, self._ACTIVE_ALARMS_SAFETY_CAP),
        )
        info_count = warning_count = fault_count = critical_count = 0
        active_alarms: list[dict] = []
        for row in rows:
            bucket = self._classify(row.get("level"))
            if bucket == "critical":
                critical_count += 1
            elif bucket == "fault":
                fault_count += 1
            elif bucket == "warning":
                warning_count += 1
            else:
                info_count += 1
            start_time = str(row.get("start_time") or "")
            active_alarms.append({
                "id": row.get("id"),
                "deviceId": row.get("device_uid"),
                "alarmId": row.get("alarm_id"),
                "level": self._level_label(bucket),
                "action": row.get("action"),
                "startTime": start_time,
                "time": self._short_time(start_time),
                "description": row.get("description") or "",
                "ack": bool(row.get("is_acknowledged")),
            })
        return AlarmSummary(
            active_count=len(active_alarms),
            info_count=info_count,
            warning_count=warning_count,
            fault_count=fault_count,
            critical_count=critical_count,
            active_alarms=active_alarms,
        )

    def _classify(self, level: str | None) -> str:
        value = str(level or "").upper()
        if "TRIP" in value or "CRIT" in value:
            return "critical"
        if "FAULT" in value or "ERROR" in value:
            return "fault"
        if "WARN" in value:
            return "warning"
        if "ALARM" in value:
            return "fault"
        return "info"

    @staticmethod
    def _level_label(bucket: str) -> str:
        return {"critical": "Critical", "fault": "Fault", "warning": "Warning", "info": "Info"}[bucket]

    @staticmethod
    def _short_time(start_time: str) -> str:
        return start_time[-8:] if len(start_time) >= 8 else start_time


    def get_alarms(
        self,
        topology: PmsTopology,
        limit: int = 500,
        start_ms: int | None = None,
        end_ms: int | None = None,
        active_only: bool = False,
        total_budget: bool = False,
        history_only: bool = False,
    ) -> list[dict]:
        key = (start_ms, end_ms, limit, active_only, total_budget, history_only)
        self._schedule_alarms_refresh(topology, limit, start_ms, end_ms, active_only, total_budget, history_only, key)
        with self._lock:
            return list(self._alarms_cache.get(key, []))

    def _schedule_alarms_refresh(
        self,
        topology: PmsTopology,
        limit: int,
        start_ms: int | None,
        end_ms: int | None,
        active_only: bool,
        total_budget: bool,
        history_only: bool,
        key: tuple,
    ) -> None:
        with self._lock:
            if key in self._alarms_refreshing:
                return
            self._alarms_refreshing.add(key)
        threading.Thread(
            target=self._refresh_alarms_worker,
            args=(topology, limit, start_ms, end_ms, active_only, total_budget, history_only, key),
            daemon=True, name="mysql-alarms-refresh",
        ).start()

    def _refresh_alarms_worker(
        self,
        topology: PmsTopology,
        limit: int,
        start_ms: int | None,
        end_ms: int | None,
        active_only: bool,
        total_budget: bool,
        history_only: bool,
        key: tuple,
    ) -> None:
        try:
            alarms = self._compute_alarms(topology, limit, start_ms, end_ms, active_only, total_budget, history_only)
            with self._lock:
                self._alarms_cache[key] = alarms
            self._logged_errors.discard("alarms_list")
        except Exception:
            self._log_once("alarms_list", "MySQL alarms refresh failed")
        finally:
            with self._lock:
                self._alarms_refreshing.discard(key)

    def _compute_alarms(
        self,
        topology: PmsTopology,
        limit: int,
        start_ms: int | None = None,
        end_ms: int | None = None,
        active_only: bool = False,
        total_budget: bool = False,
        history_only: bool = False,
    ) -> list[dict]:
        if active_only:
            rows = self._mysql_client.fetch_all(
                f"SELECT {self._ALARM_COLUMNS}, 'A' AS src_table FROM alarms WHERE is_active = 1 "
                "ORDER BY start_time DESC LIMIT %s",
                (self._ACTIVE_ALARMS_SAFETY_CAP,),
            )
            return [self._map_alarm_row(row, topology) for row in rows]

        range_where = ""
        range_params: list = []
        if start_ms is not None and end_ms is not None:
            range_where = " AND start_time BETWEEN %s AND %s"
            range_params = [self._format_dt(start_ms), self._format_dt(end_ms)]

        if history_only:
            history_rows = self._mysql_client.fetch_all(
                f"SELECT {self._ALARM_COLUMNS}, 'H' AS src_table FROM alarm_history"
                f" WHERE is_active = 0{range_where} ORDER BY start_time DESC LIMIT %s",
                tuple([*range_params, limit]),
            )
            return [self._map_alarm_row(row, topology) for row in history_rows]

        active_rows = self._mysql_client.fetch_all(
            f"SELECT {self._ALARM_COLUMNS}, 'A' AS src_table FROM alarms"
            f" WHERE 1=1{range_where} ORDER BY start_time DESC LIMIT %s",
            tuple([*range_params, self._ACTIVE_ALARMS_SAFETY_CAP]),
        )
        history_limit = max(0, limit - len(active_rows)) if total_budget else limit
        history_rows = self._mysql_client.fetch_all(
            f"SELECT {self._ALARM_COLUMNS}, 'H' AS src_table FROM alarm_history"
            f" WHERE is_active = 0{range_where} ORDER BY start_time DESC LIMIT %s",
            tuple([*range_params, history_limit]),
        )
        rows = sorted(
            [*active_rows, *history_rows],
            key=lambda row: str(row.get("start_time") or ""),
            reverse=True,
        )
        return [self._map_alarm_row(row, topology) for row in rows]

    @staticmethod
    def _format_dt(epoch_ms: int) -> str:
        return datetime.fromtimestamp(epoch_ms / 1000).strftime("%Y-%m-%d %H:%M:%S")

    def _map_alarm_row(self, row: dict, topology: PmsTopology) -> dict:
        source, device_label = self._alarm_source(topology, row.get("device_uid"))
        grid = topology.grid_for_device(row.get("device_uid"))
        is_active = bool(row.get("is_active"))
        is_ack = bool(row.get("is_acknowledged"))
        start_time = str(row.get("start_time") or "")
        src_tag = row.get("src_table") or "A"
        return {
            "id": f"ALM-{src_tag}{row.get('id')}",
            "timestamp": start_time,
            "time": self._short_time(start_time),
            "epochMs": self._parse_epoch_ms(start_time),
            "level": self._level_label(self._classify(row.get("level"))),
            "status": "Active" if is_active else "Cleared",
            "source": source,
            "deviceId": device_label,
            "deviceUid": row.get("device_uid"),
            "grid": grid.name if grid else "",
            "gridId": grid.id if grid else None,
            "code": f"ALM-{row.get('alarm_id')}" if row.get("alarm_id") is not None else "",
            "description": row.get("description") or "",
            "value": "",
            "valueText": "",
            "threshold": "",
            "unit": "",
            "ack": is_ack,
            "ackStatus": "Acknowledged" if is_ack else "Unacknowledged",
            "ackTime": str(row.get("acked_time") or ""),
            "ackUser": "",
            "clearTime": str(row.get("stop_time") or ""),
            "suggestedAction": "",
            "possibleCause": "",
            "relatedEquipment": "",
            "history": [],
        }

    def _alarm_source(self, topology: PmsTopology, device_uid) -> tuple[str, str]:
        device = next((item for item in topology.devices if item.id == device_uid), None)
        if device is None:
            return "EMS", f"DEV-{device_uid}"
        if "TRANSF" in device.type:
            return "Transformer", device.name
        source = next((item for item in topology.power_sources if item.id == device.source_id), None)
        if source is None:
            return "EMS", device.name
        if source.type == "_CFG_PWRSRCTYPE_BESS" and "PCS" in device.type:
            return "PCS", device.name
        return self._SOURCE_TYPE_LABELS.get(source.type, "EMS"), device.name

    @staticmethod
    def _parse_epoch_ms(text: str) -> int:
        if not text:
            return 0
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S.%f"):
            try:
                return int(datetime.strptime(text, fmt).timestamp() * 1000)
            except ValueError:
                continue
        return 0

    def acknowledge_alarms(self, alarm_ids: list[int]) -> None:
        if not alarm_ids:
            return
        placeholders = ",".join(["%s"] * len(alarm_ids))
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            self._mysql_client.execute(
                f"UPDATE alarms SET is_acknowledged = 1, acked_time = %s WHERE id IN ({placeholders})",
                (now, *alarm_ids),
            )
        except ConnectionError:
            logger.exception("MySQL alarm acknowledge failed for ids=%s", alarm_ids)
            return
        logger.info("Alarm acknowledged ids=%s", alarm_ids)

    def clear_alarm(self, alarm_id: int) -> None:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            self._mysql_client.execute(
                "UPDATE alarms SET is_active = 0, stop_time = %s WHERE id = %s",
                (now, alarm_id),
            )
        except ConnectionError:
            logger.exception("MySQL alarm clear failed for id=%s", alarm_id)
            return
        logger.info("Alarm cleared id=%s", alarm_id)
