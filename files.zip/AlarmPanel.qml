pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Controls
import QtQuick.Controls.Basic as Basic
import "components"

Rectangle {
    id: root
    color: "#020b14"
    radius: 10
    border.color: "#123d5b"
    border.width: 1
    clip: true

    property var dataSource: null
    property var liveSource: null

    // false: disables all write actions (acknowledge, clear) and hides the "Ack Selected" and "Ack Visible" buttons. 
    // This is useful for read-only dashboards where you don't want users to be able to modify the alarm state.
    readonly property bool writeActionsEnabled: false

    readonly property bool useLive: !!(liveSource && liveSource.live)
    readonly property var activeSource: useLive ? liveSource : dataSource

    property int dataTick: 0
    property var alarmRows: activeSource && activeSource.alarms ? activeSource.alarms : []
    readonly property var summaryData: computeSummary(root.filteredAlarms)
    property int pageSize: 15
    property int currentPage: 0
    property var filteredAlarms: []
    property var visibleAlarms: []
    property var selectedAlarm: ({})
    property bool detailOpen: false
    property var selectedIds: []
    property string tableView: "active"
    property var selectedLevels: []
    property var selectedSources: []
    property var selectedStatuses: []

    property string selectedTimeRangeActive: "All"
    property string selectedTimeRangeHistory: "Last 7 days"
    readonly property string selectedTimeRange: root.tableView === "active" ? root.selectedTimeRangeActive : root.selectedTimeRangeHistory

    property string customFromDate: Qt.formatDate(new Date(), "dd/MM/yyyy")
    property string customToDate: Qt.formatDate(new Date(), "dd/MM/yyyy")
    property string customStartTime: "00:00"
    property string customEndTime: "23:59"
    property string searchText: ""
    property string sortKey: "Time"
    property bool sortDescending: true
    property string exportMessage: ""
    property string confirmMessage: ""

    onDataSourceChanged: {
        dataTick += 1;
        Qt.callLater(root.syncRangeAndRefresh);
    }
    onLiveSourceChanged: {
        dataTick += 1;
        Qt.callLater(root.syncRangeAndRefresh);
    }

    readonly property color bg: "#020b14"
    readonly property color panel: "#071827"
    readonly property color panel2: "#0b2237"
    readonly property color line: "#16415f"
    readonly property color textMain: "#e5f2ff"
    readonly property color textMuted: "#8aa4bf"
    readonly property color criticalColor: "#dc2626"
    readonly property color faultColor: "#ef4444"
    readonly property color warningColor: "#f59e0b"
    readonly property color primaryWarningColor: "#d97706"
    readonly property color infoColor: "#38bdf8"
    readonly property color normalColor: "#22c55e"
    readonly property color unknownColor: "#64748b"

    readonly property var levelOptions: ["Critical", "Fault", "Warning", "Info"]
    readonly property var sourceOptions: ["Grid", "PV", "BESS", "PCS", "Transformer", "Load", "HVAC", "FSS", "EMS"]
    readonly property var statusOptions: ["Acknowledged", "Unacknowledged"]
    readonly property var timeOptions: ["All", "Last 1 hour", "Today", "Yesterday", "Last 7 days", "Custom range"]

    readonly property bool showDetailPanel: false
    readonly property real sideWidth: showDetailPanel ? Math.min(392, Math.max(320, width * 0.31)) : 0
    readonly property real gap: 12
    readonly property real leftWidth: showDetailPanel ? Math.max(1, width - sideWidth - gap * 3) : Math.max(1, width - gap * 2)

    readonly property int colSelect: 34
    readonly property int colTime: 168
    readonly property int colLevel: 96
    readonly property int colStatus: 88
    readonly property int colSource: 104
    readonly property int colGrid: 100
    readonly property int colDevice: 132
    readonly property int colCode: 184
    readonly property int colDesc: 292
    readonly property int colValue: 104
    readonly property int colThreshold: 126
    readonly property int colAck: 92
    readonly property int colAction: 130
    readonly property int tableContentWidth: colSelect + colTime + colLevel + colStatus + colSource + colGrid + colDevice + colCode + colDesc + colValue + colThreshold + colAck + colAction

    function emptySummary() {
        return {
            "totalActive": 0,
            "critical": 0,
            "fault": 0,
            "warning": 0,
            "info": 0,
            "unacknowledged": 0,
            "acknowledged": 0,
            "latestAlarmTime": "--"
        };
    }

    function computeSummary(rows) {
        var summary = emptySummary();
        var latestMs = -1;
        for (var i = 0; i < rows.length; i++) {
            var item = rows[i];
            summary.totalActive += 1;
            if (item.level === "Critical")
                summary.critical += 1;
            else if (item.level === "Fault")
                summary.fault += 1;
            else if (item.level === "Warning")
                summary.warning += 1;
            else if (item.level === "Info")
                summary.info += 1;
            if (item.ack)
                summary.acknowledged += 1;
            else
                summary.unacknowledged += 1;
            var ms = Number(item.epochMs || 0);
            if (ms > latestMs) {
                latestMs = ms;
                summary.latestAlarmTime = item.time || item.timestamp || "--";
            }
        }
        return summary;
    }

    function colorForLevel(level) {
        if (level === "Critical")
            return criticalColor;
        if (level === "Fault")
            return faultColor;
        if (level === "Warning")
            return warningColor;
        if (level === "Info")
            return infoColor;
        return unknownColor;
    }

    function levelIcon(level) {
        if (level === "Critical")
            return "CR";
        if (level === "Fault")
            return "FT";
        if (level === "Warning")
            return "WR";
        if (level === "Info")
            return "IN";
        return "--";
    }

    function levelRank(level) {
        if (level === "Critical")
            return 4;
        if (level === "Fault")
            return 3;
        if (level === "Warning")
            return 2;
        if (level === "Info")
            return 1;
        return 0;
    }

    function rowBg(alarm) {
        if (!alarm || alarm.status === "Cleared")
            return "#071827";
        if (alarm.level === "Critical")
            return "#2a0b12";
        if (alarm.level === "Fault")
            return "#241018";
        if (alarm.level === "Warning")
            return "#241b0a";
        if (alarm.level === "Info")
            return "#082033";
        return "#071827";
    }

    function hasUnackedFault() {
        for (var i = 0; i < root.filteredAlarms.length; i++) {
            var item = root.filteredAlarms[i];
            if (item.level === "Fault" && item.status === "Active" && !item.ack)
                return true;
        }
        return false;
    }

    function containsValue(list, value) {
        return list.indexOf(value) >= 0;
    }

    function toggleArrayValue(list, value) {
        var next = list.slice();
        var index = next.indexOf(value);
        if (index >= 0)
            next.splice(index, 1);
        else
            next.push(value);
        return next;
    }

    function toggleLevel(value) {
        selectedLevels = toggleArrayValue(selectedLevels, value);
        currentPage = 0;
        refreshVisible();
    }

    function toggleSource(value) {
        selectedSources = toggleArrayValue(selectedSources, value);
        currentPage = 0;
        refreshVisible();
    }

    function toggleStatus(value) {
        selectedStatuses = toggleArrayValue(selectedStatuses, value);
        currentPage = 0;
        refreshVisible();
    }

    function setTableView(view) {
        if (tableView === view)
            return;
        tableView = view;
        currentPage = 0;
        refreshVisible();
    }

    function setTimeRange(value) {
        if (root.tableView === "active")
            selectedTimeRangeActive = value;
        else
            selectedTimeRangeHistory = value;
        currentPage = 0;
        syncRangeAndRefresh();
    }

    function setCustomTimeRange(fromDateValue, toDateValue, startValue, endValue) {
        customFromDate = fromDateValue;
        customToDate = toDateValue;
        customStartTime = startValue;
        customEndTime = endValue;
        if (root.tableView === "active")
            selectedTimeRangeActive = "Custom range";
        else
            selectedTimeRangeHistory = "Custom range";
        currentPage = 0;
        syncRangeAndRefresh();
    }

    function resetFilters() {
        selectedLevels = [];
        selectedSources = [];
        selectedStatuses = [];
        selectedTimeRangeActive = "All";
        selectedTimeRangeHistory = "Last 7 days";
        customFromDate = Qt.formatDate(new Date(), "dd/MM/yyyy");
        customToDate = customFromDate;
        customStartTime = "00:00";
        customEndTime = "23:59";
        searchText = "";
        searchInput.text = "";
        currentPage = 0;
        syncRangeAndRefresh();
    }

    function rangeBoundsFor(rangeValue) {
        var nowMs = activeSource && activeSource.nowMs ? Number(activeSource.nowMs) : Date.now();
        nowMs = Math.floor(nowMs / 30000) * 30000;
        if (rangeValue === "All")
            return [null, null];
        if (rangeValue === "Custom range") {
            var fromMs = customDateTimeMs(customFromDate, customStartTime);
            var toMs = customDateTimeMs(customToDate, customEndTime);
            return [Math.min(fromMs, toMs), Math.max(fromMs, toMs)];
        }
        if (rangeValue === "Last 1 hour")
            return [nowMs - 3600000, nowMs];
        var nowDate = new Date(nowMs);
        var todayStart = new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate()).getTime();
        if (rangeValue === "Today")
            return [todayStart, todayStart + 86400000];
        if (rangeValue === "Yesterday")
            return [todayStart - 86400000, todayStart];
        if (rangeValue === "Last 7 days")
            return [nowMs - 7 * 86400000, nowMs];
        return [null, null];
    }

    function backendRangeBounds() {
        return rangeBoundsFor(root.selectedTimeRangeHistory);
    }

    function syncRangeAndRefresh() {
        if (root.useLive && root.activeSource) {
            var bounds = root.backendRangeBounds();
            if (bounds[0] === null || bounds[1] === null) {
                if (root.activeSource.clearTimeRange)
                    root.activeSource.clearTimeRange();
            } else if (root.activeSource.setTimeRange) {
                root.activeSource.setTimeRange(bounds[0], bounds[1]);
            }
        }
        currentPage = 0;
        root.refreshVisible();
    }

    function setSort(key) {
        if (sortKey === key)
            sortDescending = !sortDescending;
        else {
            sortKey = key;
            sortDescending = key === "Time";
        }
        currentPage = 0;
        refreshVisible();
    }

    function sortGlyph(key) {
        if (sortKey !== key)
            return "";
        return sortDescending ? " v" : " ^";
    }

    function parseDateText(value) {
        var parts = String(value || "").split("/");
        if (parts.length === 3) {
            var day = Number(parts[0]);
            var month = Number(parts[1]);
            var year = Number(parts[2]);
            var parsed = new Date(year, month - 1, day);
            if (!isNaN(parsed.getTime()) && parsed.getDate() === day && parsed.getMonth() === month - 1 && parsed.getFullYear() === year)
                return parsed;
        }
        return new Date();
    }

    function minutesOf(value) {
        var parts = String(value || "00:00").split(":");
        return Number(parts[0]) * 60 + Number(parts[1]);
    }

    function customDateTimeMs(dateText, timeText) {
        var dateValue = parseDateText(dateText);
        var minutes = minutesOf(timeText);
        dateValue.setHours(Math.floor(minutes / 60), minutes % 60, 0, 0);
        return dateValue.getTime();
    }

    function timeMatches(alarm) {
        var now = activeSource && activeSource.nowMs ? Number(activeSource.nowMs) : 0;
        var alarmMs = Number(alarm.epochMs || 0);
        if (selectedTimeRange === "Custom range") {
            var fromMs = customDateTimeMs(customFromDate, customStartTime);
            var toMs = customDateTimeMs(customToDate, customEndTime);
            return alarmMs >= Math.min(fromMs, toMs) && alarmMs <= Math.max(fromMs, toMs);
        }
        if (selectedTimeRange === "Last 1 hour")
            return now - alarmMs <= 3600000;
        var alarmDate = new Date(alarmMs);
        var nowDate = new Date(now);
        var todayStart = new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate()).getTime();
        var tomorrowStart = todayStart + 86400000;
        var yesterdayStart = todayStart - 86400000;
        if (selectedTimeRange === "Today")
            return alarmMs >= todayStart && alarmMs < tomorrowStart;
        if (selectedTimeRange === "Yesterday")
            return alarmMs >= yesterdayStart && alarmMs < todayStart;
        if (selectedTimeRange === "Last 7 days")
            return now - alarmMs <= 7 * 86400000;
        return true;
    }

    function searchMatches(alarm) {
        var term = searchText.trim().toLowerCase();
        if (term.length === 0)
            return true;
        var text = ((alarm.deviceId || "") + " " + (alarm.code || "") + " " + (alarm.description || "") + " " + (alarm.source || "") + " " + (alarm.grid || "")).toLowerCase();
        return text.indexOf(term) >= 0;
    }

    function alarmMatches(alarm) {
        var wantStatus = root.tableView === "active" ? "Active" : "Cleared";
        if (alarm.status !== wantStatus)
            return false;
        if (selectedLevels.length > 0 && !containsValue(selectedLevels, alarm.level))
            return false;
        if (selectedSources.length > 0 && !containsValue(selectedSources, alarm.source))
            return false;
        if (selectedStatuses.length > 0) {
            var statusMatch = (containsValue(selectedStatuses, "Acknowledged") && alarm.ack)
                    || (containsValue(selectedStatuses, "Unacknowledged") && !alarm.ack);
            if (!statusMatch)
                return false;
        }
        if (!timeMatches(alarm))
            return false;
        return searchMatches(alarm);
    }

    function sortValue(alarm, key) {
        if (key === "Time")
            return Number(alarm.epochMs || 0);
        if (key === "Level")
            return levelRank(alarm.level);
        if (key === "Source")
            return alarm.source || "";
        if (key === "Status")
            return alarm.status || "";
        return alarm.time || "";
    }

    function refreshVisible() {
        dataTick;
        var rows = [];
        var raw = alarmRows || [];
        for (var i = 0; i < raw.length; i++) {
            if (alarmMatches(raw[i]))
                rows.push(raw[i]);
        }
        rows.sort(function (a, b) {
            var av = sortValue(a, sortKey);
            var bv = sortValue(b, sortKey);
            var result = 0;
            if (typeof av === "number" && typeof bv === "number")
                result = av - bv;
            else
                result = String(av).localeCompare(String(bv));
            return sortDescending ? -result : result;
        });
        filteredAlarms = rows;
        var maxPage = Math.max(0, Math.ceil(rows.length / pageSize) - 1);
        if (currentPage > maxPage) {
            currentPage = 0;
        }
        visibleAlarms = rows.slice(currentPage * pageSize, currentPage * pageSize + pageSize);
        refreshSelectedAlarm();
    }

    function setPage(page) {
        var maxPage = Math.max(0, Math.ceil(filteredAlarms.length / pageSize) - 1);
        currentPage = Math.min(Math.max(0, page), maxPage);
        visibleAlarms = filteredAlarms.slice(currentPage * pageSize, currentPage * pageSize + pageSize);
    }

    function refreshSelectedAlarm() {
        if (!selectedAlarm || !selectedAlarm.id) {
            selectedAlarm = visibleAlarms.length > 0 ? visibleAlarms[0] : {};
            return;
        }
        for (var i = 0; i < alarmRows.length; i++) {
            if (alarmRows[i].id === selectedAlarm.id) {
                selectedAlarm = alarmRows[i];
                return;
            }
        }
        selectedAlarm = visibleAlarms.length > 0 ? visibleAlarms[0] : {};
    }

    function selectAlarm(alarm) {
        selectedAlarm = alarm;
        detailOpen = true;
    }

    function isSelected(id) {
        return selectedIds.indexOf(id) >= 0;
    }

    function toggleSelected(id) {
        selectedIds = toggleArrayValue(selectedIds, id);
    }

    function allVisibleSelected() {
        if (!visibleAlarms || visibleAlarms.length === 0)
            return false;
        for (var i = 0; i < visibleAlarms.length; i++) {
            if (!isSelected(visibleAlarms[i].id))
                return false;
        }
        return true;
    }

    function toggleSelectAllVisible() {
        if (allVisibleSelected()) {
            var visibleIds = visibleAlarms.map(function(item) { return item.id; });
            selectedIds = selectedIds.filter(function(id) { return visibleIds.indexOf(id) < 0; });
        } else {
            var next = selectedIds.slice();
            for (var i = 0; i < visibleAlarms.length; i++) {
                if (next.indexOf(visibleAlarms[i].id) < 0)
                    next.push(visibleAlarms[i].id);
            }
            selectedIds = next;
        }
    }

    function visibleUnackIds() {
        var ids = [];
        for (var i = 0; i < visibleAlarms.length; i++) {
            if (!visibleAlarms[i].ack && visibleAlarms[i].status === "Active")
                ids.push(visibleAlarms[i].id);
        }
        return ids;
    }

    function acknowledgeOne(id) {
        if (!root.writeActionsEnabled)
            return;
        if (activeSource && activeSource.acknowledgeAlarm)
            activeSource.acknowledgeAlarm(id);
    }

    function acknowledgeSelected() {
        if (!root.writeActionsEnabled)
            return;
        if (selectedIds.length > 0 && activeSource && activeSource.acknowledgeAlarms)
            activeSource.acknowledgeAlarms(selectedIds);
        selectedIds = [];
    }

    function requestAckAllVisible() {
        if (!root.writeActionsEnabled)
            return;
        var count = visibleUnackIds().length;
        confirmMessage = "Acknowledge " + count + " visible unacknowledged alarm(s)?";
        confirmOverlay.visible = count > 0;
    }

    function confirmAckAllVisible() {
        if (root.writeActionsEnabled && activeSource && activeSource.acknowledgeVisibleAlarms)
            activeSource.acknowledgeVisibleAlarms(visibleUnackIds());
        confirmOverlay.visible = false;
    }

    function clearOne(id) {
        if (!root.writeActionsEnabled)
            return;
        if (activeSource && activeSource.clearAlarm)
            activeSource.clearAlarm(id);
    }

    function exportVisible() {
        if (activeSource && activeSource.exportCsv) {
            exportMessage = "Exported: " + activeSource.exportCsv(visibleAlarms);
            exportMessageTimer.restart();
        }
    }

    function detail(name, fallback) {
        if (!selectedAlarm || !selectedAlarm.id)
            return fallback || "--";
        var value = selectedAlarm[name];
        return value === undefined || value === null || value === "" ? (fallback || "--") : value;
    }

    Connections {
        target: root.activeSource
        function onDataChanged() {
            root.dataTick += 1;
            root.refreshVisible();
        }
        function onExportCompleted(path) {
            root.exportMessage = "Exported: " + path;
            exportMessageTimer.restart();
        }
    }

    Component.onCompleted: syncRangeAndRefresh()

    Timer {
        id: exportMessageTimer
        interval: 5000
        onTriggered: root.exportMessage = ""
    }

    Rectangle {
        id: header
        x: 12
        y: 12
        width: root.leftWidth
        height: 58
        radius: 8
        color: "#071827"
        border.color: "#16415f"
        border.width: 1

        Text {
            x: 18
            y: 10
            text: "CẢNH BÁO HỆ THỐNG"
            color: root.textMain
            font.pixelSize: 24
            font.bold: true
        }

        Text {
            x: 20
            y: 38
            text: "Realtime Alarm Monitoring | Microgrid / BESS / PCS / PV / Grid" 
            color: root.textMuted
            font.pixelSize: 12
        }

        Text {
            x: parent.width - width - 18
            y: 22
            width: 260
            text: root.exportMessage
            color: root.normalColor
            font.pixelSize: 12
            horizontalAlignment: Text.AlignRight
            elide: Text.ElideMiddle
            visible: root.exportMessage.length > 0
        }
    }

    Row {
        x: 12
        y: 82
        spacing: 8

        SummaryCard {
            cardWidth: (root.leftWidth - 7 * 8) / 8
            title: root.tableView === "active" ? "Total active" : "Total alarm"
            value: root.summaryData.totalActive || 0
            accent: root.tableView === "active" ? (root.summaryData.totalActive > 0 ? root.faultColor : root.normalColor) : root.infoColor
            note: root.tableView === "active" ? "Active alarms" : "History alarms"
        }
        SummaryCard { cardWidth: (root.leftWidth - 7 * 8) / 8; title: "Critical"; value: root.summaryData.critical || 0; accent: root.criticalColor; note: "Highest severity" }
        SummaryCard { cardWidth: (root.leftWidth - 7 * 8) / 8; title: "Fault"; value: root.summaryData.fault || 0; accent: root.faultColor; note: "Fault alarms"; blink: root.hasUnackedFault() }
        SummaryCard { cardWidth: (root.leftWidth - 7 * 8) / 8; title: "Warning"; value: root.summaryData.warning || 0; accent: root.warningColor; note: "Warning alarms" }
        SummaryCard { cardWidth: (root.leftWidth - 7 * 8) / 8; title: "Info"; value: root.summaryData.info || 0; accent: root.infoColor; note: "Information" }
        SummaryCard { cardWidth: (root.leftWidth - 7 * 8) / 8; title: "Unack"; value: root.summaryData.unacknowledged || 0; accent: root.warningColor; note: "Need action" }
        SummaryCard { cardWidth: (root.leftWidth - 7 * 8) / 8; title: "Acked"; value: root.summaryData.acknowledged || 0; accent: root.normalColor; note: "Acknowledged" }
        SummaryCard { cardWidth: (root.leftWidth - 7 * 8) / 8; title: "Latest"; value: root.summaryData.latestAlarmTime || "--"; accent: root.infoColor; note: "Alarm time"; compact: true }
    }

    Rectangle {
        id: filterPanel
        x: 12
        y: 176
        width: root.leftWidth
        height: filterRow.y * 2 + filterRow.height + (customTimePicker.visible ? customTimePicker.height + 12 : 0)
        radius: 8
        color: "#071827"
        border.color: "#16415f"
        border.width: 1

        property real pad: 10
        property real rowSpacing: 8
        property real boxWidth: 128
        property real buttonWidth: 104
        property real buttonBlockWidth: buttonWidth * 2 + rowSpacing
        property real filterLabelWidth: 52
        property real fixedRowWidth: filterLabelWidth + boxWidth * 4 + buttonBlockWidth + rowSpacing * 6
        property real searchWidth: Math.max(160, width - pad * 2 - fixedRowWidth)
        property real customPickerWidth: Math.min(608, Math.max(224, width - pad * 2))

        Row {
            id: filterRow
            x: filterPanel.pad
            y: filterPanel.pad
            height: 52
            spacing: filterPanel.rowSpacing

            Text {
                anchors.verticalCenter: parent.verticalCenter
                width: filterPanel.filterLabelWidth
                text: "FILTER"
                color: root.textMain
                font.pixelSize: 13
                font.bold: true
            }

            MultiFilterBox {
                anchors.verticalCenter: parent.verticalCenter
                width: filterPanel.boxWidth
                label: "Level"
                options: root.levelOptions
                selectedValues: root.selectedLevels
                onToggleOption: function(value) { root.toggleLevel(value) }
            }
            MultiFilterBox {
                anchors.verticalCenter: parent.verticalCenter
                width: filterPanel.boxWidth
                label: "Source"
                options: root.sourceOptions
                selectedValues: root.selectedSources
                onToggleOption: function(value) { root.toggleSource(value) }
            }
            MultiFilterBox {
                anchors.verticalCenter: parent.verticalCenter
                width: filterPanel.boxWidth
                label: "Status"
                options: root.statusOptions
                selectedValues: root.selectedStatuses
                onToggleOption: function(value) { root.toggleStatus(value) }
            }

            SingleFilterBox {
                anchors.verticalCenter: parent.verticalCenter
                width: filterPanel.boxWidth
                label: "Time"
                options: root.timeOptions
                value: root.selectedTimeRange
                onSelectOption: function(value) { root.setTimeRange(value) }
            }

            Rectangle {
                anchors.verticalCenter: parent.verticalCenter
                width: filterPanel.searchWidth
                height: 52
                radius: 8
                color: "#061421"
                border.color: searchInput.activeFocus ? root.infoColor : root.line
                border.width: 1

                Text {
                    x: 12
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Search Device ID, Code, Description"
                    color: "#64748b"
                    font.pixelSize: 11
                    visible: searchInput.text.length === 0 && !searchInput.activeFocus
                }

                TextInput {
                    id: searchInput
                    anchors.fill: parent
                    anchors.leftMargin: 12
                    anchors.rightMargin: 12
                    color: root.textMain
                    selectionColor: root.infoColor
                    selectedTextColor: "#04111f"
                    selectByMouse: true
                    font.pixelSize: 12
                    verticalAlignment: TextInput.AlignVCenter
                    clip: true
                    onTextChanged: {
                        root.searchText = text;
                        currentPage = 0;
                        root.refreshVisible();
                    }
                }
            }

            Column {
                anchors.verticalCenter: parent.verticalCenter
                spacing: 4

                Row {
                    spacing: filterPanel.rowSpacing
                    ToolbarButton { width: filterPanel.buttonWidth; height: 24; label: "Clear Filter"; accent: root.unknownColor; onClicked: root.resetFilters() }
                    ToolbarButton { width: filterPanel.buttonWidth; height: 24; label: "Export CSV"; accent: root.infoColor; enabled: root.visibleAlarms.length > 0; onClicked: root.exportVisible() }
                }
                Row {
                    spacing: filterPanel.rowSpacing
                    ToolbarButton { width: filterPanel.buttonWidth; height: 24; label: "Ack Selected"; accent: root.primaryWarningColor; enabled: root.writeActionsEnabled && root.selectedIds.length > 0; onClicked: root.acknowledgeSelected() }
                    ToolbarButton { width: filterPanel.buttonWidth; height: 24; label: "Ack Visible"; accent: root.warningColor; enabled: root.writeActionsEnabled && root.visibleUnackIds().length > 0; onClicked: root.requestAckAllVisible() }
                }
            }
        }

        DateTimeRangePicker {
            id: customTimePicker
            x: filterPanel.pad
            y: filterRow.y + filterRow.height + 10
            width: filterPanel.customPickerWidth
            visible: root.selectedTimeRange === "Custom range"
            compact: width < 560
            fromDate: root.customFromDate
            toDate: root.customToDate
            startTime: root.customStartTime
            endTime: root.customEndTime
            textColor: root.textMain
            mutedTextColor: root.textMuted
            accentColor: root.infoColor
            fieldColor: "#061421"
            hoverColor: "#0b2237"
            borderColor: root.line
            onRangeEdited: function(fromDateValue, toDateValue, startValue, endValue) {
                root.setCustomTimeRange(fromDateValue, toDateValue, startValue, endValue);
            }
        }
    }

    Rectangle {
        id: tablePanel
        x: 12
        y: filterPanel.y + filterPanel.height + 12
        width: root.leftWidth
        height: root.height - y - 12
        radius: 8
        color: "#04111f"
        border.color: "#16415f"
        border.width: 1

        Item {
            id: tableTabs
            x: 8
            y: 8
            width: parent.width - 16
            height: 32

            Row {
                anchors.left: parent.left
                anchors.verticalCenter: parent.verticalCenter
                spacing: 6

                Rectangle {
                    width: 150
                    height: tableTabs.height
                    radius: 6
                    color: root.tableView === "active" ? root.infoColor : "#061421"
                    border.color: root.infoColor
                    border.width: 1
                    Text {
                        anchors.centerIn: parent
                        text: "Active"
                        color: root.tableView === "active" ? "#04111f" : root.textMain
                        font.pixelSize: 12
                        font.bold: true
                    }
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.setTableView("active")
                    }
                }

                Rectangle {
                    width: 150
                    height: tableTabs.height
                    radius: 6
                    color: root.tableView === "history" ? root.infoColor : "#061421"
                    border.color: root.infoColor
                    border.width: 1
                    Text {
                        anchors.centerIn: parent
                        text: "History"
                        color: root.tableView === "history" ? "#04111f" : root.textMain
                        font.pixelSize: 12
                        font.bold: true
                    }
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.setTableView("history")
                    }
                }
            }

            Text {
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                text: root.selectedIds.length + " selected"
                color: root.textMuted
                font.pixelSize: 11
            }
        }

        Item {
            id: pager
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.bottom: parent.bottom
            anchors.leftMargin: 8
            anchors.rightMargin: 8
            anchors.bottomMargin: 8
            height: 28

            Row {
                anchors.left: parent.left
                anchors.verticalCenter: parent.verticalCenter
                spacing: 8

                Rectangle {
                    width: 88
                    height: pager.height
                    radius: 6
                    color: root.currentPage > 0 ? "#1e293b" : "#0f172a"
                    border.color: "#334155"
                    Text { anchors.centerIn: parent; text: "PREV"; color: "#f8fafc"; font.pixelSize: 10; font.bold: true }

                    MouseArea {
                        anchors.fill: parent
                        enabled: root.currentPage > 0
                        cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                        onClicked: root.setPage(root.currentPage - 1)
                    }
                }

                Rectangle {
                    width: 88
                    height: pager.height
                    radius: 6
                    color: (root.currentPage + 1) * root.pageSize < root.filteredAlarms.length ? "#1e293b" : "#0f172a"
                    border.color: "#334155"
                    Text { anchors.centerIn: parent; text: "NEXT"; color: "#f8fafc"; font.pixelSize: 10; font.bold: true }

                    MouseArea {
                        anchors.fill: parent
                        enabled: (root.currentPage + 1) * root.pageSize < root.filteredAlarms.length
                        cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                        onClicked: root.setPage(root.currentPage + 1)
                    }
                }
            }

            Text {
                id: visibleCountText
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                property int totalPages: Math.max(1, Math.ceil(root.filteredAlarms.length / root.pageSize))
                property int startIndex: root.filteredAlarms.length > 0 ? root.currentPage * root.pageSize + 1 : 0
                property int endIndex: Math.min((root.currentPage + 1) * root.pageSize, root.filteredAlarms.length)
                text: "Showing " + startIndex + " - " + endIndex + " of " + root.filteredAlarms.length + " | Page " + (root.currentPage + 1) + " / " + totalPages
                color: root.textMuted
                font.pixelSize: 11
            }
        }

        Flickable {
            id: tableFlick
            anchors.top: tableTabs.bottom
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.bottom: pager.top
            anchors.topMargin: 8
            anchors.leftMargin: 8
            anchors.rightMargin: 8
            anchors.bottomMargin: 4
            clip: true
            contentWidth: Math.max(width, root.tableContentWidth)
            contentHeight: height
            flickableDirection: Flickable.HorizontalFlick
            ScrollBar.horizontal: ScrollBar { policy: ScrollBar.AsNeeded }

            Row {
                id: tableHeader
                width: tableFlick.contentWidth
                height: 34
                HeaderCell {
                    width: root.colSelect
                    label: ""
                    SelectBox {
                        anchors.centerIn: parent
                        selected: root.allVisibleSelected()
                        onClicked: root.toggleSelectAllVisible()
                    }
                }
                HeaderCell { width: root.colTime; label: "Time" + root.sortGlyph("Time"); sortable: true; onClicked: root.setSort("Time") }
                HeaderCell { width: root.colLevel; label: "Level" + root.sortGlyph("Level"); textAlignment: Text.AlignHCenter; sortable: true; onClicked: root.setSort("Level") }
                HeaderCell { width: root.colStatus; label: "Status" + root.sortGlyph("Status"); sortable: true; onClicked: root.setSort("Status") }
                HeaderCell { width: root.colSource; label: "Source" + root.sortGlyph("Source"); sortable: true; onClicked: root.setSort("Source") }
                HeaderCell { width: root.colGrid; label: "Grid" }
                HeaderCell { width: root.colDevice; label: "Device ID" }
                HeaderCell { width: root.colCode; label: "Alarm Code" }
                HeaderCell { width: root.colDesc; label: "Description" }
                HeaderCell { width: root.colValue; label: "Value" }
                HeaderCell { width: root.colThreshold; label: "Threshold" }
                HeaderCell { width: root.colAck; label: "Ack"; textAlignment: Text.AlignHCenter }
                HeaderCell { width: root.colAction; label: "Action"; textAlignment: Text.AlignHCenter }
            }

            ListView {
                id: alarmList
                x: 0
                y: tableHeader.height + 4
                width: tableFlick.contentWidth
                height: Math.max(1, tableFlick.height - y)
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                cacheBuffer: Math.max(0, height * 2)
                reuseItems: true
                spacing: 4
                model: root.visibleAlarms
                ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded }

                delegate: AlarmTableRow {
                    required property var modelData
                    width: alarmList.width
                    alarm: modelData
                }
            }
        }
    }

    Rectangle {
        id: detailBackdrop
        anchors.fill: parent
        visible: root.detailOpen
        color: "#000000aa"
        z: 900
        MouseArea {
            anchors.fill: parent
            onClicked: root.detailOpen = false
        }
    }

    Rectangle {
        id: detailPanel
        visible: root.detailOpen
        z: 901
        anchors.centerIn: parent
        width: Math.min(620, root.width - root.gap * 4)
        height: Math.min(760, root.height - root.gap * 4)
        radius: 10
        color: "#071827"
        border.color: root.selectedAlarm && root.selectedAlarm.level ? root.colorForLevel(root.selectedAlarm.level) : root.line
        border.width: 1
        clip: true

        MouseArea {
            anchors.fill: parent
        }

        Rectangle {
            id: detailCloseButton
            z: 10
            width: 30
            height: 30
            radius: 15
            x: parent.width - width - 22
            y: 22
            color: closeMouse.containsMouse ? "#1e293b" : "#0b2237"
            border.color: root.textMuted
            border.width: 1
            Text { anchors.centerIn: parent; text: "✕"; color: root.textMain; font.pixelSize: 14; font.bold: true }
            MouseArea {
                id: closeMouse
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: root.detailOpen = false
            }
        }

        Rectangle {
            x: 14
            y: 14
            width: parent.width - 28
            height: 104
            radius: 8
            color: "#0b2237"
            border.color: root.selectedAlarm && root.selectedAlarm.level ? root.colorForLevel(root.selectedAlarm.level) : root.line
            border.width: 1

            Text {
                x: 14
                y: 12
                width: parent.width - 28
                text: root.detail("code", "Select an alarm")
                color: root.textMain
                font.pixelSize: 18
                font.bold: true
                elide: Text.ElideRight
            }
            Text {
                x: 14
                y: 40
                width: parent.width - 28
                text: root.detail("description", "Click an alarm row to view detail")
                color: root.textMuted
                font.pixelSize: 12
                elide: Text.ElideRight
            }
            StatusPill {
                x: 14
                y: 66
                label: root.detail("level", "--")
                accent: root.colorForLevel(label)
            }
            StatusPill {
                x: parent.width - width - 14
                y: 66
                label: root.detail("status", "--")
                accent: label === "Cleared" ? root.normalColor : root.colorForLevel(root.detail("level", "--"))
            }
        }

        Flickable {
            id: detailFlick
            x: 14
            y: 132
            width: parent.width - 28
            height: parent.height - 146
            clip: true
            contentWidth: width
            contentHeight: detailColumn.height
            boundsBehavior: Flickable.StopAtBounds
            ScrollBar.vertical: ScrollBar {
                policy: ScrollBar.AsNeeded
            }

            Column {
                id: detailColumn
                width: detailFlick.width
                spacing: 8

                DetailRow { label: "Alarm ID"; value: root.detail("id") }
                DetailRow { label: "Timestamp"; value: root.detail("timestamp") }
                DetailRow { label: "Level"; value: root.detail("level") }
                DetailRow { label: "Source"; value: root.detail("source") }
                DetailRow { label: "Grid"; value: root.detail("grid") }
                DetailRow { label: "Device ID"; value: root.detail("deviceId") }
                DetailRow { label: "Alarm Code"; value: root.detail("code") }
                DetailRow { label: "Description"; value: root.detail("description") }
                DetailRow { label: "Current Value"; value: root.detail("valueText") }
                DetailRow { label: "Threshold"; value: root.detail("threshold") }
                DetailRow { label: "Unit"; value: root.detail("unit") }
                DetailRow { label: "Status"; value: root.detail("status") }
                DetailRow { label: "Ack Status"; value: root.detail("ackStatus") }
                DetailRow { label: "Ack Time"; value: root.detail("ackTime") }
                DetailRow { label: "Ack User"; value: root.detail("ackUser") }
                DetailRow { label: "Suggested Action"; value: root.detail("suggestedAction") }
                DetailRow { label: "Possible Cause"; value: root.detail("possibleCause") }
                DetailRow { label: "Related Equipment"; value: root.detail("relatedEquipment") }

                Text {
                    text: "Event history"
                    color: root.textMain
                    font.pixelSize: 13
                    font.bold: true
                    topPadding: 6
                }

                Repeater {
                    model: root.selectedAlarm && root.selectedAlarm.history ? root.selectedAlarm.history : []
                    delegate: Rectangle {
                        required property string modelData
                        width: detailColumn.width
                        height: Math.max(30, historyText.implicitHeight + 12)
                        radius: 6
                        color: "#061421"
                        border.color: "#123d5b"
                        border.width: 1
                        Text {
                            id: historyText
                            x: 10
                            y: 6
                            width: parent.width - 20
                            text: modelData
                            color: root.textMuted
                            font.pixelSize: 12
                            wrapMode: Text.WordWrap
                        }
                    }
                }
            }
        }
    }

    Rectangle {
        id: confirmOverlay
        anchors.fill: parent
        color: "#000000aa"
        visible: false
        z: 1000

        Rectangle {
            anchors.centerIn: parent
            width: 430
            height: 176
            radius: 10
            color: "#071827"
            border.color: root.warningColor
            border.width: 1

            Text {
                x: 20
                y: 18
                width: parent.width - 40
                text: "CONFIRM ACKNOWLEDGE"
                color: root.textMain
                font.pixelSize: 18
                font.bold: true
            }
            Text {
                x: 20
                y: 58
                width: parent.width - 40
                text: root.confirmMessage
                color: root.textMuted
                font.pixelSize: 13
                wrapMode: Text.WordWrap
            }

            ToolbarButton { x: 204; y: 124; width: 94; label: "Cancel"; accent: root.unknownColor; onClicked: confirmOverlay.visible = false }
            ToolbarButton { x: 312; y: 124; width: 94; label: "Acknowledge"; accent: root.warningColor; onClicked: root.confirmAckAllVisible() }
        }
    }

    MouseArea {
        anchors.fill: parent
        propagateComposedEvents: true
        onPressed: function(mouse) {
            if (searchInput.activeFocus)
                searchInput.focus = false;
            mouse.accepted = false;
        }
    }

    component SummaryCard: Rectangle {
        id: summaryCard
        property real cardWidth: 160
        property string title: ""
        property var value: 0
        property string note: ""
        property color accent: root.infoColor
        property bool blink: false
        property bool compact: false
        property real blinkOpacity: 1.0
        width: cardWidth
        height: 80
        radius: 8
        color: "#071827"
        border.color: accent
        border.width: 1
        opacity: blink ? blinkOpacity : 1.0

        SequentialAnimation on blinkOpacity {
            running: summaryCard.blink
            loops: Animation.Infinite
            NumberAnimation { from: 0.58; to: 1.0; duration: 520 }
            NumberAnimation { from: 1.0; to: 0.58; duration: 520 }
        }

        Rectangle {
            x: 0
            y: 0
            width: 5
            height: parent.height
            radius: 2
            color: summaryCard.accent
        }
        Text {
            x: 14
            y: 10
            width: parent.width - 24
            text: summaryCard.title
            color: root.textMuted
            font.pixelSize: 11
            font.bold: true
            elide: Text.ElideRight
        }
        Text {
            x: 14
            y: 30
            width: parent.width - 24
            text: String(summaryCard.value)
            color: root.textMain
            font.pixelSize: summaryCard.compact ? 18 : 26
            font.bold: true
            elide: Text.ElideRight
        }
        Text {
            x: 14
            y: 60
            width: parent.width - 24
            text: summaryCard.note
            color: summaryCard.accent
            font.pixelSize: 10
            elide: Text.ElideRight
        }
    }

    component MultiFilterBox: Rectangle {
        id: box
        property string label: ""
        property var options: []
        property var selectedValues: []
        signal toggleOption(string value)

        readonly property string displayText: box.selectedValues.length === 0 ? "All" : (box.selectedValues.length + " selected")

        width: 176
        height: 52
        radius: 8
        color: "#061421"
        border.color: popup.visible ? root.infoColor : root.line
        border.width: 1

        Text {
            x: 12
            y: 8
            text: box.label
            color: root.textMuted
            font.pixelSize: 10
            font.bold: true
        }

        Text {
            x: 12
            y: 27
            width: parent.width - 34
            text: box.displayText
            color: root.textMain
            font.pixelSize: 13
            font.bold: true
            elide: Text.ElideRight
        }

        Text {
            x: box.width - 22
            y: 25
            width: 14
            height: 20
            text: "▾"
            color: root.infoColor
            font.pixelSize: 12
            font.bold: true
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
        }

        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            onClicked: popup.visible = !popup.visible
        }

        Popup {
            id: popup
            y: box.height + 4
            width: Math.max(box.width, 200)
            padding: 6
            closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside
            background: Rectangle {
                radius: 8
                color: "#061421"
                border.color: root.infoColor
                border.width: 1
            }
            contentItem: Column {
                spacing: 2
                Repeater {
                    model: box.options
                    delegate: Rectangle {
                        id: optionRow
                        required property string modelData
                        width: popup.width - 12
                        height: 30
                        radius: 5
                        color: optMouse.containsMouse ? "#102a42" : "transparent"

                        Row {
                            x: 8
                            anchors.verticalCenter: parent.verticalCenter
                            spacing: 8
                            SelectBox {
                                anchors.verticalCenter: parent.verticalCenter
                                selected: root.containsValue(box.selectedValues, optionRow.modelData)
                            }
                            Text {
                                anchors.verticalCenter: parent.verticalCenter
                                text: optionRow.modelData
                                color: root.textMain
                                font.pixelSize: 12
                            }
                        }

                        MouseArea {
                            id: optMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: box.toggleOption(optionRow.modelData)
                        }
                    }
                }
            }
        }
    }

    component SingleFilterBox: Rectangle {
        id: box
        property string label: ""
        property var options: []
        property string value: ""
        signal selectOption(string value)

        width: 176
        height: 52
        radius: 8
        color: "#061421"
        border.color: popup.visible ? root.infoColor : root.line
        border.width: 1

        Text {
            x: 12
            y: 8
            text: box.label
            color: root.textMuted
            font.pixelSize: 10
            font.bold: true
        }

        Text {
            x: 12
            y: 27
            width: parent.width - 34
            text: box.value
            color: root.textMain
            font.pixelSize: 13
            font.bold: true
            elide: Text.ElideRight
        }

        Text {
            x: box.width - 22
            y: 25
            width: 14
            height: 20
            text: "▾"
            color: root.infoColor
            font.pixelSize: 12
            font.bold: true
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
        }

        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            onClicked: popup.visible = !popup.visible
        }

        Popup {
            id: popup
            y: box.height + 4
            width: Math.max(box.width, 200)
            padding: 6
            closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside
            background: Rectangle {
                radius: 8
                color: "#061421"
                border.color: root.infoColor
                border.width: 1
            }
            contentItem: Column {
                spacing: 2
                Repeater {
                    model: box.options
                    delegate: Rectangle {
                        id: optionRow
                        required property string modelData
                        width: popup.width - 12
                        height: 30
                        radius: 5
                        color: optMouse.containsMouse ? "#102a42" : (optionRow.modelData === box.value ? "#0b2237" : "transparent")

                        Text {
                            x: 10
                            anchors.verticalCenter: parent.verticalCenter
                            text: optionRow.modelData
                            color: optionRow.modelData === box.value ? root.infoColor : root.textMain
                            font.pixelSize: 12
                            font.bold: optionRow.modelData === box.value
                        }

                        MouseArea {
                            id: optMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: {
                                box.selectOption(optionRow.modelData);
                                popup.close();
                            }
                        }
                    }
                }
            }
        }
    }

    component ToolbarButton: Rectangle {
        id: toolButton
        property string label: ""
        property color accent: root.infoColor
        signal clicked()
        height: 26
        radius: 5
        opacity: enabled ? 1.0 : 0.42
        color: buttonMouse.containsMouse && enabled ? "#102a42" : "#061421"
        border.color: accent
        border.width: 1

        Text {
            anchors.centerIn: parent
            width: parent.width - 10
            text: toolButton.label
            color: root.textMain
            font.pixelSize: 10
            font.bold: true
            horizontalAlignment: Text.AlignHCenter
            elide: Text.ElideRight
        }

        MouseArea {
            id: buttonMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: toolButton.enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
            onClicked: if (toolButton.enabled) toolButton.clicked()
        }
    }

    component HeaderCell: Rectangle {
        id: headerCell
        property string label: ""
        property bool sortable: false
        property int textAlignment: Text.AlignLeft
        signal clicked()
        height: 34
        color: "#0b2237"
        border.color: "#16415f"
        border.width: 1

        Text {
            anchors.fill: parent
            anchors.leftMargin: headerCell.textAlignment === Text.AlignLeft ? 8 : 0
            anchors.rightMargin: headerCell.textAlignment === Text.AlignLeft ? 6 : 0
            text: headerCell.label
            color: root.textMain
            font.pixelSize: 11
            font.bold: true
            verticalAlignment: Text.AlignVCenter
            horizontalAlignment: headerCell.textAlignment
            elide: Text.ElideRight
        }
        MouseArea {
            anchors.fill: parent
            enabled: headerCell.sortable
            cursorShape: Qt.PointingHandCursor
            onClicked: headerCell.clicked()
        }
    }

    component AlarmTableRow: Rectangle {
        id: alarmRow
        property var alarm: ({})
        readonly property bool blinkFault: alarm.level === "Fault" && alarm.status === "Active" && !alarm.ack
        property real blinkOpacity: 1.0
        height: 46
        radius: 6
        color: root.selectedAlarm && root.selectedAlarm.id === alarm.id ? "#123d5b" : (rowMouse.containsMouse ? "#102033" : root.rowBg(alarm))
        border.color: root.selectedAlarm && root.selectedAlarm.id === alarm.id ? root.infoColor : "#123d5b"
        border.width: 1
        opacity: blinkFault ? blinkOpacity : 1.0

        Rectangle {
            x: 0
            y: 0
            width: 5
            height: parent.height
            radius: 2
            color: alarm.status === "Cleared" ? root.normalColor : root.colorForLevel(alarm.level)
        }

        SequentialAnimation on blinkOpacity {
            running: alarmRow.blinkFault
            loops: Animation.Infinite
            NumberAnimation { from: 0.72; to: 1.0; duration: 650 }
            NumberAnimation { from: 1.0; to: 0.72; duration: 650 }
        }

        MouseArea {
            id: rowMouse
            anchors.fill: parent
            hoverEnabled: true
            onClicked: root.selectAlarm(alarmRow.alarm)
        }

        SelectBox { x: 10; anchors.verticalCenter: parent.verticalCenter; selected: root.isSelected(alarmRow.alarm.id); onClicked: root.toggleSelected(alarmRow.alarm.id) }
        CellText { x: root.colSelect; width: root.colTime; text: alarmRow.alarm.timestamp || alarmRow.alarm.time || "--" }
        SeverityBadge { x: root.colSelect + root.colTime + 6; anchors.verticalCenter: parent.verticalCenter; level: alarmRow.alarm.level || "--" }
        CellText { x: root.colSelect + root.colTime + root.colLevel; width: root.colStatus; text: alarmRow.alarm.status || "--"; textColor: alarmRow.alarm.status === "Cleared" ? root.normalColor : root.textMain }
        CellText { x: root.colSelect + root.colTime + root.colLevel + root.colStatus; width: root.colSource; text: alarmRow.alarm.source || "--" }
        CellText { x: root.colSelect + root.colTime + root.colLevel + root.colStatus + root.colSource; width: root.colGrid; text: alarmRow.alarm.grid || "--" }
        CellText { x: root.colSelect + root.colTime + root.colLevel + root.colStatus + root.colSource + root.colGrid; width: root.colDevice; text: alarmRow.alarm.deviceId || "--" }
        CellText { x: root.colSelect + root.colTime + root.colLevel + root.colStatus + root.colSource + root.colGrid + root.colDevice; width: root.colCode; text: alarmRow.alarm.code || "--"; textColor: root.colorForLevel(alarmRow.alarm.level) }
        CellText { x: root.colSelect + root.colTime + root.colLevel + root.colStatus + root.colSource + root.colGrid + root.colDevice + root.colCode; width: root.colDesc; text: alarmRow.alarm.description || "--" }
        CellText { x: root.colSelect + root.colTime + root.colLevel + root.colStatus + root.colSource + root.colGrid + root.colDevice + root.colCode + root.colDesc; width: root.colValue; text: alarmRow.alarm.valueText || "--" }
        CellText { x: root.colSelect + root.colTime + root.colLevel + root.colStatus + root.colSource + root.colGrid + root.colDevice + root.colCode + root.colDesc + root.colValue; width: root.colThreshold; text: alarmRow.alarm.threshold || "--" }
        CellText { x: root.colSelect + root.colTime + root.colLevel + root.colStatus + root.colSource + root.colGrid + root.colDevice + root.colCode + root.colDesc + root.colValue + root.colThreshold; width: root.colAck; text: alarmRow.alarm.ack ? "Ack" : "Unack"; textColor: alarmRow.alarm.ack ? root.normalColor : root.warningColor; textAlignment: Text.AlignHCenter }

        Row {
            x: root.colSelect + root.colTime + root.colLevel + root.colStatus + root.colSource + root.colGrid + root.colDevice + root.colCode + root.colDesc + root.colValue + root.colThreshold + root.colAck + 8
            y: 8
            spacing: 6
            ToolbarButton {
                width: 54
                label: alarmRow.alarm.ack ? "Acked" : "Ack"
                accent: alarmRow.alarm.ack ? root.normalColor : root.warningColor
                enabled: root.writeActionsEnabled && !alarmRow.alarm.ack && alarmRow.alarm.status === "Active"
                onClicked: root.acknowledgeOne(alarmRow.alarm.id)
            }
            ToolbarButton {
                width: 54
                label: "Clear"
                accent: root.normalColor
                enabled: root.writeActionsEnabled && alarmRow.alarm.status === "Active"
                onClicked: root.clearOne(alarmRow.alarm.id)
            }
        }
    }

    component CellText: Text {
        property color textColor: root.textMain
        property int textAlignment: Text.AlignLeft
        y: 0
        height: 46
        leftPadding: textAlignment === Text.AlignLeft ? 8 : 0
        rightPadding: textAlignment === Text.AlignLeft ? 8 : 0
        color: textColor
        font.pixelSize: 12
        verticalAlignment: Text.AlignVCenter
        horizontalAlignment: textAlignment
        elide: Text.ElideRight
    }

    component SeverityBadge: Rectangle {
        property string level: "--"
        width: 82
        height: 26
        radius: 13
        color: root.colorForLevel(level)

        Text {
            anchors.centerIn: parent
            text: root.levelIcon(level) + " " + level
            color: "#04111f"
            font.pixelSize: 10
            font.bold: true
        }
    }

    component SelectBox: Rectangle {
        id: selectBox
        property bool selected: false
        signal clicked()
        width: 16
        height: 16
        radius: 3
        color: selected ? root.infoColor : "#061421"
        border.color: selected ? root.infoColor : root.unknownColor
        border.width: 1
        Text {
            anchors.centerIn: parent
            text: selectBox.selected ? "x" : ""
            color: "#04111f"
            font.pixelSize: 10
            font.bold: true
        }
        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            onClicked: selectBox.clicked()
        }
    }

    component StatusPill: Rectangle {
        property string label: "--"
        property color accent: root.infoColor
        width: Math.max(86, pillText.implicitWidth + 24)
        height: 28
        radius: 14
        color: accent
        Text {
            id: pillText
            anchors.centerIn: parent
            text: label
            color: "#04111f"
            font.pixelSize: 11
            font.bold: true
        }
    }

    component DetailRow: Rectangle {
        property string label: ""
        property string value: ""
        readonly property real labelWidth: Math.min(126, Math.max(92, width * 0.36))
        readonly property real valueLeft: labelWidth + 18
        width: parent ? parent.width : 340
        height: Math.max(34, rowValue.implicitHeight + 14)
        radius: 6
        color: "#0a1f33"
        border.color: "#173d5c"
        border.width: 1

        Text {
            x: 10
            y: 8
            width: parent.labelWidth
            text: label
            color: root.textMuted
            font.pixelSize: 12
            elide: Text.ElideRight
        }
        Text {
            id: rowValue
            x: parent.valueLeft
            y: 8
            width: parent.width - parent.valueLeft - 10
            text: value
            color: root.textMain
            font.pixelSize: 12
            font.bold: true
            wrapMode: Text.WordWrap
            horizontalAlignment: Text.AlignRight
        }
    }
}

