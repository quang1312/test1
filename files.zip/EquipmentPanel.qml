pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Controls.Basic as Controls
import "components"

Rectangle {
    id: root

    property var configSource: null
    property var pcsSource: null
    property var batterySource: null
    property var pvSource: null
    property var equipmentRowsCache: []
    property var filteredRowsCache: []
    property var pagedRowsCache: []
    property var statusCountsCache: ({})
    property var statusRowsCache: []
    property var selectedEquipmentCache: ({})
    property int totalEquipmentCountCache: 0
    property int totalPagesCache: 1
    property int pageStartCache: 0
    property string showingTextCache: "Showing 0 of 0 entries"
    property bool refreshPending: false
    property int selectedIndex: 0
    property string selectedType: "All Types"
    property string selectedStatus: "All Status"
    property string selectedLocation: "All Locations"
    property string selectedMaker: "All"
    property string searchText: ""
    property int currentPage: 1
    property int rowsPerPage: 8
    property string statusMessage: ""
    property bool detailDialogVisible: false
    readonly property real colK: 1.45
    readonly property color bgColor: "#031624"
    readonly property color panelColor: "#071c2b"
    readonly property color panelHeaderColor: "#092235"
    readonly property color cardColor: "#082034"
    readonly property color lineColor: "#16415f"
    readonly property color textColor: "#eef6ff"
    readonly property color mutedTextColor: "#9db2c5"
    readonly property color blueColor: "#128cff"
    readonly property color cyanColor: "#20c7d7"
    readonly property color greenColor: "#3bd15b"
    readonly property color yellowColor: "#ffc323"
    readonly property color orangeColor: "#f59e0b"
    readonly property color redColor: "#ff4038"
    readonly property color violetColor: "#8b5cf6"
    readonly property color grayColor: "#94a3b8"
    property real boardScale: Math.min(width / board.width, height / board.height)

    color: bgColor
    radius: 8
    border.color: "#12324b"
    border.width: 1
    clip: true

    function numberValue(value, fallbackValue) {
        var n = Number(value);
        return isNaN(n) ? fallbackValue : n;
    }

    function fmt(value, digits) {
        return numberValue(value, 0).toFixed(digits);
    }

    function showStatus(message) {
        statusMessage = message;
        statusTimer.restart();
    }

    function scheduleCacheRefresh() {
        if (!cacheRefreshTimer.running)
            cacheRefreshTimer.start();
    }

    function resetSelection() {
        var total = filteredRowsCache.length;
        currentPage = Math.max(1, Math.min(currentPage, totalPages()));
        var start = pageStart();
        if (selectedIndex < start || selectedIndex >= start + rowsPerPage)
            selectedIndex = Math.min(start, Math.max(0, total - 1));
        else
            selectedIndex = Math.min(selectedIndex, Math.max(0, total - 1));
        updateSelectedEquipmentCache();
    }

    function clearFilters() {
        selectedType = "All Types";
        selectedStatus = "All Status";
        selectedLocation = "All Locations";
        selectedMaker = "All";
        searchText = "";
        currentPage = 1;
        selectedIndex = 0;
        showStatus("Filters cleared");
    }

    function statusColor(rawStatus) {
        if (rawStatus === "Online" || rawStatus === "Normal")
            return greenColor;
        if (rawStatus === "Warning")
            return yellowColor;
        if (rawStatus === "Critical" || rawStatus === "Fault")
            return redColor;
        return grayColor;
    }

    function statusRows() {
        return statusRowsCache;
    }

    readonly property var categoryMeta: ({
        "PCS": { label: "PCS", icon: "pcs", color: blueColor, detailKind: "Power Conversion System" },
        "BESS": { label: "BESS", icon: "bess", color: violetColor, detailKind: "Battery Energy Storage" },
        "PV": { label: "PV", icon: "solar_pv", color: yellowColor, detailKind: "PV Inverter" },
        "PQM": { label: "PQM", icon: "total_rate_power", color: cyanColor, detailKind: "Power Quality Meter" }
    })

    function typeRows() {
        var rows = equipmentRowsCache;
        var total = rows.length;
        var counts = {};
        for (var i = 0; i < rows.length; i++)
            counts[rows[i].type] = (counts[rows[i].type] || 0) + 1;
        var out = [];
        var keys = Object.keys(counts);
        for (var k = 0; k < keys.length; k++) {
            var meta = root.categoryMeta[keys[k]] || { label: keys[k], color: grayColor };
            out.push({ label: meta.label, value: counts[keys[k]], percent: total > 0 ? counts[keys[k]] * 100 / total : 0, color: meta.color });
        }
        return out;
    }

    function statusBucket(rawStatus) {
        if (rawStatus === "Warning" || rawStatus === "Critical" || rawStatus === "Fault")
            return "Alarm";
        if (rawStatus === "Offline" || rawStatus === "Connecting")
            return "Offline";
        return "Online";
    }

    function normalizeRow(raw, category, grid) {
        var meta = root.categoryMeta[category] || {};
        var rawStatus = raw.rtStatus || raw.status || "";
        var location = grid.name;
        var capacity = "--";
        var loadKw = 0;
        var hasLoad = false;
        if (category === "PCS") {
            capacity = root.fmt(raw.cfgRatedPowerMw, 2) + " MW";
            loadKw = numberValue(raw.rtPkw, 0);
            hasLoad = true;
        } else if (category === "BESS") {
            capacity = root.fmt(raw.ratedEnergyMwh, 2) + " MWh";
            loadKw = numberValue(raw.powerKw, 0);
            hasLoad = true;
        } else if (category === "PV") {
            capacity = root.fmt(raw.cfgRatedPowerMw, 2) + " MW";
            loadKw = numberValue(raw.rtAcPowerMw, 0) * 1000;
            hasLoad = true;
        }
        var capacityKw = category === "BESS" ? numberValue(raw.ratedEnergyMwh, 0) * 1000 : numberValue(raw.cfgRatedPowerMw, 0) * 1000;
        var loadPct = hasLoad && capacityKw > 0 ? Math.min(100, Math.round(Math.abs(loadKw) / capacityKw * 100)) : 0;
        var loadText = "--";
        if (hasLoad) {
            var absLoadKw = Math.abs(loadKw);
            var loadValueText = absLoadKw >= 1000 ? root.fmt(absLoadKw / 1000, 2) + " MW" : root.fmt(absLoadKw, 0) + " kW";
            loadText = (loadKw < 0 ? "-" : "") + loadValueText;
        }
        return {
            name: raw.containerId || "--",
            type: category,
            location: location,
            status: rawStatus || "--",
            statusBucket: root.statusBucket(rawStatus),
            capacity: capacity,
            load: hasLoad ? (category === "BESS" && loadKw !== 0 ? loadText + (loadKw > 0 ? " (Discharge)" : " (Charge)") : loadText) : "--",
            loadPct: loadPct,
            capacityMw: category === "BESS" ? 0 : numberValue(raw.cfgRatedPowerMw, 0),
            loadKwValue: hasLoad ? loadKw : 0,
            maker: raw.cfgDeviceType || "--",
            address: raw.address || "--",
            alarmCount: numberValue(raw.rtAlarmCount !== undefined ? raw.rtAlarmCount : raw.alarmCount, 0),
            icon: meta.icon || "▦",
            detailKind: meta.detailKind || category
        };
    }

    function appendRows(rows, source, slotName, grid, category) {
        if (!source || typeof source[slotName] !== "function")
            return;
        var raw = source[slotName](grid.id) || [];
        for (var i = 0; i < raw.length; i++)
            rows.push(root.normalizeRow(raw[i], category, grid));
    }

    function buildEquipmentRows() {
        var grids = (root.configSource && root.configSource.mainGrids) ? root.configSource.mainGrids : [];
        var rows = [];
        for (var g = 0; g < grids.length; g++) {
            var grid = grids[g];
            appendRows(rows, root.pcsSource, "pcsContainersForGrid", grid, "PCS");
            appendRows(rows, root.batterySource, "bessContainersForGrid", grid, "BESS");
            appendRows(rows, root.pvSource, "pvContainersForGrid", grid, "PV");
            appendRows(rows, root.pvSource, "pqmContainersForGrid", grid, "PQM");
        }
        return rows;
    }

    function distinctOptions(rows, field, allLabel) {
        var seen = {};
        var out = [allLabel];
        for (var i = 0; i < rows.length; i++) {
            var value = rows[i][field];
            if (value && !seen[value]) {
                seen[value] = true;
                out.push(value);
            }
        }
        return out;
    }

    function typeFilterOptions() {
        return distinctOptions(equipmentRowsCache, "type", "All Types");
    }

    function locationFilterOptions() {
        return distinctOptions(equipmentRowsCache, "location", "All Locations");
    }

    function makerFilterOptions() {
        return distinctOptions(equipmentRowsCache, "maker", "All");
    }

    function equipmentRows() {
        return equipmentRowsCache;
    }

    function applyEquipmentFilters(rows) {
        var text = searchText.toLowerCase();
        var out = [];
        for (var i = 0; i < rows.length; i++) {
            var item = rows[i];
            var matchesType = selectedType === "All Types" || item.type === selectedType;
            var matchesStatus = selectedStatus === "All Status" || item.statusBucket === selectedStatus;
            var matchesLocation = selectedLocation === "All Locations" || item.location === selectedLocation;
            var matchesMaker = selectedMaker === "All" || item.maker === selectedMaker;
            var haystack = (item.name + " " + item.type + " " + item.location + " " + item.maker + " " + item.status).toLowerCase();
            var matchesSearch = text.length === 0 || haystack.indexOf(text) >= 0;
            if (matchesType && matchesStatus && matchesLocation && matchesMaker && matchesSearch)
                out.push(item);
        }
        return out;
    }

    function totalEquipmentCount() {
        return totalEquipmentCountCache;
    }

    function buildStatusCounts(rows) {
        var counts = {
            "Online": 0,
            "Alarm": 0,
            "Offline": 0
        };
        for (var i = 0; i < rows.length; i++) {
            var bucket = rows[i].statusBucket || "Offline";
            counts[bucket] = (counts[bucket] || 0) + 1;
        }
        return counts;
    }

    function statusCounts() {
        return statusCountsCache;
    }

    function statusCount(status) {
        var counts = statusCounts();
        return counts[status] || 0;
    }

    function statusPercent(status, total) {
        var denominator = total > 0 ? total : totalEquipmentCount();
        if (denominator <= 0)
            return 0;
        return statusCount(status) * 100 / denominator;
    }

    function statusPercentText(status) {
        return root.fmt(statusPercent(status, totalEquipmentCount()), 1) + "%";
    }

    function filteredEquipmentRows() {
        return filteredRowsCache;
    }

    function totalPages() {
        return totalPagesCache;
    }

    function setRowsPerPage(value) {
        rowsPerPage = Number(value);
        currentPage = 1;
        resetSelection();
        showStatus("Rows per page: " + rowsPerPage);
    }

    function goToPage(page) {
        currentPage = Math.max(1, Math.min(Number(page), totalPages()));
        resetSelection();
        showStatus("Page " + currentPage + " of " + totalPages());
    }

    function paginationItems() {
        var total = totalPages();
        var page = Math.max(1, Math.min(currentPage, total));
        var items = [];
        function addPage(value) {
            items.push({ label: String(value), page: value, ellipsis: false });
        }
        function addGap() {
            items.push({ label: "...", page: -1, ellipsis: true });
        }
        if (total <= 5) {
            for (var i = 1; i <= total; i++)
                addPage(i);
            return items;
        }
        addPage(1);
        var start = Math.max(2, page - 1);
        var end = Math.min(total - 1, page + 1);
        if (page <= 3) {
            start = 2;
            end = 4;
        } else if (page >= total - 2) {
            start = total - 3;
            end = total - 1;
        }
        if (start > 2)
            addGap();
        for (var p = start; p <= end; p++)
            addPage(p);
        if (end < total - 1)
            addGap();
        addPage(total);
        return items;
    }

    function pageStart() {
        return pageStartCache;
    }

    function pagedEquipmentRows() {
        return pagedRowsCache;
    }

    function showingText() {
        return showingTextCache;
    }

    function selectedEquipment() {
        return selectedEquipmentCache;
    }

    function updateSelectedEquipmentCache() {
        var rows = filteredRowsCache || [];
        var i = Math.max(0, Math.min(selectedIndex, rows.length - 1));
        selectedEquipmentCache = rows.length > 0 ? rows[i] : ({});
    }

    function rebuildEquipmentCache() {
        var rows = buildEquipmentRows();
        var filtered = applyEquipmentFilters(rows);
        var total = filtered.length;
        var pages = Math.max(1, Math.ceil(total / rowsPerPage));
        var page = Math.max(1, Math.min(currentPage, pages));
        if (currentPage !== page)
            currentPage = page;
        var start = Math.max(0, (page - 1) * rowsPerPage);
        var maxSelected = Math.max(0, total - 1);
        var selected = Math.max(0, Math.min(selectedIndex, maxSelected));
        if (selectedIndex !== selected)
            selectedIndex = selected;

        equipmentRowsCache = rows;
        filteredRowsCache = filtered;
        totalEquipmentCountCache = rows.length;
        totalPagesCache = pages;
        pageStartCache = start;
        pagedRowsCache = filtered.slice(start, start + rowsPerPage);
        showingTextCache = total === 0 ? "Showing 0 of 0 entries" : "Showing " + (start + 1) + " to " + Math.min(total, start + rowsPerPage) + " of " + total + " filtered entries";
        statusCountsCache = buildStatusCounts(rows);
        statusRowsCache = [
            { label: "Online", value: statusCountsCache.Online || 0, percent: statusPercent("Online", rows.length), color: greenColor },
            { label: "Alarm", value: statusCountsCache.Alarm || 0, percent: statusPercent("Alarm", rows.length), color: redColor },
            { label: "Offline", value: statusCountsCache.Offline || 0, percent: statusPercent("Offline", rows.length), color: grayColor }
        ];
        updateSelectedEquipmentCache();
        redrawCharts();
    }

    function maintenanceRows() {
        return [];
    }

    function efficiencyPoints() {
        return [];
    }

    function totalRatedPowerMw() {
        var rows = equipmentRowsCache;
        var total = 0;
        for (var i = 0; i < rows.length; i++)
            total += rows[i].capacityMw || 0;
        return total;
    }

    function totalLoadKw() {
        var rows = equipmentRowsCache;
        var total = 0;
        for (var i = 0; i < rows.length; i++)
            total += Math.abs(rows[i].loadKwValue || 0);
        return total;
    }

    function redrawCharts() {
        if (statusDonut)
            statusDonut.requestPaint();
        if (typeDonut)
            typeDonut.requestPaint();
        if (efficiencyChart)
            efficiencyChart.requestPaint();
    }

    onSelectedTypeChanged: scheduleCacheRefresh()
    onSelectedStatusChanged: scheduleCacheRefresh()
    onSelectedLocationChanged: scheduleCacheRefresh()
    onSelectedMakerChanged: scheduleCacheRefresh()
    onSearchTextChanged: scheduleCacheRefresh()
    onCurrentPageChanged: scheduleCacheRefresh()
    onRowsPerPageChanged: scheduleCacheRefresh()
    onSelectedIndexChanged: updateSelectedEquipmentCache()
    onWidthChanged: redrawCharts()
    onHeightChanged: redrawCharts()

    Component.onCompleted: rebuildEquipmentCache()

    function requestRefresh() {
        if (!root.visible)
            return;
        root.refreshPending = true;
        if (!refreshTimer.running)
            refreshTimer.start();
    }

    Connections {
        target: root.configSource
        function onConfigChanged() { root.requestRefresh(); }
    }

    Connections {
        target: root.pcsSource
        function onDataChanged() { root.requestRefresh(); }
    }

    Connections {
        target: root.batterySource
        function onDataChanged() { root.requestRefresh(); }
    }

    Connections {
        target: root.pvSource
        function onDataChanged() { root.requestRefresh(); }
    }

    onVisibleChanged: {
        if (visible && root.refreshPending && !refreshTimer.running)
            refreshTimer.start();
    }

    Repeater {
        model: 58
        Rectangle {
            required property int index
            x: index * 42
            width: 1
            height: parent.height
            color: "#0d2a40"
            opacity: 0.38
        }
    }

    Repeater {
        model: 36
        Rectangle {
            required property int index
            y: index * 36
            width: parent.width
            height: 1
            color: "#0d2a40"
            opacity: 0.24
        }
    }

    Item {
        id: board
        width: 1780
        height: 1120
        anchors.centerIn: parent
        scale: root.boardScale

        Text {
            x: 0
            y: 0
            width: 360
            text: "EQUIPMENT OVERVIEW"
            color: root.textColor
            font.pixelSize: 18
            font.bold: true
            elide: Text.ElideRight
        }

        Row {
            x: 0
            y: 36
            spacing: 10

            KpiTile { width: 245; title: "TOTAL EQUIPMENT"; value: String(root.totalEquipmentCount()); subText: "PCS/BESS/PV/PQM"; iconText: "components"; accent: root.grayColor }
            KpiTile { width: 245; title: "ONLINE"; value: String(root.statusCount("Online")); subText: root.statusPercentText("Online"); iconText: "online_status"; accent: root.greenColor }
            KpiTile { width: 245; title: "OFFLINE"; value: String(root.statusCount("Offline")); subText: root.statusPercentText("Offline"); iconText: "offline_status"; accent: root.redColor }
            KpiTile { width: 245; title: "MAINTENANCE"; value: "--"; subText: "Chưa có nguồn dữ liệu"; iconText: "maintenance"; accent: root.yellowColor }
            KpiTile { width: 245; title: "ALARM"; value: String(root.statusCount("Alarm")); subText: root.statusPercentText("Alarm"); iconText: "alarms"; accent: root.redColor }
            KpiTile { width: 245; title: "TOTAL RATED POWER"; value: root.fmt(root.totalRatedPowerMw(), 2); unitText: "MW"; subText: "PCS + PV"; iconText: "total_rate_power"; accent: root.blueColor }
            KpiTile { width: 245; title: "TOTAL LOAD"; value: root.fmt(root.totalLoadKw() / 1000, 2); unitText: "MW"; subText: "PCS + BESS + PV"; iconText: "plug"; accent: root.violetColor }
        }

        PanelCard {
            x: 0
            y: 166
            width: 1780
            height: 120
            z: 20
            clip: false
            title: "EQUIPMENT LIST"

            Row {
                x: 18
                y: 56
                spacing: 22

                FilterGroup {
                    label: "Equipment Type"
                    value: root.selectedType
                    options: root.typeFilterOptions()
                    boxWidth: 238
                    onSelected: function(value) {
                        root.selectedType = value;
                        root.currentPage = 1;
                        root.selectedIndex = 0;
                        root.showStatus("Equipment type: " + value);
                    }
                }
                FilterGroup {
                    label: "Status"
                    value: root.selectedStatus
                    options: ["All Status", "Online", "Alarm", "Offline"]
                    boxWidth: 200
                    onSelected: function(value) {
                        root.selectedStatus = value;
                        root.currentPage = 1;
                        root.selectedIndex = 0;
                        root.showStatus("Status filter: " + value);
                    }
                }
                FilterGroup {
                    label: "Main Grid"
                    value: root.selectedLocation
                    options: root.locationFilterOptions()
                    boxWidth: 216
                    onSelected: function(value) {
                        root.selectedLocation = value;
                        root.currentPage = 1;
                        root.selectedIndex = 0;
                        root.showStatus("Location filter: " + value);
                    }
                }
                FilterGroup {
                    label: "Manufacturer"
                    value: root.selectedMaker
                    options: root.makerFilterOptions()
                    boxWidth: 216
                    onSelected: function(value) {
                        root.selectedMaker = value;
                        root.currentPage = 1;
                        root.selectedIndex = 0;
                        root.showStatus("Manufacturer filter: " + value);
                    }
                }
            }

            SearchBox {
                x: 990
                y: 56
                width: 266
                height: 56
                text: root.searchText
                onTextEdited: function(value) {
                    root.searchText = value;
                    root.currentPage = 1;
                    root.selectedIndex = 0;
                }
            }

            ActionButton {
                x: 1288
                y: 68
                width: 110
                label: "Filter"
                iconText: "fillter"
                accent: root.blueColor
                filled: true
                onClicked: {
                    root.currentPage = 1;
                    root.selectedIndex = 0;
                    root.showStatus("Filter applied: " + root.filteredEquipmentRows().length + " equipment matched");
                }
            }

            ActionButton {
                x: 1418
                y: 68
                width: 112
                label: "Clear"
                iconText: "clear"
                accent: root.grayColor
                onClicked: root.clearFilters()
            }

            ActionButton {
                x: 1494
                y: 12
                width: 158
                label: "Add Equipment"
                iconText: "add_device"
                accent: root.blueColor
                filled: true
                onClicked: root.showStatus("Not supported yet")
            }

            ActionButton {
                x: 1672
                y: 12
                width: 88
                label: "Export"
                iconText: "file_export"
                accent: root.grayColor
                onClicked: root.showStatus("Exported " + root.filteredEquipmentRows().length + " filtered equipment rows")
            }
        }

        Rectangle {
            x: 1138
            y: 136
            width: 620
            height: 26
            radius: 5
            visible: root.statusMessage.length > 0
            color: "#08243a"
            border.color: root.blueColor
            border.width: 1
            z: 30

            Text {
                anchors.fill: parent
                anchors.leftMargin: 12
                anchors.rightMargin: 12
                text: root.statusMessage
                color: "#ccecff"
                font.pixelSize: 12
                font.bold: true
                verticalAlignment: Text.AlignVCenter
                elide: Text.ElideRight
            }
        }

        Rectangle {
            x: 0
            y: 290
            width: 1780
            height: 500
            radius: 8
            color: root.panelColor
            border.color: "#143a56"
            border.width: 1
            clip: true

            Row {
                x: 18
                y: 18
                height: 28
                Text { width: 40 + 164 * root.colK; text: "EQUIPMENT NAME"; color: root.mutedTextColor; font.pixelSize: 12; font.bold: true; horizontalAlignment: Text.AlignHCenter }
                Text { width: 150 * root.colK; text: "TYPE"; color: root.mutedTextColor; font.pixelSize: 12; font.bold: true }
                Text { width: 168 * root.colK; text: "LOCATION"; color: root.mutedTextColor; font.pixelSize: 12; font.bold: true }
                Text { width: 130; text: "STATUS"; color: root.mutedTextColor; font.pixelSize: 12; font.bold: true }
                Text { width: 130; text: "CAPACITY"; color: root.mutedTextColor; font.pixelSize: 12; font.bold: true }
                Text { width: 170; text: "LOAD"; color: root.mutedTextColor; font.pixelSize: 12; font.bold: true }
                Text { width: 150 * root.colK; text: "MANUFACTURER"; color: root.mutedTextColor; font.pixelSize: 12; font.bold: true }
                Text { width: 156 * root.colK; text: "ADDRESS"; color: root.mutedTextColor; font.pixelSize: 12; font.bold: true }
                Text { width: 72; text: "ACTIONS"; color: root.mutedTextColor; font.pixelSize: 12; font.bold: true; horizontalAlignment: Text.AlignHCenter }
            }

            Rectangle { x: 0; y: 54; width: parent.width; height: 1; color: root.lineColor }

            Flickable {
                id: rowsScrollView
                x: 0
                y: 55
                width: parent.width
                height: parent.height - 101
                contentWidth: width
                contentHeight: Math.max(height, root.pagedEquipmentRows().length * 42)
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                flickableDirection: Flickable.VerticalFlick
                interactive: contentHeight > height

                ScrollBar.vertical: ScrollBar {
                    policy: ScrollBar.AsNeeded
                }

                Column {
                    width: rowsScrollView.width
                    spacing: 0

                    Repeater {
                        model: root.pagedEquipmentRows()
                        EquipmentRow {
                            required property var modelData
                            required property int index
                            width: rowsScrollView.width
                            property int actualIndex: root.pageStart() + index
                            selected: root.selectedIndex === actualIndex
                            rowData: modelData
                            onClicked: {
                                root.selectedIndex = actualIndex;
                                root.detailDialogVisible = true;
                            }
                        }
                    }
                }
            }

            Text {
                x: 18
                y: parent.height - 34
                text: root.showingText()
                color: root.mutedTextColor
                font.pixelSize: 13
                font.bold: true
            }

            Row {
                anchors.right: parent.right
                anchors.rightMargin: 18
                y: parent.height - 40
                height: 28
                spacing: 8
                Text { text: "Rows per page:"; color: root.mutedTextColor; font.pixelSize: 13; anchors.verticalCenter: parent.verticalCenter }
                PageSizeCombo { value: root.rowsPerPage; onSelected: function(value) { root.setRowsPerPage(value); } }
                PageButton { label: "«"; width: 34; enabled: root.currentPage > 1; onClicked: root.goToPage(1) }
                PageButton { label: "‹"; width: 34; enabled: root.currentPage > 1; onClicked: root.goToPage(root.currentPage - 1) }
                Repeater {
                    model: root.paginationItems()
                    PageButton {
                        required property var modelData
                        label: modelData.label
                        width: modelData.ellipsis ? 40 : 34
                        enabled: !modelData.ellipsis
                        selected: !modelData.ellipsis && root.currentPage === modelData.page
                        onClicked: root.goToPage(modelData.page)
                    }
                }
                PageButton { label: "›"; width: 34; enabled: root.currentPage < root.totalPages(); onClicked: root.goToPage(root.currentPage + 1) }
                PageButton { label: "»"; width: 34; enabled: root.currentPage < root.totalPages(); onClicked: root.goToPage(root.totalPages()) }
            }
        }

        PanelCard {
            x: 0
            y: 804
            width: 410
            height: 292
            title: "EQUIPMENT STATUS DISTRIBUTION"

            DonutChart {
                id: statusDonut
                x: 26
                y: 70
                width: 160
                height: 150
                rows: root.statusRows()
                centerTitle: String(root.totalEquipmentCount())
                centerSub: "Total"
            }

            LegendList {
                x: 210
                y: 78
                width: 196
                rows: root.statusRows()
                showPercent: true
            }
        }

        PanelCard {
            x: 422
            y: 804
            width: 410
            height: 292
            title: "EQUIPMENT BY TYPE"

            DonutChart {
                id: typeDonut
                x: 26
                y: 70
                width: 160
                height: 150
                rows: root.typeRows()
                centerTitle: String(root.totalEquipmentCount())
                centerSub: "Total"
            }

            LegendList {
                x: 210
                y: 62
                width: 196
                rows: root.typeRows()
                showPercent: true
            }
        }

        PanelCard {
            x: 844
            y: 804
            width: 420
            height: 292
            title: "EQUIPMENT EFFICIENCY TREND (%)"

            EfficiencyChart {
                id: efficiencyChart
                x: 30
                y: 66
                width: parent.width - 54
                height: parent.height - 100
                points: root.efficiencyPoints()
                visible: points.length > 0
            }

            Text {
                anchors.centerIn: parent
                visible: root.efficiencyPoints().length === 0
                width: parent.width - 60
                text: "Chưa có nguồn dữ liệu lịch sử hiệu suất thiết bị"
                color: root.mutedTextColor
                font.pixelSize: 13
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.WordWrap
            }

            Row {
                x: 146
                y: parent.height - 28
                spacing: 8
                visible: root.efficiencyPoints().length > 0
                Rectangle { width: 42; height: 4; radius: 2; color: root.greenColor; anchors.verticalCenter: parent.verticalCenter }
                Text { text: "Average Efficiency (%)"; color: root.mutedTextColor; font.pixelSize: 11; font.bold: true; anchors.verticalCenter: parent.verticalCenter }
            }
        }

        PanelCard {
            x: 1276
            y: 804
            width: 504
            height: 292
            title: "MAINTENANCE SCHEDULE"

            Row {
                x: 18
                y: 58
                height: 24
                visible: root.maintenanceRows().length > 0
                Text { width: 172; text: "EQUIPMENT"; color: root.mutedTextColor; font.pixelSize: 11; font.bold: true }
                Text { width: 110; text: "TYPE"; color: root.mutedTextColor; font.pixelSize: 11; font.bold: true }
                Text { width: 126; text: "SCHEDULED DATE"; color: root.mutedTextColor; font.pixelSize: 11; font.bold: true }
                Text { width: 72; text: "STATUS"; color: root.mutedTextColor; font.pixelSize: 11; font.bold: true; horizontalAlignment: Text.AlignHCenter }
            }

            Rectangle { x: 18; y: 84; width: parent.width - 36; height: 1; color: root.lineColor; visible: root.maintenanceRows().length > 0 }

            Column {
                x: 18
                y: 92
                width: parent.width - 36
                spacing: 8

                Repeater {
                    model: root.maintenanceRows()
                    MaintenanceRow {
                        required property var modelData
                        width: parent.width
                        item: modelData
                    }
                }
            }

            Text {
                anchors.centerIn: parent
                visible: root.maintenanceRows().length === 0
                width: parent.width - 60
                text: "Chưa có nguồn dữ liệu lịch bảo trì"
                color: root.mutedTextColor
                font.pixelSize: 13
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.WordWrap
            }
        }
    }

    Rectangle {
        anchors.fill: parent
        visible: root.detailDialogVisible
        z: 100
        color: "#000912"
        opacity: 0.72
        MouseArea { anchors.fill: parent; onClicked: root.detailDialogVisible = false }
    }

    Rectangle {
        id: fullDetailDialog
        visible: root.detailDialogVisible
        z: 101
        width: 620
        height: 420
        radius: 8
        color: "#071c2b"
        border.color: root.blueColor
        border.width: 1
        anchors.centerIn: parent

        property var item: root.selectedEquipment()

        Text {
            x: 22
            y: 18
            width: parent.width - 90
            text: fullDetailDialog.item.name || "Equipment details"
            color: root.textColor
            font.pixelSize: 18
            font.bold: true
            elide: Text.ElideRight
        }

        ActionButton {
            x: parent.width - 58
            y: 14
            width: 36
            label: ""
            iconText: "offline_status"
            accent: root.grayColor
            onClicked: root.detailDialogVisible = false
        }

        Grid {
            x: 26
            y: 64
            width: parent.width - 52
            height: 250
            columns: 2
            columnSpacing: 28
            rowSpacing: 10

            DetailRow { width: 260; label: "Type"; value: fullDetailDialog.item.type || "--" }
            DetailRow { width: 260; label: "Status"; value: fullDetailDialog.item.status || "--"; valueColor: root.statusColor(fullDetailDialog.item.status || "") }
            DetailRow { width: 260; label: "Location"; value: fullDetailDialog.item.location || "--" }
            DetailRow { width: 260; label: "Capacity"; value: fullDetailDialog.item.capacity || "--" }
            DetailRow { width: 260; label: "Load"; value: (fullDetailDialog.item.load || "--") + " (" + (fullDetailDialog.item.loadPct || 0) + "%)" }
            DetailRow { width: 260; label: "Manufacturer"; value: fullDetailDialog.item.maker || "--" }
            DetailRow { width: 260; label: "Address"; value: fullDetailDialog.item.address || "--" }
            DetailRow { width: 260; label: "Alarm Count"; value: String(fullDetailDialog.item.alarmCount || 0) }
        }

        LoadBar {
            x: 26
            y: 336
            width: parent.width - 52
            height: 12
            percent: fullDetailDialog.item.loadPct || 0
        }

        Text {
            x: 26
            y: 362
            width: parent.width - 52
            text: "Dữ liệu thiết bị đọc trực tiếp từ topology (pms_config.json) + NATS/MySQL thời gian thực — không có API/CSDL riêng để chỉnh sửa qua màn hình này."
            color: root.mutedTextColor
            font.pixelSize: 12
            wrapMode: Text.WordWrap
        }
    }

    Timer {
        id: statusTimer
        interval: 2600
        repeat: false
        onTriggered: root.statusMessage = ""
    }

    Timer {
        id: cacheRefreshTimer
        interval: 0
        repeat: false
        onTriggered: root.rebuildEquipmentCache()
    }

    Timer {
        id: refreshTimer
        interval: 5000
        repeat: false
        onTriggered: {
            if (!root.refreshPending)
                return;
            root.refreshPending = false;
            root.scheduleCacheRefresh();
        }
    }

    component PanelCard: Rectangle {
        id: panel
        default property alias content: contentLayer.data
        property string title: ""

        radius: 8
        color: root.panelColor
        border.color: "#143a56"
        border.width: 1
        clip: true

        Rectangle {
            x: 1
            y: 1
            width: parent.width - 2
            height: 49
            radius: 7
            color: root.panelHeaderColor
        }

        Rectangle { x: 0; y: 49; width: parent.width; height: 1; color: root.lineColor }

        Text {
            x: 16
            y: 15
            text: panel.title
            color: root.textColor
            font.pixelSize: 16
            font.bold: true
            elide: Text.ElideRight
        }

        Item {
            id: contentLayer
            anchors.fill: parent
        }
    }

    component KpiTile: Rectangle {
        id: card
        property string title: ""
        property string value: ""
        property string unitText: ""
        property string subText: ""
        property string iconText: ""
        property color accent: root.blueColor

        height: 108
        radius: 8
        color: root.cardColor
        border.color: "#143a56"
        border.width: 1
        clip: true

        Rectangle {
            x: 16
            y: 27
            width: 54
            height: 54
            radius: 27
            color: Qt.rgba(card.accent.r, card.accent.g, card.accent.b, 0.15)
            border.color: card.accent
            border.width: 1
            AppIcon { anchors.centerIn: parent; width: 28; height: 28; name: card.iconText; tint: card.accent }
        }

        Text {
            x: 86
            y: 18
            width: parent.width - 100
            text: card.title
            color: root.mutedTextColor
            font.pixelSize: 12
            font.bold: true
            elide: Text.ElideRight
        }

        Row {
            x: 86
            y: 44
            width: parent.width - 100
            spacing: 7
            Text { text: card.value; color: root.textColor; font.pixelSize: 25; font.bold: true }
            Text { text: card.unitText; color: "#d3e4f3"; font.pixelSize: 13; font.bold: true; anchors.baseline: parent.children[0].baseline }
        }

        Text {
            x: 86
            y: 80
            width: parent.width - 100
            text: card.subText
            color: root.mutedTextColor
            font.pixelSize: 12
            font.bold: true
            elide: Text.ElideRight
        }
    }

    component FilterGroup: Item {
        id: group
        property string label: ""
        property string value: ""
        property var options: []
        property int boxWidth: 200
        signal selected(string value)

        width: boxWidth
        height: 58
        z: dropdown.popup.visible ? 50 : 1

        FilterComboBox {
            id: dropdown
            x: 0
            y: 0
            width: group.boxWidth
            height: group.height
            highlightOnFocus: false
            label: group.label
            model: group.options
            currentIndex: Math.max(0, group.options.indexOf(group.value))
            onActivated: function(index) {
                group.selected(group.options[index]);
            }
        }
    }

    component SearchBox: Rectangle {
        id: searchBox
        property string text: ""
        signal textEdited(string value)

        height: 36
        radius: 5
        color: "#071827"
        border.color: "#173852"
        border.width: 1

        TextInput {
            id: searchInput
            x: 12
            y: 0
            width: parent.width - 46
            height: parent.height
            text: searchBox.text
            color: root.textColor
            font.pixelSize: 13
            verticalAlignment: Text.AlignVCenter
            clip: true
            selectByMouse: true
            onTextChanged: searchBox.textEdited(text)
        }

        Text {
            x: 12
            y: 0
            width: parent.width - 46
            height: parent.height
            visible: searchInput.text.length === 0 && !searchInput.activeFocus
            text: "Search Equipment"
            color: "#6f8aa3"
            font.pixelSize: 13
            verticalAlignment: Text.AlignVCenter
        }

        Text {
            x: parent.width - 34
            y: 0
            width: 22
            height: parent.height
            text: "⌕"
            color: root.mutedTextColor
            font.pixelSize: 18
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
        }
    }

    component ActionButton: Rectangle {
        id: button
        property string label: ""
        property string iconText: ""
        property color accent: root.blueColor
        property bool filled: false
        signal clicked()

        height: 34
        radius: 5
        color: button.filled ? (buttonMouse.containsMouse ? "#1260cc" : "#0d47a1") : (buttonMouse.containsMouse ? "#0a2438" : "#071827")
        border.color: button.filled ? "#1d6fd7" : (buttonMouse.containsMouse ? button.accent : "#173852")
        border.width: 1

        Row {
            anchors.centerIn: parent
            spacing: 8
            AppIcon { anchors.verticalCenter: parent.verticalCenter; width: 20; height: 20; name: button.iconText; tint: button.filled ? "#dcecff" : button.accent}
            Text { text: button.label; color: root.textColor; font.pixelSize: 13; font.bold: true; anchors.verticalCenter: parent.verticalCenter }
        }

        MouseArea {
            id: buttonMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: button.clicked()
        }
    }

    component EquipmentRow: Rectangle {
        id: row
        property var rowData: ({})
        property bool selected: false
        signal clicked()

        height: 42
        color: selected ? "#0a2a40" : "transparent"
        border.color: selected ? "#1f6aa5" : "#0d2a40"
        border.width: selected ? 1 : 0

        Row {
            x: 18
            y: 0
            height: parent.height

            Item {
                width: 40
                height: parent.height
                AppIcon { anchors.centerIn: parent; width: 26; height: 26; name: row.rowData.icon; tint: root.mutedTextColor }
            }
            Text { width: 164 * root.colK; height: parent.height; text: row.rowData.name || "--"; color: root.textColor; font.pixelSize: 12; font.bold: true; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
            Text { width: 150 * root.colK; height: parent.height; text: row.rowData.type || "--"; color: "#d7e3ed"; font.pixelSize: 12; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
            Text { width: 168 * root.colK; height: parent.height; text: row.rowData.location || "--"; color: "#d7e3ed"; font.pixelSize: 12; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
            Item {
                width: 130
                height: parent.height
                StatusBadge { anchors.verticalCenter: parent.verticalCenter; label: row.rowData.status || "--" }
            }
            Text { width: 130; height: parent.height; text: row.rowData.capacity || "--"; color: "#d7e3ed"; font.pixelSize: 12; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
            Item {
                width: 170
                height: parent.height
                Column {
                    width: 136
                    height: 27
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 5
                    Text {
                        width: parent.width
                        height: 16
                        text: (row.rowData.load || "--") + " (" + (row.rowData.loadPct || 0) + "%)"
                        color: "#d7e3ed"
                        font.pixelSize: 11
                        verticalAlignment: Text.AlignVCenter
                        elide: Text.ElideRight
                    }
                    LoadBar { width: parent.width; height: 6; percent: row.rowData.loadPct || 0 }
                }
            }
            Text { width: 150 * root.colK; height: parent.height; text: row.rowData.maker || "--"; color: "#d7e3ed"; font.pixelSize: 12; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
            Text { width: 156 * root.colK; height: parent.height; text: row.rowData.address || "--"; color: "#d7e3ed"; font.pixelSize: 11; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
            Row {
                width: 72
                height: parent.height
                spacing: 10
                Text { height: parent.height; text: "⊙"; color: root.mutedTextColor; font.pixelSize: 16; verticalAlignment: Text.AlignVCenter }
                Text { height: parent.height; text: "⌁"; color: root.mutedTextColor; font.pixelSize: 16; verticalAlignment: Text.AlignVCenter }
                Text { height: parent.height; text: "✎"; color: root.mutedTextColor; font.pixelSize: 15; verticalAlignment: Text.AlignVCenter }
            }
        }

        Rectangle { x: 0; y: parent.height - 1; width: parent.width; height: 1; color: "#0d2a40"; opacity: 0.8 }

        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            onClicked: row.clicked()
        }
    }

    component StatusBadge: Rectangle {
        id: badge
        property string label: ""
        property string rawStatus: label

        width: Math.max(66, badgeText.implicitWidth + 20)
        height: 24
        radius: 5
        color: root.statusColor(badge.rawStatus)
        opacity: 0.82

        Text {
            id: badgeText
            anchors.centerIn: parent
            text: badge.label
            color: "#ffffff"
            font.pixelSize: 12
            font.bold: true
        }
    }

    component LoadBar: Rectangle {
        id: bar
        property real percent: 0

        radius: height / 2
        color: "#24384a"
        Rectangle {
            width: parent.width * Math.max(0, Math.min(100, bar.percent)) / 100
            height: parent.height
            radius: parent.radius
            color: root.greenColor
        }
    }

    component DetailRow: Row {
        id: row
        property string label: ""
        property string value: ""
        property color valueColor: root.textColor

        height: 18
        Text { width: 142; height: parent.height; text: row.label; color: root.mutedTextColor; font.pixelSize: 11; font.bold: true; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
        Text { width: parent.width - 142; height: parent.height; text: row.value; color: row.valueColor; font.pixelSize: 11; font.bold: true; horizontalAlignment: Text.AlignRight; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
    }

    component PageSizeCombo: Item {
        id: pageSize
        property int value: 8
        property var options: [5, 8, 10, 20]
        signal selected(int value)

        width: 84
        height: 28
        z: combo.popup.visible ? 50 : 1

        Controls.ComboBox {
            id: combo
            anchors.fill: parent
            model: pageSize.options
            currentIndex: Math.max(0, pageSize.options.indexOf(pageSize.value))
            onActivated: function(index) {
                pageSize.selected(Number(pageSize.options[index]));
            }

            contentItem: Text {
                leftPadding: 12
                rightPadding: 24
                text: combo.displayText
                color: root.textColor
                font.pixelSize: 12
                font.bold: true
                verticalAlignment: Text.AlignVCenter
                elide: Text.ElideRight
            }

            indicator: Text {
                x: combo.width - 22
                y: 0
                width: 18
                height: combo.height
                text: combo.popup.visible ? "⌃" : "⌄"
                color: combo.hovered || combo.popup.visible ? root.blueColor : root.mutedTextColor
                font.pixelSize: 13
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
            }

            background: Rectangle {
                radius: 5
                color: combo.hovered || combo.popup.visible ? "#0a2438" : "#071827"
                border.color: combo.hovered || combo.popup.visible ? root.blueColor : "#173852"
                border.width: 1
            }

            delegate: Controls.ItemDelegate {
                id: sizeDelegate
                required property var modelData
                required property int index

                width: combo.width
                height: 28
                highlighted: combo.highlightedIndex === index

                contentItem: Text {
                    text: String(sizeDelegate.modelData)
                    color: sizeDelegate.highlighted ? root.textColor : "#cbd9e5"
                    font.pixelSize: 12
                    font.bold: sizeDelegate.highlighted
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }

                background: Rectangle {
                    color: sizeDelegate.highlighted ? "#0d3552" : (sizeDelegate.hovered ? "#0a2438" : "#071827")
                }
            }

            popup: Controls.Popup {
                y: -implicitHeight - 4
                width: combo.width
                implicitHeight: combo.delegateModel.count * 28 + 2
                padding: 1

                contentItem: ListView {
                    clip: true
                    implicitHeight: contentHeight
                    model: combo.popup.visible ? combo.delegateModel : null
                    currentIndex: combo.highlightedIndex
                }

                background: Rectangle {
                    radius: 5
                    color: "#071827"
                    border.color: root.blueColor
                    border.width: 1
                }
            }
        }
    }

    component PageButton: Rectangle {
        id: page
        property string label: ""
        property bool selected: false
        signal clicked()

        height: 28
        radius: 5
        color: !page.enabled ? "#061522" : page.selected ? "#0d47a1" : pageMouse.containsMouse ? "#0a2438" : "#071827"
        border.color: !page.enabled ? "#102b40" : page.selected ? "#1d6fd7" : pageMouse.containsMouse ? root.blueColor : "#173852"
        border.width: 1

        Text {
            anchors.centerIn: parent
            text: page.label
            color: !page.enabled ? "#53697c" : page.selected ? "#eaf6ff" : root.mutedTextColor
            font.pixelSize: 12
            font.bold: true
        }

        MouseArea {
            id: pageMouse
            anchors.fill: parent
            enabled: page.enabled
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: page.clicked()
        }
    }

    component DonutChart: Item {
        id: donut
        property var rows: []
        property string centerTitle: ""
        property string centerSub: ""

        function requestPaint() {
            donutCanvas.requestPaint();
        }

        Canvas {
            id: donutCanvas
            anchors.fill: parent
            onPaint: {
                var ctx = getContext("2d");
                ctx.clearRect(0, 0, width, height);
                var rows = donut.rows || [];
                var total = 0;
                for (var i = 0; i < rows.length; i++)
                    total += rows[i].value;
                var cx = width / 2;
                var cy = height / 2;
                var radius = Math.min(width, height) / 2 - 6;
                var start = -Math.PI / 2;
                for (var j = 0; j < rows.length; j++) {
                    var angle = rows[j].value / Math.max(1, total) * Math.PI * 2;
                    ctx.beginPath();
                    ctx.moveTo(cx, cy);
                    ctx.arc(cx, cy, radius, start, start + angle);
                    ctx.closePath();
                    ctx.fillStyle = rows[j].color;
                    ctx.globalAlpha = 0.9;
                    ctx.fill();
                    start += angle;
                }
                ctx.globalAlpha = 1.0;
                ctx.beginPath();
                ctx.arc(cx, cy, radius * 0.58, 0, Math.PI * 2);
                ctx.fillStyle = root.panelColor;
                ctx.fill();
                ctx.fillStyle = root.textColor;
                ctx.font = "bold 26px sans-serif";
                ctx.textAlign = "center";
                ctx.fillText(donut.centerTitle, cx, cy - 4);
                ctx.fillStyle = root.mutedTextColor;
                ctx.font = "bold 13px sans-serif";
                ctx.fillText(donut.centerSub, cx, cy + 18);
            }
            Component.onCompleted: requestPaint()
        }
    }

    component LegendList: Column {
        id: list
        property var rows: []
        property bool showPercent: false

        spacing: 12
        Repeater {
            model: list.rows || []
            Row {
                id: legendRow
                required property var modelData
                width: list.width
                height: 18
                spacing: 10

                Rectangle { width: 13; height: 13; radius: 3; color: legendRow.modelData.color; anchors.verticalCenter: parent.verticalCenter }
                Text { width: 70; text: legendRow.modelData.label; color: "#d7e3ed"; font.pixelSize: 12; font.bold: true; elide: Text.ElideRight; anchors.verticalCenter: parent.verticalCenter }
                Text {
                    width: list.width - 103
                    text: legendRow.modelData.value + (list.showPercent ? " (" + root.fmt(legendRow.modelData.percent, 1) + "%)" : "")
                    color: "#d7e3ed"
                    font.pixelSize: 12
                    horizontalAlignment: Text.AlignRight
                    elide: Text.ElideRight
                    anchors.verticalCenter: parent.verticalCenter
                }
            }
        }
    }

    component EfficiencyChart: Canvas {
        id: chart
        property var points: []

        onPaint: {
            var ctx = getContext("2d");
            ctx.clearRect(0, 0, width, height);
            var rows = chart.points || [];
            var padL = 44;
            var padR = 12;
            var padT = 12;
            var padB = 28;
            var plotW = width - padL - padR;
            var plotH = height - padT - padB;
            var minV = 70;
            var maxV = 100;
            ctx.strokeStyle = "#143a56";
            ctx.fillStyle = root.mutedTextColor;
            ctx.font = "11px sans-serif";
            for (var gy = 0; gy <= 3; gy++) {
                var y = padT + plotH * gy / 3;
                ctx.beginPath();
                ctx.moveTo(padL, y);
                ctx.lineTo(width - padR, y);
                ctx.stroke();
                ctx.fillText(String(maxV - (maxV - minV) * gy / 3), 4, y + 4);
            }
            function xAt(i) { return padL + plotW * i / Math.max(1, rows.length - 1); }
            function yAt(value) { return padT + (maxV - value) / (maxV - minV) * plotH; }
            ctx.beginPath();
            for (var i = 0; i < rows.length; i++) {
                var x = xAt(i);
                var yv = yAt(rows[i].value);
                if (i === 0)
                    ctx.moveTo(x, yv);
                else
                    ctx.lineTo(x, yv);
            }
            ctx.strokeStyle = root.greenColor;
            ctx.lineWidth = 2.4;
            ctx.stroke();
            for (var j = 0; j < rows.length; j++) {
                var px = xAt(j);
                var py = yAt(rows[j].value);
                ctx.beginPath();
                ctx.arc(px, py, 4, 0, Math.PI * 2);
                ctx.fillStyle = "#b8ffad";
                ctx.fill();
                ctx.fillStyle = root.mutedTextColor;
                ctx.fillText(rows[j].label, px - 16, height - 8);
            }
        }
    }

    component MaintenanceRow: Row {
        id: row
        property var item: ({})

        height: 24
        Text { width: 172; text: row.item.equipment || "--"; color: "#d7e3ed"; font.pixelSize: 12; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
        Text { width: 110; text: row.item.type || "--"; color: "#d7e3ed"; font.pixelSize: 12; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
        Text { width: 126; text: row.item.date || "--"; color: "#d7e3ed"; font.pixelSize: 12; verticalAlignment: Text.AlignVCenter }
        Rectangle {
            width: 76
            height: 22
            radius: 4
            color: row.item.color || root.blueColor
            opacity: 0.85
            Text { anchors.centerIn: parent; text: row.item.status || "--"; color: "#ffffff"; font.pixelSize: 11; font.bold: true }
        }
    }
}

