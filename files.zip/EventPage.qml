pragma ComponentBehavior: Bound
import QtQuick
import "components"

Rectangle {
    id: root
    property var dataSource: null
    property var eventsModel: dataSource ? dataSource.eventsModel : []
    property var eventSummary: dataSource ? dataSource.eventSummary : ({})
    property var selectedEvent: dataSource ? dataSource.selectedEvent : ({})
    property var eventFilter: dataSource ? dataSource.eventFilter : ({})
    property string statusMessage: dataSource ? dataSource.statusMessage : "Event manager disconnected"
    property bool live: dataSource ? !!dataSource.live : false
    property bool detailOpen: false
    property real boardScale: Math.min(width / board.width, height / board.height)

    color: "#07111f"
    radius: 0
    border.color: "transparent"
    border.width: 0
    clip: true

    Repeater {
        model: 56
        Rectangle {
            required property int index
            x: index * 38
            width: 1
            height: root.height
            color: "#142033"
            opacity: 0.20
        }
    }

    Repeater {
        model: 34
        Rectangle {
            required property int index
            y: index * 32
            width: root.width
            height: 1
            color: "#142033"
            opacity: 0.14
        }
    }

    Item {
        id: board
        width: 1440
        height: 960
        anchors.centerIn: parent
        scale: root.boardScale

        Rectangle {
            anchors.fill: parent
            radius: 8
            color: "#07111f"
            border.color: "#1e3a5f"
            border.width: 1
        }

        Row {
            x: 24
            y: 20
            width: parent.width - 48
            height: 54
            spacing: 14

            Rectangle {
                width: 9
                height: 48
                radius: 4
                color: "#f59e0b"
                anchors.verticalCenter: parent.verticalCenter
            }

            Column {
                width: 600
                anchors.verticalCenter: parent.verticalCenter
                spacing: 3
                Text {
                    width: parent.width
                    text: "SỰ KIỆN HỆ THỐNG"
                    color: "#f8fafc"
                    font.pixelSize: 29
                    font.bold: true
                    elide: Text.ElideRight
                }
                Text {
                    width: parent.width
                    text: "Operator audit · Control commands · Device state · Alarms · Communications · EMS services"
                    color: "#fed7aa"
                    font.pixelSize: 13
                    elide: Text.ElideRight
                }
            }

            Item { width: parent.width - 600 - 9 - 14 - 520 - 28; height: 1 }

            Rectangle {
                width: 520
                height: 40
                radius: 8
                color: "#0a1524"
                border.color: "#1e293b"
                anchors.verticalCenter: parent.verticalCenter

                Row {
                    id: eventStatusRow
                    anchors.fill: parent
                    anchors.leftMargin: 12
                    anchors.rightMargin: 12
                    spacing: 12

                    Text {
                        width: 126
                        height: eventStatusRow.height
                        text: root.eventFilter.timeRange || "Today"
                        color: "#f59e0b"
                        font.pixelSize: 12
                        font.bold: true
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                        elide: Text.ElideRight
                    }

                    Text {
                        width: 222
                        height: eventStatusRow.height
                        text: "Latest: " + (root.eventSummary.latestEventTime || "--")
                        color: "#cbd5e1"
                        font.pixelSize: 11
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                        elide: Text.ElideRight
                    }

                    Text {
                        width: 124
                        height: eventStatusRow.height
                        text: root.statusMessage
                        color: root.eventFilter.valid === false ? "#ef4444" : "#94a3b8"
                        font.pixelSize: 11
                        verticalAlignment: Text.AlignVCenter
                        horizontalAlignment: Text.AlignHCenter
                        elide: Text.ElideRight
                    }
                }
            }
        }

        EventSummaryBar {
            x: 24
            y: 88
            width: parent.width - 48
            height: 96
            summary: root.eventSummary
        }

        EventFilterBar {
            id: filterBar
            x: 24
            y: 198
            width: parent.width - 48
            height: implicitHeight
            filter: root.eventFilter
            dataSource: root.dataSource
            live: root.live
        }

        EventTable {
            x: 24
            y: filterBar.y + filterBar.height + 14
            width: parent.width - 48
            height: board.height - 34 - y
            onRowActivated: root.detailOpen = true
            events: root.eventsModel
            selectedEvent: root.selectedEvent
            eventSummary: root.eventSummary
            filter: root.eventFilter
            dataSource: root.dataSource
        }

        Text {
            x: 24
            y: board.height - 26
            width: parent.width - 48
            height: 18
            text: "Storage: SQLite data/events.sqlite · retention 5000 records · CSV: exports/EMS_EventLog_YYYYMMDD_HHMMSS.csv"
            color: "#64748b"
            font.pixelSize: 10
            elide: Text.ElideRight
        }
    }

    Rectangle {
        anchors.fill: parent
        visible: root.detailOpen
        color: "#000000aa"
        z: 900
        MouseArea { anchors.fill: parent; onClicked: root.detailOpen = false }
    }

    Item {
        id: detailPopup
        visible: root.detailOpen
        z: 901
        anchors.centerIn: parent
        width: Math.min(620, root.width - 48)
        height: Math.min(720, root.height - 48)

        MouseArea { anchors.fill: parent }

        EventDetailPanel {
            anchors.fill: parent
            eventRecord: root.selectedEvent
        }

        Rectangle {
            width: 30
            height: 30
            radius: 15
            x: parent.width - width - 12
            y: 10
            z: 5
            color: evtCloseMouse.containsMouse ? "#1e293b" : "#0b2237"
            border.color: "#64748b"
            Text { anchors.centerIn: parent; text: "✕"; color: "#f8fafc"; font.pixelSize: 14; font.bold: true }
            MouseArea {
                id: evtCloseMouse
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: root.detailOpen = false
            }
        }
    }

    ExportProgressDialog {
        dataSource: root.dataSource
    }
}

